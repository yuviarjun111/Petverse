# 🐾 PetVerse — Your Habits. Your Pets. Your World.

A native Android virtual-pet game where **real-life habits power your pets' growth**.
Built with **Kotlin + Jetpack Compose + Room + WorkManager**, 100% offline, with no login, ads or subscriptions.

---

## 📱 How to get the APK

### Option A: Build in the cloud with GitHub (no PC setup needed)
1. Create a free GitHub account and a **new empty repository** (for example `PetVerse`).
2. Upload the **contents** of this folder to the repository. On github.com use *Add file → Upload files* and drag everything in, including the hidden `.github` folder. If the uploader skips `.github`, create the file `.github/workflows/build-apk.yml` by hand and paste in the workflow from this project.
3. Open the **Actions** tab. The workflow **"Build PetVerse APK"** starts on its own. If it doesn't, click it and press **Run workflow**.
4. Wait about 5–8 minutes. Then open the finished run and download **PetVerse-debug-apk** from *Artifacts*.
5. Unzip it and copy `app-debug.apk` to your phone. Open it and allow *Install unknown apps* when Android asks.

### Option B: Android Studio (PC/Mac)
1. Install **Android Studio** (Ladybug 2024.2 or newer). JDK 17+ comes bundled.
2. Choose *File → Open* and select the `PetVerse` folder. Wait for Gradle sync to finish; the first time downloads about 1 GB.
3. Press **Build → Build App Bundle(s) / APK(s) → Build APK(s)**.
4. Click **locate** in the popup. The APK is at `app/build/outputs/apk/debug/app-debug.apk`.
5. Or plug your phone in with USB debugging on and press ▶ **Run**.

### Option C: Command line
```bash
./gradlew assembleDebug      # Windows: gradlew.bat assembleDebug
# → app/build/outputs/apk/debug/app-debug.apk
./gradlew assembleRelease    # installable release APK (signed with the debug key for testing)
```
You need the Android SDK installed: set `ANDROID_HOME`, or create `local.properties` containing `sdk.dir=...`.

**Requirements:** Android 8.0 (API 26) or newer.

---

## ✨ Features

| Area | What's inside |
|---|---|
| **66 species** | Dogs (9 breeds), cats (6), rabbit, hamster, guinea pig, hedgehog, pony, horse, fox, wolf, deer, bears, koala, panda, monkey, gorilla, zebra, giraffe, elephant, lion, tiger, leopard, cheetah, polar bear, 8 birds, 10 aquatic animals, 6 reptiles, 5 mythical creatures |
| **Rarity (6 tiers)** | Common → Uncommon → Rare → Epic → Legendary → Mythical. Rarity is kept **separate** from development level and only describes how rarely a species is discovered |
| **Habits → pets** | Each habit gives coins, 1 Pet Food, XP, loyalty and partner-pet XP. The category adds a bonus (Learning = +1 Training Point, and so on). **5 habits in a day = Habit Power: +50 XP, +20 Happiness, +10 Loyalty, +1 Development Point** |
| **Custom habits** | Create, edit and archive habits with your own icon, category and difficulty, or pick from 16 suggestions |
| **Care** | Feed, water, pet, play, toys, clean, rest/sleep, items, walks (dogs and horses), tricks, cuddles, adventures, bond gifts, each with its own animation |
| **Loyalty (6 levels)** | Stranger → Familiar → Friend → Trusted Friend → Best Friend → Unbreakable Bond. Each level unlocks new interactions |
| **Growth (5 stages)** | Every species group has its own stage names (e.g. Newborn → Baby Puppy → Young Puppy → Adult Dog → Advanced Companion). Growing needs a pet level **and** Development Points, so habits drive growth. Each stage unlocks abilities, skills and accessories |
| **Training** | A 3-round timing mini-game with 4–6 skills per species group. Mastered skills unlock "Show Trick" |
| **World** | 10 areas: Pet Home, Dog Park, Cat House, Training Ground, Horse Stable, Aquarium, Bird Sanctuary, Forest, Animal Sanctuary and Mythic Grove. They unlock by level, and your pets roam around inside them |
| **Sanctuary ethics** | Wild and dangerous animals are always sanctuary residents: you care for them as a keeper with enrichment, observation and cooperative training, never as household pets |
| **No suffering** | Needs drift down gently to a comfortable floor and never below it. Pets never starve, get sick or die |
| **Gamification** | 7-day login rewards, 5 daily missions, 4 weekly challenges, 3 monthly goals, 29 badges, streaks, trainer levels, a collection book and a shop with 20 items |
| **App** | 15 screens, light/dark/system themes, daily reminder notifications (time is configurable), haptics and a full progress reset |

---

## 🏗️ Architecture

```
app/src/main/java/com/petverse/app/
├── PetVerseApp.kt              Application + manual DI container
├── MainActivity.kt             Edge-to-edge Compose host, theme switching
├── data/
│   ├── model/Enums.kt          Rarity, categories, groups, environments, actions, reactions
│   ├── catalog/                Species (66), items, habit presets, skills, missions, badges, login rewards
│   ├── db/Database.kt          Room entities, DAOs and the database
│   └── repo/GameRepository.kt  All game logic, run inside Room transactions
├── domain/GameRules.kt         XP curves, bonds, growth, gentle needs drift, stats, mission engine
├── notifications/              Notification channel, WorkManager daily reminder
├── util/Time.kt                Dates and streak calculation
└── ui/
    ├── GameViewModel.kt        StateFlows + actions, events → toasts and celebrations
    ├── theme/                  Colours, typography, light/dark schemes
    ├── components/             Cards, bars, rings, chips, AnimatedPet, EnvironmentBackdrop
    ├── navigation/             NavHost, bottom bar, toast + celebration overlays
    └── screens/                Splash, Onboarding, Dashboard, My Pets, Collection, Pet Interaction,
                                Training, Habit Tracker, Missions, Shop, World/Sanctuary,
                                Achievements, Statistics, Profile, Settings
```

**Data flow:** Room → Flow → `GameRepository` → `StateFlow` in `GameViewModel` → Compose UI.
Actions go back through the repository, which returns `GameEvent`s (toasts or celebration dialogs) and a `Reaction` that plays the pet's animation.

**Art:** all visuals are drawn in code. Animals are rendered from emoji and brought to life with Compose animations: breathing, bounce, tail-wag wiggle, hopping, flying, swimming, slithering, walking across the scene, a spinning hamster wheel, particles, sleeping Zzz, mythical auras and accessory overlays. Scenes are layered gradient backdrops. Because nothing depends on image files, no assets can go missing.

---

## 🔧 Troubleshooting
- **Gradle sync fails** → use *File → Settings → Build Tools → Gradle → Gradle JDK = 17 or 21*.
- **SDK not found** → open *SDK Manager* and install *Android 15 (API 35)*.
- **Notifications don't appear** → turn on *Settings → Daily reminder* in the app and allow notifications when Android asks.
- Some newer emoji may look different on older Android versions. That's normal.
