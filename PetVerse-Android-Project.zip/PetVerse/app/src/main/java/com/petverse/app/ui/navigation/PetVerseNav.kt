package com.petverse.app.ui.navigation

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.Pets
import androidx.compose.material.icons.rounded.Public
import androidx.compose.material.icons.rounded.TaskAlt
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.petverse.app.domain.GameEvent
import com.petverse.app.ui.GameViewModel
import com.petverse.app.ui.components.GradientButton
import com.petverse.app.ui.screens.AchievementsScreen
import com.petverse.app.ui.screens.CollectionScreen
import com.petverse.app.ui.screens.DashboardScreen
import com.petverse.app.ui.screens.EnvironmentScreen
import com.petverse.app.ui.screens.HabitTrackerScreen
import com.petverse.app.ui.screens.MissionsScreen
import com.petverse.app.ui.screens.MyPetsScreen
import com.petverse.app.ui.screens.OnboardingScreen
import com.petverse.app.ui.screens.PetInteractionScreen
import com.petverse.app.ui.screens.ProfileScreen
import com.petverse.app.ui.screens.SettingsScreen
import com.petverse.app.ui.screens.ShopScreen
import com.petverse.app.ui.screens.SplashScreen
import com.petverse.app.ui.screens.StatisticsScreen
import com.petverse.app.ui.screens.TrainingScreen
import com.petverse.app.ui.screens.WorldScreen
import kotlinx.coroutines.delay

object Routes {
    const val SPLASH = "splash"
    const val ONBOARDING = "onboarding"
    const val HOME = "home"
    const val PETS = "pets"
    const val HABITS = "habits"
    const val WORLD = "world"
    const val PROFILE = "profile"
    const val COLLECTION = "collection"
    const val PET = "pet/{id}"
    const val TRAIN = "train/{id}"
    const val MISSIONS = "missions"
    const val SHOP = "shop"
    const val ACHIEVEMENTS = "achievements"
    const val STATS = "stats"
    const val SETTINGS = "settings"
    const val ENV = "env/{id}"

    fun pet(id: Long) = "pet/$id"
    fun train(id: Long) = "train/$id"
    fun env(id: String) = "env/$id"
}

private data class Tab(val route: String, val label: String, val icon: ImageVector)

private val tabs = listOf(
    Tab(Routes.HOME, "Home", Icons.Rounded.Home),
    Tab(Routes.PETS, "Pets", Icons.Rounded.Pets),
    Tab(Routes.HABITS, "Habits", Icons.Rounded.TaskAlt),
    Tab(Routes.WORLD, "World", Icons.Rounded.Public),
    Tab(Routes.PROFILE, "Profile", Icons.Rounded.Person),
)

/** Navigate to a bottom-bar tab, keeping a single copy of each tab. */
fun NavHostController.goTab(route: String) {
    navigate(route) {
        popUpTo(Routes.HOME) { saveState = true }
        launchSingleTop = true
        restoreState = true
    }
}

private data class ToastItem(val id: Long, val text: String, val emoji: String, val error: Boolean)

@Composable
fun PetVerseRoot(vm: GameViewModel) {
    val nav = rememberNavController()
    val entry by nav.currentBackStackEntryAsState()
    val route = entry?.destination?.route
    val showBar = tabs.any { it.route == route }

    val toasts = remember { mutableStateListOf<ToastItem>() }
    val celebrations = remember { mutableStateListOf<GameEvent.Celebration>() }
    LaunchedEffect(Unit) {
        vm.events.collect { e ->
            when (e) {
                is GameEvent.Toast -> toasts.add(ToastItem(System.nanoTime(), e.text, e.emoji, false))
                is GameEvent.Problem -> toasts.add(ToastItem(System.nanoTime(), e.text, "⚠️", true))
                is GameEvent.Celebration -> celebrations.add(e)
            }
            while (toasts.size > 3) toasts.removeAt(0)
        }
    }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        bottomBar = {
            if (showBar) {
                NavigationBar(containerColor = MaterialTheme.colorScheme.surface, tonalElevation = 0.dp) {
                    tabs.forEach { tab ->
                        NavigationBarItem(
                            selected = route == tab.route,
                            onClick = { nav.goTab(tab.route) },
                            icon = { Icon(tab.icon, contentDescription = tab.label) },
                            label = { Text(tab.label) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = Color.White,
                                indicatorColor = MaterialTheme.colorScheme.primary,
                                selectedTextColor = MaterialTheme.colorScheme.primary,
                            ),
                        )
                    }
                }
            }
        },
    ) { padding ->
        Box(Modifier.fillMaxSize().padding(padding)) {
            NavHost(navController = nav, startDestination = Routes.SPLASH) {
                composable(Routes.SPLASH) {
                    SplashScreen(vm) { onboarded ->
                        nav.navigate(if (onboarded) Routes.HOME else Routes.ONBOARDING) {
                            popUpTo(Routes.SPLASH) { inclusive = true }
                        }
                    }
                }
                composable(Routes.ONBOARDING) {
                    OnboardingScreen(vm) {
                        nav.navigate(Routes.HOME) { popUpTo(Routes.ONBOARDING) { inclusive = true } }
                    }
                }
                composable(Routes.HOME) { DashboardScreen(vm, nav) }
                composable(Routes.PETS) { MyPetsScreen(vm, nav) }
                composable(Routes.HABITS) { HabitTrackerScreen(vm, nav, showBack = false) }
                composable(Routes.WORLD) { WorldScreen(vm, nav) }
                composable(Routes.PROFILE) { ProfileScreen(vm, nav) }
                composable(Routes.COLLECTION) { CollectionScreen(vm, nav) }
                composable(Routes.MISSIONS) { MissionsScreen(vm, nav) }
                composable(Routes.SHOP) { ShopScreen(vm, nav) }
                composable(Routes.ACHIEVEMENTS) { AchievementsScreen(vm, nav) }
                composable(Routes.STATS) { StatisticsScreen(vm, nav) }
                composable(Routes.SETTINGS) {
                    SettingsScreen(vm, nav) {
                        nav.navigate(Routes.ONBOARDING) { popUpTo(nav.graph.id) { inclusive = true } }
                    }
                }
                composable(Routes.PET, arguments = listOf(navArgument("id") { type = NavType.LongType })) { e ->
                    PetInteractionScreen(vm, nav, e.arguments?.getLong("id") ?: 0L)
                }
                composable(Routes.TRAIN, arguments = listOf(navArgument("id") { type = NavType.LongType })) { e ->
                    TrainingScreen(vm, nav, e.arguments?.getLong("id") ?: 0L)
                }
                composable(Routes.ENV, arguments = listOf(navArgument("id") { type = NavType.StringType })) { e ->
                    EnvironmentScreen(vm, nav, e.arguments?.getString("id") ?: "HOME")
                }
            }

            // Toasts
            Column(
                Modifier
                    .align(Alignment.TopCenter)
                    .padding(top = 8.dp, start = 16.dp, end = 16.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp),
            ) {
                toasts.forEach { t ->
                    key(t.id) {
                        ToastView(t) { toasts.remove(t) }
                    }
                }
            }
        }
    }

    celebrations.firstOrNull()?.let { c ->
        CelebrationDialog(c) { if (celebrations.isNotEmpty()) celebrations.removeAt(0) }
    }
}

@Composable
private fun ToastView(item: ToastItem, onDone: () -> Unit) {
    val visible = remember { androidx.compose.animation.core.MutableTransitionState(false) }
    LaunchedEffect(item.id) {
        visible.targetState = true
        delay(if (item.error) 2600 else 2200)
        visible.targetState = false
        delay(300)
        onDone()
    }
    AnimatedVisibility(
        visibleState = visible,
        enter = slideInVertically { -it } + fadeIn(),
        exit = slideOutVertically { -it } + fadeOut(),
    ) {
        Surface(
            shape = RoundedCornerShape(20.dp),
            color = if (item.error) Color(0xFF3A1E2A) else Color(0xFF22204A),
            shadowElevation = 8.dp,
        ) {
            Row(
                Modifier.padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(item.emoji, fontSize = 18.sp)
                Spacer(Modifier.width(10.dp))
                Text(item.text, color = Color.White, style = MaterialTheme.typography.bodyMedium)
            }
        }
    }
}

@Composable
private fun CelebrationDialog(event: GameEvent.Celebration, onDismiss: () -> Unit) {
    val pop = remember(event) { Animatable(0.3f) }
    LaunchedEffect(event) {
        pop.animateTo(1f, spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessLow))
    }
    Dialog(onDismissRequest = onDismiss) {
        Column(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(32.dp))
                .background(MaterialTheme.colorScheme.surface)
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("🎉", "✨", "🎊").forEach { Text(it, fontSize = 22.sp) }
            }
            Spacer(Modifier.height(8.dp))
            Text(
                event.emoji,
                fontSize = 84.sp,
                modifier = Modifier.graphicsLayer {
                    scaleX = pop.value
                    scaleY = pop.value
                },
            )
            Spacer(Modifier.height(12.dp))
            Text(event.title, style = MaterialTheme.typography.headlineSmall, textAlign = TextAlign.Center)
            Spacer(Modifier.height(8.dp))
            Text(
                event.message,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center,
            )
            Spacer(Modifier.height(20.dp))
            GradientButton("Awesome!", onClick = onDismiss, modifier = Modifier.fillMaxWidth())
        }
    }
}
