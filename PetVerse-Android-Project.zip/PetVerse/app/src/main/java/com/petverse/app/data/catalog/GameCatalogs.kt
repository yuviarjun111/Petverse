package com.petverse.app.data.catalog

import com.petverse.app.data.model.ActivityTypes
import com.petverse.app.data.model.Difficulty
import com.petverse.app.data.model.HabitCategory
import com.petverse.app.data.model.PetAction
import com.petverse.app.data.model.SpeciesGroup

// ------------------------------------------------------------------
// Items
// ------------------------------------------------------------------

enum class ItemType(val label: String, val emoji: String) {
    FOOD("Food", "🥣"),
    CARE("Care", "🧴"),
    TOY("Toys", "🎾"),
    ACCESSORY("Style", "🎀"),
    SPECIAL("Special", "🌟"),
}

enum class Anchor { HEAD, FACE, NECK }

data class ItemDef(
    val id: String,
    val name: String,
    val emoji: String,
    val type: ItemType,
    val price: Int?,
    val description: String,
    val minStage: Int = 1,
    val anchor: Anchor = Anchor.HEAD,
    val fullness: Int = 0,
    val happiness: Int = 0,
    val health: Int = 0,
    val energy: Int = 0,
    val cleanliness: Int = 0,
    val xp: Int = 0,
    val developmentPoints: Int = 0,
    val favoriteOf: Set<SpeciesGroup> = emptySet(),
) {
    val permanent: Boolean get() = type == ItemType.TOY || type == ItemType.ACCESSORY
    val sold: Boolean get() = price != null
}

object ItemCatalog {
    val all: List<ItemDef> = listOf(
        ItemDef("pet_food", "Pet Food", "🥣", ItemType.FOOD, 15, "A balanced everyday meal. Earned from every habit!",
            fullness = 30, happiness = 5, xp = 5),
        ItemDef("healthy_treat", "Healthy Treat", "🍪", ItemType.FOOD, 25, "A crunchy reward that boosts mood.",
            fullness = 10, happiness = 12, health = 4, xp = 8),
        ItemDef("premium_meal", "Premium Meal", "🥗", ItemType.FOOD, 60, "A gourmet feast full of nutrients.",
            fullness = 60, happiness = 15, health = 10, xp = 15),
        ItemDef("golden_treat", "Golden Treat", "🌟", ItemType.SPECIAL, null, "A rare reward for perfect habit days. +50 pet XP!",
            fullness = 20, happiness = 20, xp = 50),
        ItemDef("growth_crystal", "Growth Crystal", "💎", ItemType.SPECIAL, null, "Grants +1 Development Point. Earned through big challenges.",
            developmentPoints = 1),

        ItemDef("grooming_kit", "Grooming Kit", "🧴", ItemType.CARE, 30, "A full spa session. Sparkling clean!",
            cleanliness = 100, happiness = 8, xp = 5),
        ItemDef("cloud_pillow", "Cloud Pillow", "☁️", ItemType.CARE, 30, "The comfiest nap ever. +50 energy.",
            energy = 50, happiness = 5, xp = 5),
        ItemDef("vitamin_snack", "Vitamin Snack", "🍎", ItemType.CARE, 40, "Keeps your friend feeling great.",
            health = 20, happiness = 5, fullness = 5, xp = 5),

        ItemDef("ball", "Rubber Ball", "🎾", ItemType.TOY, 80, "Bouncy, chewable and great for fetch.",
            favoriteOf = setOf(SpeciesGroup.DOG, SpeciesGroup.WILD_CANINE, SpeciesGroup.MARINE)),
        ItemDef("yarn", "Yarn Ball", "🧶", ItemType.TOY, 80, "Perfect for pouncing and batting around.",
            favoriteOf = setOf(SpeciesGroup.CAT, SpeciesGroup.BIG_CAT)),
        ItemDef("rope", "Chew Rope", "🪢", ItemType.TOY, 90, "A tug-of-war classic.",
            favoriteOf = setOf(SpeciesGroup.DOG, SpeciesGroup.EQUINE, SpeciesGroup.PRIMATE)),
        ItemDef("puzzle", "Puzzle Feeder", "🧩", ItemType.TOY, 150, "Brain games with tasty rewards.",
            favoriteOf = setOf(SpeciesGroup.PRIMATE, SpeciesGroup.BIRD, SpeciesGroup.SMALL, SpeciesGroup.REPTILE, SpeciesGroup.FISH)),
        ItemDef("spinner", "Spin Toy", "🪀", ItemType.TOY, 120, "Whirls, rolls and sparkles.",
            favoriteOf = setOf(SpeciesGroup.SMALL, SpeciesGroup.LARGE_MAMMAL, SpeciesGroup.MYTHIC)),

        ItemDef("bow", "Ribbon Bow", "🎀", ItemType.ACCESSORY, 100, "A sweet ribbon for any friend.", minStage = 1, anchor = Anchor.HEAD),
        ItemDef("flower", "Flower Crown", "🌸", ItemType.ACCESSORY, 140, "Fresh blossoms, always in bloom.", minStage = 2, anchor = Anchor.HEAD),
        ItemDef("scarf", "Cozy Scarf", "🧣", ItemType.ACCESSORY, 160, "Warm and stylish.", minStage = 2, anchor = Anchor.NECK),
        ItemDef("shades", "Cool Shades", "🕶️", ItemType.ACCESSORY, 220, "Too cool for the sun.", minStage = 3, anchor = Anchor.FACE),
        ItemDef("top_hat", "Top Hat", "🎩", ItemType.ACCESSORY, 260, "Very distinguished.", minStage = 3, anchor = Anchor.HEAD),
        ItemDef("crown", "Royal Crown", "👑", ItemType.ACCESSORY, 400, "For a truly grown-up companion.", minStage = 4, anchor = Anchor.HEAD),
        ItemDef("medal", "Champion Medal", "🏅", ItemType.ACCESSORY, 500, "Only for fully grown champions.", minStage = 5, anchor = Anchor.NECK),
    )

    private val map = all.associateBy { it.id }
    fun byId(id: String): ItemDef = map[id] ?: all.first()
    fun find(id: String?): ItemDef? = id?.let { map[it] }
    fun ofType(type: ItemType) = all.filter { it.type == type }
    val feedable: List<ItemDef> get() = all.filter { it.type == ItemType.FOOD || it.id == "golden_treat" }
    val usable: List<ItemDef> get() = all.filter { it.type == ItemType.CARE || it.id == "growth_crystal" }
}

// ------------------------------------------------------------------
// Habit presets
// ------------------------------------------------------------------

data class HabitPreset(
    val id: String,
    val name: String,
    val emoji: String,
    val category: HabitCategory,
    val difficulty: Difficulty,
)

object HabitPresets {
    val all = listOf(
        HabitPreset("wake_early", "Wake up early", "⏰", HabitCategory.MORNING, Difficulty.MEDIUM),
        HabitPreset("drink_water", "Drink water", "💧", HabitCategory.MORNING, Difficulty.EASY),
        HabitPreset("morning_exercise", "Morning exercise", "🏃", HabitCategory.MORNING, Difficulty.MEDIUM),
        HabitPreset("make_bed", "Make your bed", "🛏️", HabitCategory.MORNING, Difficulty.EASY),

        HabitPreset("read_book", "Read a book", "📖", HabitCategory.LEARNING, Difficulty.MEDIUM),
        HabitPreset("study_30", "Study for 30 minutes", "📚", HabitCategory.LEARNING, Difficulty.MEDIUM),
        HabitPreset("new_skill", "Learn a new skill", "🧠", HabitCategory.LEARNING, Difficulty.HARD),
        HabitPreset("coding", "Practice coding", "💻", HabitCategory.LEARNING, Difficulty.HARD),

        HabitPreset("daily_goals", "Complete daily goals", "🎯", HabitCategory.PERSONAL, Difficulty.MEDIUM),
        HabitPreset("discipline", "Maintain discipline", "🧭", HabitCategory.PERSONAL, Difficulty.MEDIUM),
        HabitPreset("screen_time", "Reduce screen time", "📵", HabitCategory.PERSONAL, Difficulty.HARD),
        HabitPreset("meditate", "Practice meditation", "🧘", HabitCategory.PERSONAL, Difficulty.EASY),

        HabitPreset("steps_5000", "Walk 5,000 steps", "👟", HabitCategory.HEALTH, Difficulty.MEDIUM),
        HabitPreset("workout", "Workout session", "💪", HabitCategory.HEALTH, Difficulty.HARD),
        HabitPreset("sleep_schedule", "Healthy sleep schedule", "😴", HabitCategory.HEALTH, Difficulty.MEDIUM),
        HabitPreset("healthy_meal", "Eat a healthy meal", "🥗", HabitCategory.HEALTH, Difficulty.EASY),
    )
    val defaultSelection = setOf("drink_water", "make_bed", "read_book", "meditate", "steps_5000")
    val emojiChoices = listOf(
        "⭐", "💧", "📖", "🏃", "🧘", "💻", "🎯", "🎨", "🎸", "🌱", "🥗", "😴", "🧹", "✍️", "🗣️", "💰",
        "📵", "🙏", "🚴", "🏊", "🧠", "📚", "☀️", "🍎",
    )
}

// ------------------------------------------------------------------
// Training skills
// ------------------------------------------------------------------

enum class SkillFocus(val label: String, val emoji: String) { INTELLIGENCE("Intelligence", "🧠"), STRENGTH("Strength", "💪") }

data class SkillDef(
    val id: String,
    val name: String,
    val emoji: String,
    val focus: SkillFocus,
    val sessions: Int,
    val minStage: Int,
)

object TrainingCatalog {
    private val I = SkillFocus.INTELLIGENCE
    private val S = SkillFocus.STRENGTH

    private val dog = listOf(
        SkillDef("sit", "Sit", "🐾", I, 3, 1),
        SkillDef("paw", "Shake Paw", "🤝", I, 3, 1),
        SkillDef("fetch", "Fetch", "🎾", S, 4, 2),
        SkillDef("roll", "Roll Over", "🔄", I, 4, 2),
        SkillDef("agility", "Agility Course", "🏁", S, 5, 3),
        SkillDef("scent", "Scent Search", "🔍", I, 5, 4),
    )
    private val cat = listOf(
        SkillDef("come", "Come When Called", "📣", I, 3, 1),
        SkillDef("high_five", "High Five", "✋", I, 3, 1),
        SkillDef("hop", "Agility Hop", "🪜", S, 4, 2),
        SkillDef("puzzle", "Puzzle Solver", "🧩", I, 4, 2),
        SkillDef("leap", "Grand Leap", "🌙", S, 5, 3),
    )
    private val equine = listOf(
        SkillDef("halt", "Halt & Stand", "🛑", I, 3, 1),
        SkillDef("trot", "Trot", "🐾", S, 3, 1),
        SkillDef("canter", "Canter", "💨", S, 4, 2),
        SkillDef("show_jump", "Show Jump", "🚧", S, 5, 3),
        SkillDef("dressage", "Dressage", "🎼", I, 5, 4),
    )
    private val small = listOf(
        SkillDef("name", "Name Recall", "🔔", I, 3, 1),
        SkillDef("maze", "Maze Run", "🌀", I, 3, 1),
        SkillDef("spin", "Spin", "🔄", I, 4, 2),
        SkillDef("hoop", "Hoop Jump", "⭕", S, 4, 2),
    )
    private val wild = listOf(
        SkillDef("target", "Target Training", "🎯", I, 3, 1),
        SkillDef("station", "Station Training", "📍", I, 3, 1),
        SkillDef("checkup", "Health-Check Cooperation", "🩺", I, 4, 2),
        SkillDef("enrichment", "Enrichment Puzzle", "🧩", I, 4, 2),
        SkillDef("strength_play", "Strength Play", "💪", S, 5, 3),
    )
    private val bird = listOf(
        SkillDef("step_up", "Step Up", "☝️", I, 3, 1),
        SkillDef("wave", "Wave", "👋", I, 3, 1),
        SkillDef("recall", "Recall Flight", "🪃", S, 4, 2),
        SkillDef("mimic", "Sound Mimic", "🗣️", I, 5, 3),
    )
    private val aquatic = listOf(
        SkillDef("target_touch", "Target Touch", "🎯", I, 3, 1),
        SkillDef("ring_swim", "Ring Swim", "⭕", S, 3, 1),
        SkillDef("bubble", "Bubble Trick", "💧", I, 4, 2),
        SkillDef("wave_leap", "Wave Leap", "🌊", S, 5, 3),
    )
    private val reptile = listOf(
        SkillDef("target", "Target Training", "🎯", I, 3, 1),
        SkillDef("calm", "Calm Handling", "🤲", I, 3, 1),
        SkillDef("feed_station", "Feeding Station", "🍽️", I, 4, 2),
        SkillDef("climb", "Climb Course", "🌿", S, 4, 2),
    )
    private val mythic = listOf(
        SkillDef("ember", "Ember Control", "🔥", S, 3, 1),
        SkillDef("sky_dance", "Sky Dance", "🌌", S, 4, 2),
        SkillDef("star_sense", "Star Sense", "⭐", I, 4, 2),
        SkillDef("aura", "Aura Bloom", "🌈", I, 5, 3),
    )

    fun skillsFor(group: SpeciesGroup, wildAnimal: Boolean): List<SkillDef> = when {
        group == SpeciesGroup.MYTHIC -> mythic
        group == SpeciesGroup.FISH || group == SpeciesGroup.MARINE -> aquatic
        group == SpeciesGroup.BIRD -> bird
        group == SpeciesGroup.REPTILE -> if (wildAnimal) wild else reptile
        wildAnimal -> wild
        group == SpeciesGroup.DOG -> dog
        group == SpeciesGroup.CAT -> cat
        group == SpeciesGroup.EQUINE -> equine
        group == SpeciesGroup.SMALL -> small
        else -> wild
    }
}

// ------------------------------------------------------------------
// Missions
// ------------------------------------------------------------------

enum class MissionPeriod(val label: String) { DAILY("Daily"), WEEKLY("Weekly"), MONTHLY("Monthly") }
enum class MissionMetric { ACTIVITY, HABIT_STREAK }

data class MissionDef(
    val id: String,
    val period: MissionPeriod,
    val title: String,
    val emoji: String,
    val metric: MissionMetric,
    val types: Set<String>,
    val target: Int,
    val coins: Int,
    val xp: Int,
    val itemId: String? = null,
    val itemQty: Int = 0,
    val trainingPoints: Int = 0,
)

object MissionCatalog {
    private val D = MissionPeriod.DAILY
    private val W = MissionPeriod.WEEKLY
    private val Mo = MissionPeriod.MONTHLY
    private val ACT = MissionMetric.ACTIVITY

    val dailyCore = MissionDef("d_habits3", D, "Complete three habits", "✅", ACT, setOf(ActivityTypes.HABIT), 3, 30, 20, "healthy_treat", 1)

    val dailyPool = listOf(
        MissionDef("d_feed", D, "Feed your pet", "🍖", ACT, setOf(PetAction.FEED.name), 1, 15, 10),
        MissionDef("d_play", D, "Play with your pet twice", "🎾", ACT, setOf(PetAction.PLAY.name), 2, 20, 15),
        MissionDef("d_train", D, "Train your pet", "🎯", ACT, setOf(PetAction.TRAIN.name), 1, 25, 15, trainingPoints = 1),
        MissionDef("d_pet", D, "Pet your animals 5 times", "🤚", ACT, setOf(PetAction.PET.name), 5, 15, 10),
        MissionDef("d_water", D, "Give fresh water twice", "💧", ACT, setOf(PetAction.WATER.name), 2, 15, 10),
        MissionDef("d_clean", D, "Clean a habitat", "🧽", ACT, setOf(PetAction.CLEAN.name), 1, 15, 10),
        MissionDef("d_walk", D, "Take a pet for a walk", "🦮", ACT, setOf(PetAction.WALK.name), 1, 25, 15),
        MissionDef("d_toy", D, "Give a toy", "🧸", ACT, setOf(PetAction.TOY.name), 1, 15, 10),
        MissionDef("d_habits5", D, "Complete five habits", "🔥", ACT, setOf(ActivityTypes.HABIT), 5, 50, 30, "pet_food", 2),
    )

    val weekly = listOf(
        MissionDef("w_habits20", W, "Complete 20 habits this week", "📅", ACT, setOf(ActivityTypes.HABIT), 20, 150, 80, "premium_meal", 1),
        MissionDef("w_train5", W, "Train 5 times", "🏋️", ACT, setOf(PetAction.TRAIN.name), 5, 100, 60, trainingPoints = 2),
        MissionDef("w_streak7", W, "Maintain a 7-day habit streak", "🔥", MissionMetric.HABIT_STREAK, emptySet(), 7, 200, 100, "golden_treat", 1),
        MissionDef("w_care30", W, "Care for your pets 30 times", "💞", ACT, ActivityTypes.CARE, 30, 120, 60, "grooming_kit", 1),
    )

    val monthly = listOf(
        MissionDef("m_habits80", Mo, "Complete 80 habits this month", "🏆", ACT, setOf(ActivityTypes.HABIT), 80, 500, 250, "growth_crystal", 1),
        MissionDef("m_train20", Mo, "Train 20 times this month", "🎓", ACT, setOf(PetAction.TRAIN.name), 20, 300, 150, trainingPoints = 5),
        MissionDef("m_perfect10", Mo, "Have 10 perfect habit days", "🌟", ACT, setOf(ActivityTypes.PERFECT_DAY), 10, 400, 200, "growth_crystal", 1),
    )
}

// ------------------------------------------------------------------
// Achievements / badges
// ------------------------------------------------------------------

enum class AchievementMetric {
    TOTAL_HABITS, BEST_STREAK, PETS_OWNED, MAX_RARITY, MAX_BOND, MAX_STAGE, PLAYER_LEVEL, LOGIN_STREAK, ACTIVITY
}

data class AchievementDef(
    val id: String,
    val title: String,
    val description: String,
    val emoji: String,
    val metric: AchievementMetric,
    val target: Int,
    val coins: Int,
    val types: Set<String> = emptySet(),
    val itemId: String? = null,
)

object AchievementCatalog {
    private val H = AchievementMetric.TOTAL_HABITS
    private val ST = AchievementMetric.BEST_STREAK
    private val A = AchievementMetric.ACTIVITY

    val all = listOf(
        AchievementDef("first_habit", "First Step", "Complete your first habit", "👣", H, 1, 20),
        AchievementDef("habits_25", "Habit Builder", "Complete 25 habits", "🧱", H, 25, 100),
        AchievementDef("habits_100", "Habit Hero", "Complete 100 habits", "🦸", H, 100, 300, itemId = "growth_crystal"),
        AchievementDef("habits_365", "Habit Legend", "Complete 365 habits", "🏛️", H, 365, 1000, itemId = "growth_crystal"),
        AchievementDef("streak_3", "Warming Up", "Reach a 3-day habit streak", "🔥", ST, 3, 50),
        AchievementDef("streak_7", "Week Warrior", "Reach a 7-day habit streak", "⚔️", ST, 7, 150),
        AchievementDef("streak_30", "Monthly Master", "Reach a 30-day habit streak", "🗓️", ST, 30, 600, itemId = "growth_crystal"),
        AchievementDef("pets_3", "Animal Friend", "Care for 3 animals", "🤝", AchievementMetric.PETS_OWNED, 3, 100),
        AchievementDef("pets_10", "Collector", "Care for 10 animals", "📘", AchievementMetric.PETS_OWNED, 10, 300),
        AchievementDef("pets_25", "Grand Collector", "Care for 25 animals", "📚", AchievementMetric.PETS_OWNED, 25, 800),
        AchievementDef("rare", "Rare Discovery", "Discover a Rare species", "💠", AchievementMetric.MAX_RARITY, 3, 100),
        AchievementDef("epic", "Epic Discovery", "Discover an Epic species", "🔮", AchievementMetric.MAX_RARITY, 4, 200),
        AchievementDef("legendary", "Legendary Discovery", "Discover a Legendary species", "🌠", AchievementMetric.MAX_RARITY, 5, 400),
        AchievementDef("mythical", "Mythic Keeper", "Discover a Mythical creature", "🐉", AchievementMetric.MAX_RARITY, 6, 800),
        AchievementDef("bond_friend", "True Friends", "Reach Friend bond with a pet", "💛", AchievementMetric.MAX_BOND, 3, 80),
        AchievementDef("bond_best", "Best Friends", "Reach Best Friend bond", "💖", AchievementMetric.MAX_BOND, 5, 250),
        AchievementDef("bond_max", "Unbreakable", "Reach an Unbreakable Bond", "♾️", AchievementMetric.MAX_BOND, 6, 600, itemId = "growth_crystal"),
        AchievementDef("stage_3", "Growing Up", "Grow a pet to stage 3", "🌱", AchievementMetric.MAX_STAGE, 3, 120),
        AchievementDef("stage_5", "Fully Grown", "Grow a pet to stage 5", "🌳", AchievementMetric.MAX_STAGE, 5, 500),
        AchievementDef("train_10", "Trainer", "Complete 10 training sessions", "🎯", A, 10, 100, types = setOf(PetAction.TRAIN.name)),
        AchievementDef("train_50", "Master Trainer", "Complete 50 training sessions", "🥋", A, 50, 400, types = setOf(PetAction.TRAIN.name)),
        AchievementDef("walk_10", "Trail Buddy", "Go on 10 walks", "🦮", A, 10, 120, types = setOf(PetAction.WALK.name)),
        AchievementDef("care_100", "Devoted Caretaker", "Perform 100 care actions", "🫶", A, 100, 200, types = ActivityTypes.CARE),
        AchievementDef("perfect_1", "Perfect Day", "Complete every habit in a day", "🌟", A, 1, 80, types = setOf(ActivityTypes.PERFECT_DAY)),
        AchievementDef("perfect_10", "Perfectionist", "Have 10 perfect days", "💯", A, 10, 400, types = setOf(ActivityTypes.PERFECT_DAY)),
        AchievementDef("level_5", "Rising Trainer", "Reach Trainer Level 5", "⭐", AchievementMetric.PLAYER_LEVEL, 5, 100),
        AchievementDef("level_10", "Pro Trainer", "Reach Trainer Level 10", "🌟", AchievementMetric.PLAYER_LEVEL, 10, 300),
        AchievementDef("level_20", "Elite Trainer", "Reach Trainer Level 20", "👑", AchievementMetric.PLAYER_LEVEL, 20, 800),
        AchievementDef("login_7", "Loyal Visitor", "Visit 7 days in a row", "📆", AchievementMetric.LOGIN_STREAK, 7, 150),
    )

    fun byId(id: String) = all.firstOrNull { it.id == id }
}

// ------------------------------------------------------------------
// Daily login rewards (7-day cycle)
// ------------------------------------------------------------------

data class LoginReward(val day: Int, val emoji: String, val label: String, val coins: Int = 0, val items: Map<String, Int> = emptyMap(), val trainingPoints: Int = 0)

object LoginRewards {
    val cycle = listOf(
        LoginReward(1, "🪙", "30 coins", coins = 30),
        LoginReward(2, "🥣", "2 Pet Food", items = mapOf("pet_food" to 2)),
        LoginReward(3, "🪙", "50 coins", coins = 50),
        LoginReward(4, "🍪", "Treat + Training Point", items = mapOf("healthy_treat" to 1), trainingPoints = 1),
        LoginReward(5, "💰", "80 coins", coins = 80),
        LoginReward(6, "🧴", "Care bundle", items = mapOf("grooming_kit" to 1, "cloud_pillow" to 1)),
        LoginReward(7, "🌟", "150 coins + Golden Treat", coins = 150, items = mapOf("golden_treat" to 1)),
    )

    fun forStreak(streak: Int): LoginReward = cycle[((streak - 1).coerceAtLeast(0)) % cycle.size]
}
