package com.petverse.app.ui.screens

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavHostController
import com.petverse.app.data.catalog.HabitPresets
import com.petverse.app.data.db.HabitEntity
import com.petverse.app.data.db.HabitLogEntity
import com.petverse.app.data.model.Difficulty
import com.petverse.app.data.model.HabitCategory
import com.petverse.app.ui.GameViewModel
import com.petverse.app.ui.components.ChoiceChip
import com.petverse.app.ui.components.EmptyState
import com.petverse.app.ui.components.GradientButton
import com.petverse.app.ui.components.OutlineButton
import com.petverse.app.ui.components.PVCard
import com.petverse.app.ui.components.Pill
import com.petverse.app.ui.components.ProgressRing
import com.petverse.app.ui.components.ScreenHeader
import com.petverse.app.ui.components.SectionTitle
import com.petverse.app.util.Streaks
import com.petverse.app.util.Time

fun habitStreak(habitId: Long, logs: List<HabitLogEntity>, today: Long): Int =
    Streaks.current(logs.filter { it.habitId == habitId }.map { it.epochDay }.toSet(), today)

/** One habit row with an animated check button. Shared by the dashboard and tracker. */
@Composable
fun HabitRow(
    habit: HabitEntity,
    done: Boolean,
    streak: Int,
    compact: Boolean = false,
    onEdit: (() -> Unit)? = null,
    onArchive: (() -> Unit)? = null,
    onComplete: () -> Unit,
) {
    val diff = runCatching { Difficulty.valueOf(habit.difficulty) }.getOrDefault(Difficulty.MEDIUM)
    val cat = runCatching { HabitCategory.valueOf(habit.category) }.getOrDefault(HabitCategory.CUSTOM)
    val checkScale by animateFloatAsState(
        if (done) 1f else 0.85f,
        spring(dampingRatio = Spring.DampingRatioHighBouncy, stiffness = Spring.StiffnessMedium),
        label = "check",
    )
    val bg by animateColorAsState(
        if (done) MaterialTheme.colorScheme.tertiary.copy(alpha = 0.14f) else MaterialTheme.colorScheme.surfaceVariant,
        label = "habitBg",
    )
    var menu by remember { mutableStateOf(false) }
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .background(bg)
            .padding(horizontal = 12.dp, vertical = if (compact) 8.dp else 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            Modifier
                .size(if (compact) 38.dp else 44.dp)
                .clip(CircleShape)
                .background(MaterialTheme.colorScheme.surface),
            contentAlignment = Alignment.Center,
        ) { Text(habit.emoji, fontSize = if (compact) 18.sp else 22.sp) }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(
                habit.name,
                style = MaterialTheme.typography.titleSmall,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                textDecoration = if (done) TextDecoration.LineThrough else TextDecoration.None,
                color = if (done) MaterialTheme.colorScheme.onSurfaceVariant else MaterialTheme.colorScheme.onSurface,
            )
            Text(
                buildString {
                    append("+${diff.coins} 🪙 • ${diff.label}")
                    if (streak > 0) append(" • 🔥 $streak")
                    if (!compact && cat != HabitCategory.CUSTOM) append(" • ${cat.bonusText}")
                },
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
        if (onEdit != null || onArchive != null) {
            Box {
                IconButton(onClick = { menu = true }) { Icon(Icons.Rounded.MoreVert, contentDescription = "More") }
                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                    if (onEdit != null) DropdownMenuItem(text = { Text("Edit") }, onClick = { menu = false; onEdit() })
                    if (onArchive != null) DropdownMenuItem(text = { Text("Archive") }, onClick = { menu = false; onArchive() })
                }
            }
        }
        Box(
            Modifier
                .size(40.dp)
                .graphicsLayer { scaleX = checkScale; scaleY = checkScale }
                .clip(CircleShape)
                .background(if (done) MaterialTheme.colorScheme.tertiary else Color.Transparent)
                .border(2.dp, if (done) MaterialTheme.colorScheme.tertiary else MaterialTheme.colorScheme.outline, CircleShape)
                .clickable(enabled = !done, onClick = onComplete),
            contentAlignment = Alignment.Center,
        ) {
            Text(if (done) "✓" else "", color = Color.White, fontSize = 20.sp)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HabitTrackerScreen(vm: GameViewModel, nav: NavHostController, showBack: Boolean) {
    val habits by vm.habits.collectAsStateWithLifecycle()
    val logs by vm.logs.collectAsStateWithLifecycle()
    val stats by vm.stats.collectAsStateWithLifecycle()
    val today = Time.today()
    val doneIds = logs.filter { it.epochDay == today }.map { it.habitId }.toSet()
    val doneCount = habits.count { it.id in doneIds }

    var editing by remember { mutableStateOf<HabitEntity?>(null) }
    var creating by remember { mutableStateOf(false) }
    var showPresets by remember { mutableStateOf(false) }
    var archiveTarget by remember { mutableStateOf<HabitEntity?>(null) }

    val back: (() -> Unit)? = if (showBack) {
        { nav.popBackStack() }
    } else {
        null
    }

    Box(Modifier.fillMaxSize()) {
        LazyColumn(
            Modifier.fillMaxSize(),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 96.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            item {
                ScreenHeader(
                    "Habit Tracker",
                    onBack = back,
                    subtitle = Time.prettyDate(today),
                )
            }
            item {
                PVCard {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        ProgressRing(
                            if (habits.isEmpty()) 0f else doneCount / habits.size.toFloat(),
                            size = 84.dp, stroke = 9.dp, color = MaterialTheme.colorScheme.tertiary,
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("$doneCount/${habits.size}", style = MaterialTheme.typography.titleLarge)
                                Text("today", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                        Spacer(Modifier.width(16.dp))
                        Column(Modifier.weight(1f)) {
                            Text("🔥 ${stats.currentStreak}-day streak", style = MaterialTheme.typography.titleMedium)
                            Text("Best: ${stats.bestStreak} days • Total: ${stats.totalHabits}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Spacer(Modifier.height(6.dp))
                            Text(
                                "Every habit: +coins, +1 Pet Food, partner XP & loyalty. 5 habits = Habit Power ⚡ (+1 Development Point)",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                    }
                    Spacer(Modifier.height(14.dp))
                    WeekStrip(logs, habits.size, today)
                }
            }
            if (habits.isEmpty()) {
                item {
                    EmptyState("🌱", "No habits yet", "Add a habit and every completion will help your pets grow.") {
                        GradientButton("Add suggested habits", onClick = { showPresets = true }, emoji = "✨")
                    }
                }
            }
            HabitCategory.entries.forEach { cat ->
                val list = habits.filter { it.category == cat.name }
                if (list.isNotEmpty()) {
                    item(key = "cat_${cat.name}") {
                        Row(Modifier.padding(top = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text("${cat.emoji}  ${cat.label}", style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
                            Pill(cat.bonusText, color = MaterialTheme.colorScheme.primary)
                        }
                    }
                    items(list, key = { it.id }) { h ->
                        HabitRow(
                            h, done = h.id in doneIds, streak = habitStreak(h.id, logs, today),
                            onEdit = { editing = h }, onArchive = { archiveTarget = h },
                        ) { vm.completeHabit(h.id) }
                    }
                }
            }
            item {
                Spacer(Modifier.height(4.dp))
                OutlineButton("Add from suggestions", onClick = { showPresets = true }, emoji = "💡", modifier = Modifier.fillMaxWidth())
            }
            item {
                PVCard {
                    SectionTitle("Last 28 days")
                    Spacer(Modifier.height(10.dp))
                    HabitHeatmap(logs, habits.size.coerceAtLeast(1), today)
                }
            }
        }
        ExtendedFloatingActionButton(
            onClick = { creating = true },
            icon = { Icon(Icons.Rounded.Add, contentDescription = null) },
            text = { Text("New habit") },
            containerColor = MaterialTheme.colorScheme.primary,
            contentColor = Color.White,
            modifier = Modifier.align(Alignment.BottomEnd).padding(20.dp),
        )
    }

    if (creating || editing != null) {
        HabitEditorDialog(
            initial = editing,
            onDismiss = { creating = false; editing = null },
            onSave = { name, emoji, cat, diff ->
                val e = editing
                if (e == null) {
                    vm.addHabit(name, emoji, cat, diff)
                } else {
                    vm.updateHabit(e.copy(name = name.trim(), emoji = emoji, category = cat.name, difficulty = diff.name))
                }
                creating = false
                editing = null
            },
        )
    }

    archiveTarget?.let { h ->
        AlertDialog(
            onDismissRequest = { archiveTarget = null },
            title = { Text("Archive “${h.name}”?") },
            text = { Text("It will disappear from your daily list. Its history stays in your statistics.") },
            confirmButton = { TextButton(onClick = { vm.archiveHabit(h.id); archiveTarget = null }) { Text("Archive") } },
            dismissButton = { TextButton(onClick = { archiveTarget = null }) { Text("Cancel") } },
        )
    }

    if (showPresets) {
        val activePresetIds = habits.mapNotNull { it.presetId }.toSet()
        var picked by remember { mutableStateOf(setOf<String>()) }
        ModalBottomSheet(
            onDismissRequest = { showPresets = false },
            sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
        ) {
            Column(Modifier.padding(horizontal = 20.dp).padding(bottom = 24.dp)) {
                Text("Suggested habits", style = MaterialTheme.typography.headlineSmall)
                Spacer(Modifier.height(10.dp))
                val available = HabitPresets.all.filter { it.id !in activePresetIds }
                if (available.isEmpty()) {
                    Text("You're already tracking every suggestion. Create a custom habit!", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                LazyColumn(Modifier.height(380.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(available, key = { it.id }) { pr ->
                        val sel = pr.id in picked
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(14.dp))
                                .background(if (sel) MaterialTheme.colorScheme.primary.copy(alpha = 0.15f) else MaterialTheme.colorScheme.surfaceVariant)
                                .clickable { picked = if (sel) picked - pr.id else picked + pr.id }
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Text(pr.emoji, fontSize = 20.sp)
                            Spacer(Modifier.width(10.dp))
                            Column(Modifier.weight(1f)) {
                                Text(pr.name, style = MaterialTheme.typography.titleSmall)
                                Text("${pr.category.label} • ${pr.difficulty.label}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            Text(if (sel) "✅" else "⬜", fontSize = 18.sp)
                        }
                    }
                }
                Spacer(Modifier.height(12.dp))
                GradientButton(
                    if (picked.isEmpty()) "Select habits" else "Add ${picked.size} habit${if (picked.size == 1) "" else "s"}",
                    enabled = picked.isNotEmpty(),
                    onClick = { vm.addPresetHabits(picked); showPresets = false },
                    modifier = Modifier.fillMaxWidth(),
                )
            }
        }
    }
}

@Composable
private fun WeekStrip(logs: List<HabitLogEntity>, totalHabits: Int, today: Long) {
    val counts = logs.groupingBy { it.epochDay }.eachCount()
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        for (i in 6 downTo 0) {
            val day = today - i
            val c = counts[day] ?: 0
            val frac = if (totalHabits == 0) 0f else (c / totalHabits.toFloat()).coerceIn(0f, 1f)
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(Time.shortDay(day).take(2), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.height(4.dp))
                ProgressRing(frac, size = 34.dp, stroke = 4.dp, color = if (day == today) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.tertiary) {
                    Text("${Time.dayOfMonth(day)}", style = MaterialTheme.typography.labelSmall)
                }
            }
        }
    }
}

@Composable
internal fun HabitHeatmap(logs: List<HabitLogEntity>, totalHabits: Int, today: Long) {
    val counts = logs.groupingBy { it.epochDay }.eachCount()
    val tint = MaterialTheme.colorScheme.tertiary
    Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
        for (week in 3 downTo 0) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                for (d in 6 downTo 0) {
                    val day = today - week * 7 - d
                    val frac = ((counts[day] ?: 0) / totalHabits.toFloat()).coerceIn(0f, 1f)
                    Box(
                        Modifier
                            .weight(1f)
                            .aspectRatio(1f)
                            .clip(RoundedCornerShape(6.dp))
                            .background(if (frac == 0f) MaterialTheme.colorScheme.surfaceVariant else tint.copy(alpha = 0.25f + 0.75f * frac))
                    )
                }
            }
        }
        Text("Darker = more habits completed that day", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun HabitEditorDialog(
    initial: HabitEntity?,
    onDismiss: () -> Unit,
    onSave: (String, String, HabitCategory, Difficulty) -> Unit,
) {
    var name by remember { mutableStateOf(initial?.name ?: "") }
    var emoji by remember { mutableStateOf(initial?.emoji ?: HabitPresets.emojiChoices.first()) }
    var cat by remember {
        mutableStateOf(initial?.let { runCatching { HabitCategory.valueOf(it.category) }.getOrNull() } ?: HabitCategory.CUSTOM)
    }
    var diff by remember {
        mutableStateOf(initial?.let { runCatching { Difficulty.valueOf(it.difficulty) }.getOrNull() } ?: Difficulty.MEDIUM)
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (initial == null) "New habit" else "Edit habit") },
        text = {
            Column {
                OutlinedTextField(
                    value = name, onValueChange = { if (it.length <= 40) name = it },
                    label = { Text("Habit name") }, singleLine = true, modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                )
                Spacer(Modifier.height(12.dp))
                Text("Icon", style = MaterialTheme.typography.labelLarge)
                Spacer(Modifier.height(6.dp))
                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(HabitPresets.emojiChoices) { e ->
                        Box(
                            Modifier
                                .size(40.dp)
                                .clip(CircleShape)
                                .background(if (e == emoji) MaterialTheme.colorScheme.primary.copy(alpha = 0.3f) else MaterialTheme.colorScheme.surfaceVariant)
                                .clickable { emoji = e },
                            contentAlignment = Alignment.Center,
                        ) { Text(e, fontSize = 20.sp) }
                    }
                }
                Spacer(Modifier.height(12.dp))
                Text("Category", style = MaterialTheme.typography.labelLarge)
                Spacer(Modifier.height(6.dp))
                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(HabitCategory.entries) { c ->
                        ChoiceChip(c.label, c == cat, onClick = { cat = c }, emoji = c.emoji)
                    }
                }
                Spacer(Modifier.height(12.dp))
                Text("Difficulty (bigger rewards for harder habits)", style = MaterialTheme.typography.labelLarge)
                Spacer(Modifier.height(6.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Difficulty.entries.forEach { d ->
                        ChoiceChip("${d.label} +${d.coins}", d == diff, onClick = { diff = d })
                    }
                }
            }
        },
        confirmButton = {
            TextButton(enabled = name.isNotBlank(), onClick = { onSave(name, emoji, cat, diff) }) { Text("Save") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}
