package com.petverse.app.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.petverse.app.data.catalog.Anchor
import com.petverse.app.data.catalog.ItemCatalog
import com.petverse.app.data.catalog.Species
import com.petverse.app.data.model.AnimStyle
import com.petverse.app.data.model.EnvironmentId
import com.petverse.app.data.model.Reaction
import com.petverse.app.ui.theme.LocalIsDark
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random

private fun lerpF(a: Float, b: Float, t: Float) = a + (b - a) * t

// ------------------------------------------------------------------
// Environment backdrop (3D-style layered scene)
// ------------------------------------------------------------------

@Composable
fun EnvironmentBackdrop(
    env: EnvironmentId,
    modifier: Modifier = Modifier,
    shape: Shape = RoundedCornerShape(28.dp),
    showDecor: Boolean = true,
    content: @Composable BoxScope.() -> Unit = {},
) {
    val dark = LocalIsDark.current
    val inf = rememberInfiniteTransition(label = "env")
    val drift by inf.animateFloat(
        0f, 1f, infiniteRepeatable(tween(9000, easing = LinearEasing), RepeatMode.Reverse), label = "drift"
    )
    BoxWithConstraints(
        modifier
            .clip(shape)
            .background(Brush.verticalGradient(listOf(Color(env.skyTop), Color(env.skyBottom))))
    ) {
        val w = maxWidth
        val h = maxHeight
        // Far hills for depth
        Canvas(Modifier.fillMaxSize()) {
            val groundTop = size.height * 0.62f
            drawCircle(
                Color(env.ground).copy(alpha = 0.35f),
                radius = size.width * 0.55f,
                center = Offset(size.width * 0.2f, groundTop + size.width * 0.45f),
            )
            drawCircle(
                Color(env.ground).copy(alpha = 0.45f),
                radius = size.width * 0.5f,
                center = Offset(size.width * 0.85f, groundTop + size.width * 0.42f),
            )
        }
        // Ground
        Box(
            Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .fillMaxHeight(0.34f)
                .background(
                    Brush.verticalGradient(listOf(Color(env.ground).copy(alpha = 0.9f), Color(env.ground)))
                )
        )
        if (showDecor) {
            env.skyDecor.forEachIndexed { i, e ->
                val x = if (i == 0) w * (0.08f + drift * 0.1f) else w * 0.78f
                Text(
                    e, fontSize = if (i == 0) 26.sp else 22.sp,
                    modifier = Modifier.offset(x = x, y = h * (0.06f + i * 0.04f)),
                )
            }
            val positions = listOf(0.02f, 0.80f, 0.20f, 0.64f)
            env.decor.forEachIndexed { i, e ->
                val small = i >= 2
                Text(
                    e, fontSize = if (small) 22.sp else 34.sp,
                    modifier = Modifier.offset(
                        x = w * positions[i % positions.size],
                        y = h * (if (small) 0.70f else 0.52f),
                    ),
                )
            }
        }
        if (dark && env != EnvironmentId.MYTHIC_GROVE && env != EnvironmentId.AQUARIUM) {
            Box(Modifier.fillMaxSize().background(Color(0xFF0A0830).copy(alpha = 0.32f)))
            Text("✨", fontSize = 12.sp, modifier = Modifier.offset(x = w * 0.5f, y = h * 0.08f))
            Text("✨", fontSize = 10.sp, modifier = Modifier.offset(x = w * 0.32f, y = h * 0.18f))
        }
        content()
    }
}

// ------------------------------------------------------------------
// Animated pet
// ------------------------------------------------------------------

private data class Particle(
    val emoji: String,
    val sx: Float, val sy: Float,
    val ex: Float, val ey: Float,
    val delay: Float,
    val arc: Float = 0f,
    val scale: Float = 1f,
    val spin: Float = 0f,
)

private fun buildParticles(reaction: Reaction?, emoji: String?, seed: Long): List<Particle> {
    if (reaction == null) return emptyList()
    val r = Random(seed)
    fun rx(span: Float) = (r.nextFloat() - 0.5f) * span
    return when (reaction) {
        Reaction.EAT -> listOf(
            Particle(emoji ?: "🥣", 0.75f, -0.15f, 0.12f, 0.02f, 0f, arc = 0.25f, scale = 1.2f),
            Particle("😋", 0.15f, -0.35f, 0.3f, -0.7f, 0.45f),
            Particle("✨", 0.05f, 0.0f, -0.25f, -0.45f, 0.5f, scale = 0.8f),
        )
        Reaction.DRINK -> List(4) { i -> Particle("💧", 0.5f + rx(0.2f), -0.55f, 0.06f, -0.02f, i * 0.15f, scale = 0.9f) }
        Reaction.PET -> List(6) { i -> Particle(if (i % 2 == 0) "❤️" else "💕", rx(0.6f), -0.05f, rx(0.9f), -0.75f, i * 0.09f) }
        Reaction.CUDDLE -> List(8) { i -> Particle(listOf("💞", "💖", "💗", "🥰")[i % 4], rx(0.5f), 0f, rx(1.1f), -0.85f, i * 0.07f, scale = 1.2f) }
        Reaction.PLAY -> listOf(
            Particle(emoji ?: "🎾", -0.75f, 0.2f, 0.75f, 0.2f, 0f, arc = 0.55f, scale = 1.1f, spin = 720f),
            Particle("⭐", 0f, -0.2f, 0.3f, -0.7f, 0.5f),
        )
        Reaction.TOY -> listOf(
            Particle(emoji ?: "🧸", 0.55f, -0.5f, 0.32f, 0.08f, 0f, arc = 0.2f, scale = 1.3f, spin = 360f),
            Particle("🎉", -0.3f, -0.2f, -0.5f, -0.7f, 0.4f),
            Particle("⭐", 0.3f, -0.3f, 0.6f, -0.75f, 0.5f),
        )
        Reaction.CLEAN -> List(7) { i -> Particle(if (i % 3 == 0) "🧼" else "✨", rx(1.0f), rx(0.4f), rx(1.2f), -0.6f, i * 0.08f) }
        Reaction.SLEEP -> List(3) { i -> Particle("💤", 0.2f, -0.2f, 0.45f + i * 0.05f, -0.85f, i * 0.22f, scale = 1f + i * 0.2f) }
        Reaction.TRAIN -> List(6) { i ->
            val a = (i / 6f) * 2f * PI.toFloat()
            Particle(if (i % 2 == 0) "⭐" else "🌟", 0f, -0.1f, cos(a) * 0.7f, sin(a) * 0.55f - 0.2f, 0.05f * i)
        }
        Reaction.GROW, Reaction.LEVEL_UP -> List(10) { i ->
            val a = (i / 10f) * 2f * PI.toFloat()
            Particle(listOf("🌟", "✨", "🎉", "💫")[i % 4], 0f, -0.1f, cos(a) * 0.85f, sin(a) * 0.65f - 0.15f, 0.03f * i, scale = 1.1f)
        }
        Reaction.TRICK -> List(5) { i -> Particle(if (i == 0) (emoji ?: "✨") else "✨", rx(0.4f), -0.3f, rx(1.2f), -0.85f, i * 0.1f) }
        Reaction.WALK -> List(8) { i -> Particle("🐾", -0.7f + i * 0.2f, 0.42f, -0.7f + i * 0.2f, 0.42f, i * 0.1f, scale = 0.7f) }
        Reaction.ADVENTURE -> listOf(
            Particle("🗺️", -0.6f, -0.5f, -0.3f, -0.8f, 0f, scale = 1.1f),
            Particle("🪙", 0.1f, 0f, 0.5f, -0.7f, 0.45f),
            Particle("💎", -0.1f, 0f, -0.5f, -0.65f, 0.55f),
            Particle("🪙", 0f, 0f, 0.1f, -0.9f, 0.62f),
        )
        Reaction.GIFT -> listOf(
            Particle("🎁", 0.45f, 0.1f, 0.45f, -0.25f, 0f, scale = 1.4f),
            Particle("✨", 0.45f, -0.2f, 0.75f, -0.7f, 0.4f),
            Particle("✨", 0.45f, -0.2f, 0.15f, -0.75f, 0.5f),
        )
    }
}

@Composable
fun AnimatedPet(
    species: Species,
    stage: Int,
    modifier: Modifier = Modifier,
    size: Dp = 150.dp,
    accessory: String? = null,
    sleeping: Boolean = false,
    reaction: Reaction? = null,
    reactionEmoji: String? = null,
    reactionNonce: Long = 0L,
    goldenAura: Boolean = false,
    showShadow: Boolean = true,
) {
    val density = LocalDensity.current
    val px = with(density) { size.toPx() }
    val stageScale = 0.6f + 0.1f * (stage.coerceIn(1, 5) - 1)
    val style = species.style
    val baseSpeed = when (style) {
        AnimStyle.HOP -> 520
        AnimStyle.BOUNCE -> 620
        AnimStyle.FLY -> 950
        AnimStyle.SWIM -> 1900
        AnimStyle.SLITHER -> 1500
        AnimStyle.GALLOP -> 720
        AnimStyle.PROWL -> 1700
        AnimStyle.MAJESTIC -> 2300
    }
    val speed = if (sleeping) baseSpeed * 3 else baseSpeed

    val inf = rememberInfiniteTransition(label = "pet")
    val bob by inf.animateFloat(0f, 1f, infiniteRepeatable(tween(speed, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "bob")
    val wiggle by inf.animateFloat(-1f, 1f, infiniteRepeatable(tween(speed * 2, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "wiggle")
    val wag by inf.animateFloat(-1f, 1f, infiniteRepeatable(tween(130, easing = LinearEasing), RepeatMode.Reverse), label = "wag")
    val breathe by inf.animateFloat(1f, 1.05f, infiniteRepeatable(tween(1700, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "breathe")
    val glow by inf.animateFloat(0.45f, 1f, infiniteRepeatable(tween(1800), RepeatMode.Reverse), label = "glow")
    val orbit by inf.animateFloat(0f, 360f, infiniteRepeatable(tween(6000, easing = LinearEasing), RepeatMode.Restart), label = "orbit")
    val zzz by inf.animateFloat(0f, 1f, infiniteRepeatable(tween(2400, easing = LinearEasing), RepeatMode.Restart), label = "zzz")

    // One-shot reaction animation (ignores the reaction that was already stored when the screen opened)
    val progress = remember { Animatable(0f) }
    val initialNonce = remember { reactionNonce }
    LaunchedEffect(reactionNonce) {
        if (reaction != null && reactionNonce != initialNonce) {
            progress.snapTo(0.001f)
            progress.animateTo(1f, tween(reaction.durationMs, easing = LinearEasing))
            progress.snapTo(0f)
        }
    }
    val p = progress.value
    val active = reaction != null && p > 0f && p < 1f
    val particles = remember(reactionNonce) { buildParticles(reaction, reactionEmoji, reactionNonce) }

    var tx = 0f
    var ty = 0f
    var rot = 0f
    var sx = 1f
    var sy = 1f
    if (sleeping) {
        sx = 1f + (breathe - 1f) * 0.6f
        sy = 0.93f + (breathe - 1f)
    } else {
        when (style) {
            AnimStyle.BOUNCE -> { ty = -bob * px * 0.05f; rot = wiggle * 3f }
            AnimStyle.PROWL -> { tx = wiggle * px * 0.04f; rot = wiggle * 2f; sx = breathe }
            AnimStyle.GALLOP -> { rot = wiggle * 5f; ty = -bob * px * 0.04f }
            AnimStyle.HOP -> { ty = -bob * bob * px * 0.11f; sy = 1f - (1f - bob) * 0.06f }
            AnimStyle.FLY -> { ty = -bob * px * 0.11f; sy = 1f + wag * 0.035f }
            AnimStyle.SWIM -> { tx = wiggle * px * 0.16f; ty = bob * px * 0.04f; rot = wiggle * 6f }
            AnimStyle.SLITHER -> { rot = wiggle * 7f; tx = wiggle * px * 0.05f }
            AnimStyle.MAJESTIC -> { sx = breathe; sy = breathe; ty = -bob * px * 0.02f }
        }
        val happyWag = active && (reaction == Reaction.PET || reaction == Reaction.EAT || reaction == Reaction.CUDDLE || reaction == Reaction.TOY)
        if (happyWag && (style == AnimStyle.BOUNCE || style == AnimStyle.PROWL)) rot = wag * 7f
    }
    if (active) {
        val pf = p
        when (reaction) {
            Reaction.PLAY -> {
                ty += -abs(sin(pf * PI * 3)).toFloat() * px * 0.22f
                rot += sin(pf * PI * 6).toFloat() * 10f
            }
            Reaction.TRICK -> rot = pf * 360f
            Reaction.WALK, Reaction.ADVENTURE -> {
                val ang = pf * 2.0 * PI
                tx = sin(ang).toFloat() * px * 0.62f
                if (cos(ang) > 0) sx = -sx
                ty += -abs(sin(pf * PI * 14)).toFloat() * px * 0.035f
            }
            Reaction.EAT -> sy *= 1f - 0.07f * abs(sin(pf * PI * 8)).toFloat()
            Reaction.DRINK -> rot += sin(pf * PI * 4).toFloat() * 4f
            Reaction.GROW, Reaction.LEVEL_UP -> {
                val pop = sin(pf * PI).toFloat()
                sx *= 1f + pop * 0.25f
                sy *= 1f + pop * 0.25f
                ty -= pop * px * 0.1f
            }
            Reaction.CUDDLE -> {
                sx *= 1f + 0.08f * sin(pf * PI).toFloat()
                rot += sin(pf * PI * 4).toFloat() * 6f
            }
            Reaction.TRAIN -> ty -= abs(sin(pf * PI * 2)).toFloat() * px * 0.15f
            Reaction.CLEAN -> rot += sin(pf * PI * 6).toFloat() * 5f
            Reaction.GIFT -> ty -= sin(pf * PI).toFloat() * px * 0.08f
            else -> {}
        }
    }

    val emojiSize = with(density) { (size * 0.6f * stageScale).toSp() }
    val accessoryItem = ItemCatalog.find(accessory)
    val hamsterWheel = active && reaction == Reaction.PLAY && species.group.playEmoji == "🎡"

    Box(modifier.size(size), contentAlignment = Alignment.Center) {
        // Aura glow (mythical creatures and unbreakable bonds)
        if (species.aura != null || goldenAura) {
            val glowColor = if (goldenAura && species.aura == null) Color(0xFFFFD25A) else Color(species.tint)
            Canvas(Modifier.fillMaxSize()) {
                drawCircle(
                    Brush.radialGradient(
                        listOf(glowColor.copy(alpha = 0.55f * glow), Color.Transparent),
                        center = center, radius = this.size.minDimension * 0.5f,
                    ),
                    radius = this.size.minDimension * 0.5f,
                )
            }
        }
        if (hamsterWheel) {
            Canvas(Modifier.size(size * 0.8f).graphicsLayer { rotationZ = p * 900f }) {
                val r = this.size.minDimension / 2f
                drawCircle(Color(0xFF8E8EA8), radius = r * 0.95f, style = Stroke(width = r * 0.08f))
                for (k in 0 until 8) {
                    val a = k * (PI / 4).toFloat()
                    drawLine(
                        Color(0xFFB5B5C8), center,
                        Offset(center.x + cos(a) * r * 0.9f, center.y + sin(a) * r * 0.9f), strokeWidth = r * 0.04f,
                    )
                }
            }
        }
        // Ground shadow
        if (showShadow && style != AnimStyle.SWIM && style != AnimStyle.FLY) {
            Box(
                Modifier
                    .align(Alignment.BottomCenter)
                    .offset(y = -(size * 0.08f))
                    .graphicsLayer {
                        translationX = tx
                        val k = 1f - (-ty / px).coerceIn(0f, 0.4f)
                        scaleX = k
                        scaleY = k
                    }
                    .size(width = size * 0.55f * stageScale, height = size * 0.09f)
                    .clip(CircleShape)
                    .background(Color.Black.copy(alpha = 0.16f))
            )
        }
        // The pet itself, with accessory riding along on the same layer
        Box(
            Modifier.graphicsLayer {
                translationX = tx
                translationY = ty
                rotationZ = rot
                scaleX = sx
                scaleY = sy
                alpha = if (sleeping) 0.92f else 1f
            },
            contentAlignment = Alignment.Center,
        ) {
            Text(species.emoji, fontSize = emojiSize)
            if (accessoryItem != null) {
                val accSize = with(density) { (size * 0.22f * stageScale).toSp() }
                val (ox, oy) = when (accessoryItem.anchor) {
                    Anchor.HEAD -> 0.05f to -0.3f
                    Anchor.FACE -> 0.0f to -0.06f
                    Anchor.NECK -> 0.0f to 0.2f
                }
                Text(
                    accessoryItem.emoji, fontSize = accSize,
                    modifier = Modifier.offset(x = size * ox * stageScale, y = size * oy * stageScale),
                )
            }
        }
        // Orbiting aura emoji for mythical creatures
        val auraEmoji = species.aura
        if (auraEmoji != null) {
            for (k in 0 until 2) {
                val a = Math.toRadians((orbit + k * 180f).toDouble())
                Text(
                    auraEmoji, fontSize = with(density) { (size * 0.12f).toSp() },
                    modifier = Modifier.graphicsLayer {
                        translationX = cos(a).toFloat() * px * 0.42f
                        translationY = sin(a).toFloat() * px * 0.18f - px * 0.05f
                        alpha = 0.9f
                    },
                )
            }
        }
        // Sleeping Zzz
        if (sleeping) {
            for (k in 0 until 2) {
                val t = (zzz + k * 0.5f) % 1f
                Text(
                    "💤", fontSize = with(density) { (size * (0.1f + t * 0.06f)).toSp() },
                    modifier = Modifier.graphicsLayer {
                        translationX = px * (0.18f + t * 0.15f)
                        translationY = -px * (0.15f + t * 0.3f)
                        alpha = (1f - t)
                    },
                )
            }
        }
        // Reaction particles
        if (active) {
            particles.forEach { pt ->
                val lp = ((p - pt.delay) / (1f - pt.delay).coerceAtLeast(0.2f)).coerceIn(0f, 1f)
                if (lp > 0f && lp < 1f) {
                    Text(
                        pt.emoji,
                        fontSize = with(density) { (size * 0.14f * pt.scale).toSp() },
                        modifier = Modifier.graphicsLayer {
                            translationX = lerpF(pt.sx, pt.ex, lp) * px * 0.5f
                            translationY = (lerpF(pt.sy, pt.ey, lp) - sin(lp * PI).toFloat() * pt.arc) * px * 0.5f
                            alpha = (sin(lp * PI).toFloat() * 1.4f).coerceIn(0f, 1f)
                            val sc = 0.7f + lp * 0.5f
                            scaleX = sc
                            scaleY = sc
                            rotationZ = pt.spin * lp
                        },
                    )
                }
            }
        }
    }
}

/** Small static portrait (cards, lists). */
@Composable
fun PetPortrait(species: Species, modifier: Modifier = Modifier, size: Dp = 56.dp, locked: Boolean = false) {
    Box(
        modifier
            .size(size)
            .clip(CircleShape)
            .background(Brush.radialGradient(listOf(Color(species.tint).copy(alpha = 0.55f), Color(species.tint).copy(alpha = 0.15f)))),
        contentAlignment = Alignment.Center,
    ) {
        val fs = with(LocalDensity.current) { (size * 0.58f).toSp() }
        if (locked) {
            Text(species.emoji, fontSize = fs, modifier = Modifier.silhouette(Color(0xFF3B3F5C)))
        } else {
            Text(species.emoji, fontSize = fs)
        }
    }
}
