package com.petverse.app.domain

import com.petverse.app.data.catalog.AchievementDef
import com.petverse.app.data.catalog.AchievementMetric
import com.petverse.app.data.catalog.MissionCatalog
import com.petverse.app.data.catalog.MissionDef
import com.petverse.app.data.catalog.MissionMetric
import com.petverse.app.data.catalog.MissionPeriod
import com.petverse.app.data.catalog.Species
import com.petverse.app.data.catalog.SpeciesCatalog
import com.petverse.app.data.db.ActivityEntity
import com.petverse.app.data.db.PetEntity
import com.petverse.app.data.db.PlayerEntity
import com.petverse.app.data.model.PetAction
import com.petverse.app.data.model.Personality
import com.petverse.app.data.model.Reaction
import com.petverse.app.util.Streaks
import com.petverse.app.util.Time
import kotlin.math.roundToInt
import kotlin.random.Random

/** Events produced by game logic and shown by the UI as toasts or celebration dialogs. */
sealed interface GameEvent {
    data class Toast(val text: String, val emoji: String = "✨") : GameEvent
    data class Celebration(val title: String, val message: String, val emoji: String) : GameEvent
    data class Problem(val text: String) : GameEvent
}

data class ActionOutcome(
    val success: Boolean,
    val events: List<GameEvent>,
    val reaction: Reaction? = null,
    val reactionEmoji: String? = null,
    val petId: Long? = null,
) {
    companion object {
        fun fail(text: String) = ActionOutcome(false, listOf(GameEvent.Problem(text)))
    }
}

object GameRules {
    const val MAX_PET_LEVEL = 50
    const val MAX_PLAYER_LEVEL = 60
    const val DAILY_LOYALTY_CAP = 60
    const val TRAINING_ENERGY = 15

    fun petXpForNext(level: Int) = 60 + (level - 1) * 30
    fun playerXpForNext(level: Int) = 80 + (level - 1) * 40

    // ---------------- Bond / loyalty ----------------
    val bondThresholds = listOf(0, 30, 100, 250, 500, 900)
    val bondNames = listOf("Stranger", "Familiar", "Friend", "Trusted Friend", "Best Friend", "Unbreakable Bond")
    val bondEmojis = listOf("🤍", "💛", "💚", "💙", "💜", "💖")
    val bondUnlocks = listOf(
        "Feeding, water, petting, play, toys, cleaning, rest & training",
        "Walks for walk-loving companions",
        "Show Trick and accessories",
        "Cuddles / Trust Moments",
        "Daily Adventures",
        "Daily Bond Gift and a golden aura",
    )

    fun bondLevel(points: Int): Int = bondThresholds.indexOfLast { points >= it } + 1
    fun bondName(level: Int) = bondNames[(level - 1).coerceIn(0, 5)]
    fun bondEmoji(level: Int) = bondEmojis[(level - 1).coerceIn(0, 5)]
    fun nextBondThreshold(level: Int): Int? = bondThresholds.getOrNull(level)

    // ---------------- Growth ----------------
    private val stageLevelReq = mapOf(2 to 3, 3 to 7, 4 to 12, 5 to 20)
    private val stageDpReq = mapOf(2 to 1, 3 to 2, 4 to 3, 5 to 4)
    fun levelForStage(stage: Int): Int = stageLevelReq[stage] ?: Int.MAX_VALUE
    fun dpForStage(stage: Int): Int = stageDpReq[stage] ?: Int.MAX_VALUE
    fun canGrow(pet: PetEntity): Boolean =
        pet.stage < 5 && pet.level >= levelForStage(pet.stage + 1) && pet.developmentPoints >= dpForStage(pet.stage + 1)

    // ---------------- Personality effects ----------------
    fun energyCost(action: PetAction, species: Species): Int {
        val base = if (action == PetAction.TRAIN) TRAINING_ENERGY else action.energyCost
        return if (species.personality == Personality.ENERGETIC) (base * 0.7f).roundToInt() else base
    }

    fun loyaltyFor(amount: Int, species: Species): Int =
        if (species.personality == Personality.LOYAL) (amount * 1.2f).roundToInt() else amount

    fun xpFor(amount: Int, species: Species): Int =
        if (species.personality == Personality.WISE) (amount * 1.1f).roundToInt() else amount

    // ---------------- Gentle needs drift (never harmful) ----------------
    /**
     * Needs drift slowly toward a comfortable floor and never below it.
     * Pets never starve, get sick or suffer — at worst they'd "love a snack".
     */
    fun applyDrift(pet: PetEntity, now: Long): PetEntity {
        val hours = (now - pet.lastDecayAt) / 3_600_000f
        if (hours < 0.5f) return pet
        fun down(v: Int, rate: Float, floor: Int): Int =
            if (v <= floor) v else (v - rate * hours).roundToInt().coerceAtLeast(floor)
        fun up(v: Int, rate: Float): Int = (v + rate * hours).roundToInt().coerceAtMost(100).coerceAtLeast(v)
        return pet.copy(
            fullness = down(pet.fullness, 4f, 40),
            hydration = down(pet.hydration, 5f, 40),
            cleanliness = down(pet.cleanliness, 2.5f, 45),
            happiness = down(pet.happiness, 2f, 50),
            energy = up(pet.energy, 6f),
            health = up(pet.health, 1f),
            lastDecayAt = now,
        )
    }

    fun mood(pet: PetEntity, now: Long): Pair<String, String> = when {
        pet.sleepUntil > now -> "💤" to "Sleeping peacefully…"
        pet.fullness < 50 -> "🥣" to "${pet.name} would love a snack!"
        pet.hydration < 50 -> "💧" to "A sip of fresh water would be lovely."
        pet.energy < 30 -> "🥱" to "Feeling a little sleepy…"
        pet.cleanliness < 55 -> "🧽" to "The habitat could use a tidy-up."
        pet.happiness >= 85 -> "🥰" to "Feeling joyful and loved!"
        pet.happiness >= 65 -> "😊" to "Content and curious."
        else -> "🙂" to "Would love to spend time with you."
    }

    // ---------------- Skills ----------------
    fun parseProgress(s: String): Map<String, Int> =
        if (s.isBlank()) emptyMap() else s.split(";").mapNotNull { part ->
            val kv = part.split("=")
            if (kv.size == 2) kv[0] to (kv[1].toIntOrNull() ?: 0) else null
        }.toMap()

    fun encodeProgress(map: Map<String, Int>): String = map.entries.joinToString(";") { "${it.key}=${it.value}" }

    fun learnedSkills(pet: PetEntity): Set<String> =
        if (pet.learnedSkills.isBlank()) emptySet() else pet.learnedSkills.split(",").toSet()
}

// ------------------------------------------------------------------
// Aggregated stats (used for achievements, statistics and profile)
// ------------------------------------------------------------------

data class GameStats(
    val totalHabits: Int = 0,
    val currentStreak: Int = 0,
    val bestStreak: Int = 0,
    val petsOwned: Int = 0,
    val maxRarityTier: Int = 0,
    val maxBond: Int = 0,
    val maxStage: Int = 0,
    val playerLevel: Int = 1,
    val loginStreak: Int = 0,
    val counts: Map<String, Int> = emptyMap(),
) {
    fun count(types: Set<String>): Int = types.sumOf { counts[it] ?: 0 }
}

object StatsCalculator {
    fun compute(
        player: PlayerEntity?,
        pets: List<PetEntity>,
        logDays: Collection<Long>,
        totalHabits: Int,
        counts: Map<String, Int>,
        today: Long,
    ): GameStats {
        val daySet = logDays.toSet()
        return GameStats(
            totalHabits = totalHabits,
            currentStreak = Streaks.current(daySet, today),
            bestStreak = Streaks.best(daySet),
            petsOwned = pets.size,
            maxRarityTier = pets.maxOfOrNull { SpeciesCatalog.byId(it.speciesId).rarity.tier } ?: 0,
            maxBond = pets.maxOfOrNull { GameRules.bondLevel(it.loyaltyPoints) } ?: 0,
            maxStage = pets.maxOfOrNull { it.stage } ?: 0,
            playerLevel = player?.level ?: 1,
            loginStreak = player?.loginStreak ?: 0,
            counts = counts,
        )
    }

    fun achievementProgress(def: AchievementDef, s: GameStats): Int = when (def.metric) {
        AchievementMetric.TOTAL_HABITS -> s.totalHabits
        AchievementMetric.BEST_STREAK -> maxOf(s.bestStreak, s.currentStreak)
        AchievementMetric.PETS_OWNED -> s.petsOwned
        AchievementMetric.MAX_RARITY -> s.maxRarityTier
        AchievementMetric.MAX_BOND -> s.maxBond
        AchievementMetric.MAX_STAGE -> s.maxStage
        AchievementMetric.PLAYER_LEVEL -> s.playerLevel
        AchievementMetric.LOGIN_STREAK -> s.loginStreak
        AchievementMetric.ACTIVITY -> s.count(def.types)
    }
}

// ------------------------------------------------------------------
// Missions
// ------------------------------------------------------------------

object MissionEngine {
    fun periodStart(period: MissionPeriod, today: Long): Long = when (period) {
        MissionPeriod.DAILY -> today
        MissionPeriod.WEEKLY -> Time.weekStart(today)
        MissionPeriod.MONTHLY -> Time.monthStart(today)
    }

    fun claimKey(def: MissionDef, today: Long): String = "mission:${def.id}@${periodStart(def.period, today)}"

    fun dailyMissions(today: Long, hasWalker: Boolean): List<MissionDef> {
        val picked = MissionCatalog.dailyPool.shuffled(Random(today))
            .filter { hasWalker || it.id != "d_walk" }
            .take(4)
        return listOf(MissionCatalog.dailyCore) + picked
    }

    fun missionsFor(period: MissionPeriod, today: Long, hasWalker: Boolean): List<MissionDef> = when (period) {
        MissionPeriod.DAILY -> dailyMissions(today, hasWalker)
        MissionPeriod.WEEKLY -> MissionCatalog.weekly
        MissionPeriod.MONTHLY -> MissionCatalog.monthly
    }

    fun progress(def: MissionDef, activities: List<ActivityEntity>, logDays: Set<Long>, today: Long): Int {
        val start = periodStart(def.period, today)
        return when (def.metric) {
            MissionMetric.ACTIVITY -> activities.filter { it.epochDay >= start && it.type in def.types }.sumOf { it.amount }
            MissionMetric.HABIT_STREAK -> Streaks.current(logDays, today)
        }
    }

    fun hasWalker(pets: List<PetEntity>): Boolean = pets.any {
        SpeciesCatalog.byId(it.speciesId).walkable && GameRules.bondLevel(it.loyaltyPoints) >= PetAction.WALK.minBond
    }
}
