package com.petverse.app.ui.screens

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavHostController
import com.petverse.app.data.catalog.Species
import com.petverse.app.data.catalog.SpeciesCatalog
import com.petverse.app.data.db.PetEntity
import com.petverse.app.data.model.AnimStyle
import com.petverse.app.data.model.EnvironmentId
import com.petverse.app.domain.GameRules
import com.petverse.app.ui.GameViewModel
import com.petverse.app.ui.components.AnimatedPet
import com.petverse.app.ui.components.BondBadge
import com.petverse.app.ui.components.EmptyState
import com.petverse.app.ui.components.EnvironmentBackdrop
import com.petverse.app.ui.components.GradientButton
import com.petverse.app.ui.components.PVCard
import com.petverse.app.ui.components.PetPortrait
import com.petverse.app.ui.components.Pill
import com.petverse.app.ui.components.ScreenHeader
import com.petverse.app.ui.components.rememberNow
import com.petverse.app.ui.navigation.Routes
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.random.Random

// ------------------------------------------------------------------
// 12. Virtual World & Animal Sanctuary
// ------------------------------------------------------------------

@Composable
fun WorldScreen(vm: GameViewModel, nav: NavHostController) {
    val player by vm.player.collectAsStateWithLifecycle()
    val pets by vm.pets.collectAsStateWithLifecycle()
    val p = player ?: return
    val unlockedCount = EnvironmentId.entries.count { p.level >= it.unlockLevel }

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 24.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        item { ScreenHeader("PetVerse World", subtitle = "$unlockedCount of ${EnvironmentId.entries.size} areas unlocked • Level up to explore more") }
        items(EnvironmentId.entries.toList(), key = { it.name }) { env ->
            val unlocked = p.level >= env.unlockLevel
            val residents = pets.filter { SpeciesCatalog.byId(it.speciesId).habitat == env }
            val speciesHere = SpeciesCatalog.all.count { it.habitat == env }
            EnvironmentBackdrop(
                env,
                Modifier
                    .fillMaxWidth()
                    .height(150.dp)
                    .clickable { if (unlocked) nav.navigate(Routes.env(env.name)) else vm.problem("${env.title} unlocks at Trainer Level ${env.unlockLevel}.") },
            ) {
                Row(
                    Modifier.align(Alignment.BottomCenter).padding(bottom = 10.dp),
                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                ) {
                    residents.take(6).forEach { pet ->
                        Text(SpeciesCatalog.byId(pet.speciesId).emoji, fontSize = 30.sp)
                    }
                }
                Column(
                    Modifier
                        .align(Alignment.TopStart)
                        .padding(12.dp)
                        .clip(RoundedCornerShape(16.dp))
                        .background(Color.White.copy(alpha = 0.82f))
                        .padding(horizontal = 12.dp, vertical = 6.dp),
                ) {
                    Text("${env.emoji} ${env.title}", style = MaterialTheme.typography.titleMedium, color = Color(0xFF1B1A2E))
                    Text(
                        "${residents.size} resident${if (residents.size == 1) "" else "s"} • $speciesHere species",
                        style = MaterialTheme.typography.labelSmall, color = Color(0xFF4A4868),
                    )
                }
                if (!unlocked) {
                    Box(
                        Modifier.fillMaxSize().background(Color(0xFF0E1020).copy(alpha = 0.6f)),
                        contentAlignment = Alignment.Center,
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("🔒", fontSize = 34.sp)
                            Text("Unlocks at Level ${env.unlockLevel}", style = MaterialTheme.typography.titleSmall, color = Color.White)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun EnvironmentScreen(vm: GameViewModel, nav: NavHostController, envId: String) {
    val pets by vm.pets.collectAsStateWithLifecycle()
    val player by vm.player.collectAsStateWithLifecycle()
    val now by rememberNow(5000)
    val env = runCatching { EnvironmentId.valueOf(envId) }.getOrDefault(EnvironmentId.HOME)
    val residents = pets.filter { SpeciesCatalog.byId(it.speciesId).habitat == env }
    val species = SpeciesCatalog.all.filter { it.habitat == env }
    val p = player ?: return
    val unlocked = p.level >= env.unlockLevel

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 24.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        item { ScreenHeader(env.title, onBack = { nav.popBackStack() }, subtitle = env.description) }
        item {
            EnvironmentBackdrop(env, Modifier.fillMaxWidth().height(360.dp)) {
                if (!unlocked) {
                    Box(Modifier.fillMaxSize().background(Color(0xFF0E1020).copy(alpha = 0.6f)), contentAlignment = Alignment.Center) {
                        Text("🔒 Unlocks at Level ${env.unlockLevel}", style = MaterialTheme.typography.titleMedium, color = Color.White)
                    }
                } else if (residents.isEmpty()) {
                    Text(
                        "No residents yet",
                        style = MaterialTheme.typography.titleMedium, color = Color(0xFF1B1A2E),
                        modifier = Modifier
                            .align(Alignment.Center)
                            .clip(RoundedCornerShape(16.dp))
                            .background(Color.White.copy(alpha = 0.8f))
                            .padding(horizontal = 14.dp, vertical = 8.dp),
                    )
                } else {
                    BoxWithConstraints(Modifier.fillMaxSize()) {
                        val w = maxWidth
                        val h = maxHeight
                        residents.forEachIndexed { i, pet ->
                            RoamingPet(pet, SpeciesCatalog.byId(pet.speciesId), w, h, i, now) {
                                nav.navigate(Routes.pet(pet.id))
                            }
                        }
                    }
                }
            }
        }
        if (env == EnvironmentId.ANIMAL_SANCTUARY || species.any { it.wild }) {
            item {
                PVCard {
                    Text("🌿 About sanctuary animals", style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(4.dp))
                    Text(
                        "Wild and potentially dangerous animals in PetVerse live in protected virtual reserves. As their keeper you provide meals, enrichment and calm, cooperative training — they are never treated as household pets.",
                        style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
        }
        if (residents.isNotEmpty()) {
            item { Text("Residents • tap to visit", style = MaterialTheme.typography.titleLarge) }
            items(residents, key = { it.id }) { pet ->
                val sp = SpeciesCatalog.byId(pet.speciesId)
                PVCard(onClick = { nav.navigate(Routes.pet(pet.id)) }) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        PetPortrait(sp)
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(pet.name, style = MaterialTheme.typography.titleMedium)
                            Text("${sp.name} • Lv ${pet.level} • ${sp.stageName(pet.stage)}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        BondBadge(pet.loyaltyPoints)
                    }
                }
            }
        }
        item {
            Text("Species that live here", style = MaterialTheme.typography.titleLarge)
            Spacer(Modifier.height(8.dp))
            val ownedIds = pets.map { it.speciesId }.toSet()
            species.chunked(5).forEach { row ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    row.forEach { sp ->
                        Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                            PetPortrait(sp, size = 52.dp, locked = sp.id !in ownedIds && p.level < sp.minLevel)
                            Text(
                                if (sp.id in ownedIds) "✓" else "Lv ${sp.minLevel}",
                                style = MaterialTheme.typography.labelSmall,
                                color = if (sp.id in ownedIds) MaterialTheme.colorScheme.tertiary else MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                    }
                    repeat(5 - row.size) { Spacer(Modifier.weight(1f)) }
                }
                Spacer(Modifier.height(8.dp))
            }
            Spacer(Modifier.height(6.dp))
            GradientButton("Open Collection Book", onClick = { nav.navigate(Routes.COLLECTION) }, modifier = Modifier.fillMaxWidth(), emoji = "📘")
        }
        if (residents.isEmpty() && unlocked) {
            item {
                EmptyState("🔭", "Waiting for residents", "Discover species from this area in the Collection Book to see them roam here.")
            }
        }
    }
}

/** A pet that wanders around the environment on its own. */
@Composable
private fun RoamingPet(
    pet: PetEntity,
    sp: Species,
    areaW: Dp,
    areaH: Dp,
    index: Int,
    now: Long,
    onClick: () -> Unit,
) {
    val petSize = 96.dp
    val (yMin, yMax) = when (sp.style) {
        AnimStyle.FLY -> 0.08f to 0.45f
        AnimStyle.SWIM -> 0.15f to 0.7f
        else -> 0.45f to 0.68f
    }
    val x = remember { Animatable(0.1f + (index % 4) * 0.2f) }
    val y = remember { Animatable(lerpRange(yMin, yMax, 0.5f)) }
    var facingRight by remember { mutableStateOf(false) }
    val sleeping = pet.sleepUntil > now
    LaunchedEffect(pet.id, sleeping) {
        val rnd = Random(pet.id * 31 + index)
        while (!sleeping) {
            val tx = rnd.nextFloat() * 0.78f
            val ty = lerpRange(yMin, yMax, rnd.nextFloat())
            facingRight = tx > x.value
            val dur = 2200 + rnd.nextInt(2200)
            val moveX = launch { x.animateTo(tx, tween(dur, easing = FastOutSlowInEasing)) }
            y.animateTo(ty, tween(dur, easing = FastOutSlowInEasing))
            moveX.join()
            delay(600L + rnd.nextInt(1800))
        }
    }
    Column(
        Modifier
            .offset(x = (areaW - petSize) * x.value, y = (areaH - petSize) * y.value)
            .clickable(onClick = onClick),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Box(Modifier.graphicsLayer { scaleX = if (facingRight) -1f else 1f }) {
            AnimatedPet(
                sp, pet.stage, size = petSize, accessory = pet.accessory, sleeping = sleeping,
                goldenAura = GameRules.bondLevel(pet.loyaltyPoints) >= 6,
            )
        }
        Pill(pet.name, color = Color(0xFF1B1A2E), filled = true)
    }
}

private fun lerpRange(a: Float, b: Float, t: Float) = a + (b - a) * t
