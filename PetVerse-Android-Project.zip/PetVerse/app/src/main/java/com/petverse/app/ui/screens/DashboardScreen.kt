package com.petverse.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavHostController
import com.petverse.app.data.catalog.LoginRewards
import com.petverse.app.data.catalog.SpeciesCatalog
import com.petverse.app.data.model.PetAction
import com.petverse.app.domain.GameRules
import com.petverse.app.domain.MissionEngine
import com.petverse.app.ui.GameViewModel
import com.petverse.app.ui.components.AnimatedPet
import com.petverse.app.ui.components.BondBadge
import com.petverse.app.ui.components.CurrencyChip
import com.petverse.app.ui.components.EnvironmentBackdrop
import com.petverse.app.ui.components.GradientButton
import com.petverse.app.ui.components.PVCard
import com.petverse.app.ui.components.ProgressRing
import com.petverse.app.ui.components.ProgressTrack
import com.petverse.app.ui.components.SectionTitle
import com.petverse.app.ui.components.rememberNow
import com.petverse.app.ui.navigation.Routes
import com.petverse.app.ui.navigation.goTab
import com.petverse.app.ui.theme.XpColor
import com.petverse.app.util.Time

@Composable
fun DashboardScreen(vm: GameViewModel, nav: NavHostController) {
    val player by vm.player.collectAsStateWithLifecycle()
    val pets by vm.pets.collectAsStateWithLifecycle()
    val habits by vm.habits.collectAsStateWithLifecycle()
    val logs by vm.logs.collectAsStateWithLifecycle()
    val inventory by vm.inventory.collectAsStateWithLifecycle()
    val activities by vm.activities.collectAsStateWithLifecycle()
    val claims by vm.claims.collectAsStateWithLifecycle()
    val stats by vm.stats.collectAsStateWithLifecycle()
    val reaction by vm.reaction.collectAsStateWithLifecycle()
    val now by rememberNow(5000)
    val p = player ?: return

    val today = Time.today()
    val doneIds = logs.filter { it.epochDay == today }.map { it.habitId }.toSet()
    val doneCount = habits.count { it.id in doneIds }
    val partner = pets.firstOrNull { it.id == p.partnerPetId } ?: pets.firstOrNull()
    val logDays = logs.map { it.epochDay }.toSet()

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        // ---------------- Header ----------------
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier
                        .size(52.dp)
                        .clip(CircleShape)
                        .background(Brush.linearGradient(listOf(Color(0xFF8B6CFF), Color(0xFFFF8BC2))))
                        .clickable { nav.goTab(Routes.PROFILE) },
                    contentAlignment = Alignment.Center,
                ) { Text(p.avatar, fontSize = 28.sp) }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text("${Time.greeting()},", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(p.name, style = MaterialTheme.typography.headlineSmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
                ProgressRing(p.xp / GameRules.playerXpForNext(p.level).toFloat(), size = 52.dp, stroke = 5.dp, color = XpColor) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("LV", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text("${p.level}", style = MaterialTheme.typography.titleMedium)
                    }
                }
            }
            Spacer(Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                CurrencyChip("🪙", p.coins) { nav.navigate(Routes.SHOP) }
                CurrencyChip("🥣", inventory["pet_food"] ?: 0) { nav.navigate(Routes.SHOP) }
                CurrencyChip("🎯", p.trainingPoints)
                CurrencyChip("🔥", stats.currentStreak) { nav.navigate(Routes.STATS) }
            }
        }

        // ---------------- Daily login reward ----------------
        if (p.lastLoginRewardDay != today) {
            item {
                val reward = LoginRewards.forStreak(p.loginStreak)
                PVCard(
                    brush = Brush.horizontalGradient(listOf(Color(0xFFFFB547), Color(0xFFFF7A9A))),
                    onClick = { vm.claimLoginReward() },
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("🎁", fontSize = 40.sp)
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text("Daily login reward • Day ${reward.day}", style = MaterialTheme.typography.titleMedium, color = Color.White)
                            Text("${reward.emoji} ${reward.label} — tap to claim", style = MaterialTheme.typography.bodyMedium, color = Color.White.copy(alpha = 0.9f))
                        }
                        Text("${p.loginStreak}🔥", style = MaterialTheme.typography.titleMedium, color = Color.White)
                    }
                }
            }
        }

        // ---------------- Partner pet ----------------
        item {
            if (partner == null) {
                PVCard(onClick = { nav.navigate(Routes.COLLECTION) }) {
                    Text("🐾 Adopt your first companion", style = MaterialTheme.typography.titleMedium)
                }
            } else {
                val sp = SpeciesCatalog.byId(partner.speciesId)
                val (moodEmoji, moodText) = GameRules.mood(partner, now)
                val r = reaction?.takeIf { it.petId == partner.id }
                PVCard(padding = PaddingValues(0.dp)) {
                    EnvironmentBackdrop(
                        sp.habitat,
                        Modifier
                            .fillMaxWidth()
                            .height(230.dp)
                            .clickable { nav.navigate(Routes.pet(partner.id)) },
                        shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp),
                    ) {
                        AnimatedPet(
                            sp, partner.stage,
                            modifier = Modifier.align(Alignment.Center).padding(top = 30.dp),
                            size = 160.dp,
                            accessory = partner.accessory,
                            sleeping = partner.sleepUntil > now,
                            reaction = r?.reaction,
                            reactionEmoji = r?.emoji,
                            reactionNonce = r?.nonce ?: 0L,
                            goldenAura = GameRules.bondLevel(partner.loyaltyPoints) >= 6,
                        )
                        Column(Modifier.align(Alignment.TopStart).padding(14.dp)) {
                            Text(
                                partner.name, style = MaterialTheme.typography.headlineSmall, color = Color(0xFF1B1A2E),
                                modifier = Modifier
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(Color.White.copy(alpha = 0.75f))
                                    .padding(horizontal = 10.dp, vertical = 2.dp),
                            )
                            Spacer(Modifier.height(4.dp))
                            Text(
                                "Lv ${partner.level} • ${sp.stageName(partner.stage)}",
                                style = MaterialTheme.typography.labelMedium, color = Color(0xFF1B1A2E),
                                modifier = Modifier
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(Color.White.copy(alpha = 0.6f))
                                    .padding(horizontal = 8.dp, vertical = 2.dp),
                            )
                        }
                        BondBadge(partner.loyaltyPoints, Modifier.align(Alignment.TopEnd).padding(14.dp))
                        Row(
                            Modifier
                                .align(Alignment.BottomCenter)
                                .padding(10.dp)
                                .clip(RoundedCornerShape(50))
                                .background(Color.White.copy(alpha = 0.85f))
                                .padding(horizontal = 12.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Text(moodEmoji, fontSize = 14.sp)
                            Spacer(Modifier.width(6.dp))
                            Text(moodText, style = MaterialTheme.typography.labelMedium, color = Color(0xFF1B1A2E), maxLines = 1)
                        }
                    }
                    Column(Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("XP", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Spacer(Modifier.width(8.dp))
                            ProgressTrack(
                                partner.xp / GameRules.petXpForNext(partner.level).toFloat(), XpColor,
                                Modifier.weight(1f).height(8.dp),
                            )
                            Spacer(Modifier.width(8.dp))
                            Text("${partner.xp}/${GameRules.petXpForNext(partner.level)}", style = MaterialTheme.typography.labelMedium)
                        }
                        if (GameRules.canGrow(partner)) {
                            Spacer(Modifier.height(8.dp))
                            Text("🌱 ${partner.name} is ready to grow! Open their page.", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.tertiary)
                        }
                        Spacer(Modifier.height(12.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            QuickAction("🥣", "Feed", Modifier.weight(1f)) { vm.action(partner.id, PetAction.FEED, "pet_food") }
                            QuickAction("🤚", if (sp.wild) "Observe" else "Pet", Modifier.weight(1f)) { vm.action(partner.id, PetAction.PET) }
                            QuickAction(sp.group.playEmoji, "Play", Modifier.weight(1f)) { vm.action(partner.id, PetAction.PLAY) }
                            QuickAction("➡️", "Open", Modifier.weight(1f)) { nav.navigate(Routes.pet(partner.id)) }
                        }
                    }
                }
            }
        }

        // ---------------- Today's habits ----------------
        item {
            PVCard {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    ProgressRing(
                        if (habits.isEmpty()) 0f else doneCount / habits.size.toFloat(),
                        size = 64.dp, stroke = 7.dp, color = MaterialTheme.colorScheme.tertiary,
                    ) {
                        Text("$doneCount/${habits.size}", style = MaterialTheme.typography.titleSmall)
                    }
                    Spacer(Modifier.width(14.dp))
                    Column(Modifier.weight(1f)) {
                        Text("Today's habits", style = MaterialTheme.typography.titleLarge)
                        Text(
                            when {
                                habits.isEmpty() -> "Add habits to start growing your pets"
                                doneCount == habits.size -> "All done — your pets are proud! 🌟"
                                doneCount >= 5 -> "Habit Power unlocked today ⚡"
                                else -> "${(5 - doneCount).coerceAtLeast(0)} more for Habit Power ⚡"
                            },
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
                Spacer(Modifier.height(10.dp))
                habits.sortedBy { it.id in doneIds }.take(4).forEach { h ->
                    HabitRow(h, done = h.id in doneIds, streak = habitStreak(h.id, logs, today), compact = true) {
                        vm.completeHabit(h.id)
                    }
                    Spacer(Modifier.height(6.dp))
                }
                Spacer(Modifier.height(6.dp))
                GradientButton(
                    "Open Habit Tracker", onClick = { nav.goTab(Routes.HABITS) },
                    modifier = Modifier.fillMaxWidth(), emoji = "✅",
                    colors = listOf(Color(0xFF2ED3A5), Color(0xFF12A383)),
                )
            }
        }

        // ---------------- Missions preview ----------------
        item {
            val missions = MissionEngine.dailyMissions(today, MissionEngine.hasWalker(pets))
            PVCard {
                SectionTitle("Daily missions", action = "View all", onAction = { nav.navigate(Routes.MISSIONS) })
                Spacer(Modifier.height(8.dp))
                missions.take(3).forEach { m ->
                    val prog = MissionEngine.progress(m, activities, logDays, today)
                    val claimed = MissionEngine.claimKey(m, today) in claims
                    MissionRow(m, prog, claimed) { vm.claimMission(m) }
                    Spacer(Modifier.height(8.dp))
                }
            }
        }

        // ---------------- Explore grid ----------------
        item {
            SectionTitle("Explore")
            Spacer(Modifier.height(8.dp))
            val tiles = listOf(
                Triple("📘", "Collection", Routes.COLLECTION),
                Triple("🛍️", "Pet Shop", Routes.SHOP),
                Triple("🎯", "Missions", Routes.MISSIONS),
                Triple("🏅", "Badges", Routes.ACHIEVEMENTS),
                Triple("🏞️", "Sanctuary", Routes.env("ANIMAL_SANCTUARY")),
                Triple("🏋️", "Training", partner?.let { Routes.train(it.id) } ?: Routes.PETS),
                Triple("📊", "Statistics", Routes.STATS),
                Triple("⚙️", "Settings", Routes.SETTINGS),
            )
            tiles.chunked(4).forEach { row ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    row.forEach { (emoji, label, route) ->
                        Column(
                            Modifier
                                .weight(1f)
                                .aspectRatio(0.9f)
                                .clip(RoundedCornerShape(20.dp))
                                .background(MaterialTheme.colorScheme.surface)
                                .clickable { nav.navigate(route) }
                                .padding(6.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center,
                        ) {
                            Text(emoji, fontSize = 28.sp)
                            Spacer(Modifier.height(4.dp))
                            Text(label, style = MaterialTheme.typography.labelMedium, textAlign = TextAlign.Center, maxLines = 1)
                        }
                    }
                }
                Spacer(Modifier.height(10.dp))
            }
        }
    }
}

@Composable
internal fun QuickAction(emoji: String, label: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Column(
        modifier
            .clip(RoundedCornerShape(16.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant)
            .clickable(onClick = onClick)
            .padding(vertical = 10.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text(emoji, fontSize = 20.sp)
        Text(label, style = MaterialTheme.typography.labelMedium)
    }
}
