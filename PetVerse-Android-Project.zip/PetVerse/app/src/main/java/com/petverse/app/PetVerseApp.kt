package com.petverse.app

import android.app.Application
import android.content.Context
import com.petverse.app.data.db.AppDatabase
import com.petverse.app.data.repo.GameRepository
import com.petverse.app.notifications.NotificationHelper

class PetVerseApp : Application() {
    lateinit var container: AppContainer
        private set

    override fun onCreate() {
        super.onCreate()
        container = AppContainer(this)
        NotificationHelper.createChannel(this)
    }
}

/** Simple manual dependency container (no DI framework needed). */
class AppContainer(context: Context) {
    val database: AppDatabase = AppDatabase.get(context)
    val repository: GameRepository = GameRepository(database)
}
