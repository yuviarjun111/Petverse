package com.petverse.app.data.db

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Index
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.Update
import androidx.room.Upsert
import kotlinx.coroutines.flow.Flow

// ------------------------------------------------------------------
// Entities
// ------------------------------------------------------------------

@Entity(tableName = "player")
data class PlayerEntity(
    @PrimaryKey val id: Int = 1,
    val name: String = "Trainer",
    val avatar: String = "🧑",
    val level: Int = 1,
    val xp: Int = 0,
    val coins: Int = 100,
    val trainingPoints: Int = 3,
    val partnerPetId: Long? = null,
    val onboarded: Boolean = false,
    val themeMode: Int = 0, // 0 = system, 1 = light, 2 = dark
    val notificationsEnabled: Boolean = true,
    val reminderHour: Int = 19,
    val reminderMinute: Int = 0,
    val hapticsEnabled: Boolean = true,
    val loginStreak: Int = 0,
    val lastLoginDay: Long = -1,
    val lastLoginRewardDay: Long = -1,
    val totalCoinsEarned: Int = 0,
    val createdAt: Long = System.currentTimeMillis(),
)

@Entity(tableName = "pets", indices = [Index(value = ["speciesId"], unique = true)])
data class PetEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val speciesId: String,
    val name: String,
    val level: Int = 1,
    val xp: Int = 0,
    val stage: Int = 1,
    val developmentPoints: Int = 0,
    val happiness: Int = 75,
    val health: Int = 90,
    val energy: Int = 85,
    val fullness: Int = 70,
    val hydration: Int = 70,
    val cleanliness: Int = 85,
    val intelligence: Int = 5,
    val strength: Int = 5,
    val friendship: Int = 0,
    val loyaltyPoints: Int = 0,
    val learnedSkills: String = "",
    val skillProgress: String = "",
    val accessory: String? = null,
    val sleepUntil: Long = 0,
    val lastDecayAt: Long = System.currentTimeMillis(),
    val adoptedAt: Long = System.currentTimeMillis(),
    val dailyLoyaltyDay: Long = 0,
    val dailyLoyaltyGained: Int = 0,
    val lastAdventureDay: Long = 0,
    val lastGiftDay: Long = 0,
)

@Entity(tableName = "habits")
data class HabitEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val emoji: String,
    val category: String,
    val difficulty: String,
    val archived: Boolean = false,
    val sortOrder: Int = 0,
    val presetId: String? = null,
    val createdAt: Long = System.currentTimeMillis(),
)

@Entity(
    tableName = "habit_logs",
    indices = [Index(value = ["habitId", "epochDay"], unique = true), Index(value = ["epochDay"])]
)
data class HabitLogEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val habitId: Long,
    val epochDay: Long,
    val completedAt: Long,
)

@Entity(tableName = "inventory")
data class InventoryEntity(
    @PrimaryKey val itemId: String,
    val quantity: Int,
)

@Entity(tableName = "activity", indices = [Index(value = ["type", "epochDay"])])
data class ActivityEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val type: String,
    val petId: Long? = null,
    val epochDay: Long,
    val timestamp: Long,
    val amount: Int = 1,
)

@Entity(tableName = "claims")
data class ClaimEntity(
    @PrimaryKey val claimKey: String,
    val claimedAt: Long,
)

@Entity(tableName = "achievements")
data class AchievementEntity(
    @PrimaryKey val id: String,
    val unlockedAt: Long,
)

data class TypeCount(val type: String, val total: Int)

// ------------------------------------------------------------------
// DAOs
// ------------------------------------------------------------------

@Dao
interface PlayerDao {
    @Query("SELECT * FROM player WHERE id = 1")
    fun observe(): Flow<PlayerEntity?>

    @Query("SELECT * FROM player WHERE id = 1")
    suspend fun get(): PlayerEntity?

    @Upsert
    suspend fun upsert(player: PlayerEntity)
}

@Dao
interface PetDao {
    @Query("SELECT * FROM pets ORDER BY adoptedAt ASC")
    fun observeAll(): Flow<List<PetEntity>>

    @Query("SELECT * FROM pets ORDER BY adoptedAt ASC")
    suspend fun getAll(): List<PetEntity>

    @Query("SELECT * FROM pets WHERE id = :id")
    suspend fun get(id: Long): PetEntity?

    @Query("SELECT * FROM pets WHERE speciesId = :speciesId LIMIT 1")
    suspend fun getBySpecies(speciesId: String): PetEntity?

    @Insert
    suspend fun insert(pet: PetEntity): Long

    @Update
    suspend fun update(pet: PetEntity)

    @Update
    suspend fun updateAll(pets: List<PetEntity>)
}

@Dao
interface HabitDao {
    @Query("SELECT * FROM habits WHERE archived = 0 ORDER BY sortOrder ASC, id ASC")
    fun observeActive(): Flow<List<HabitEntity>>

    @Query("SELECT * FROM habits")
    fun observeAllIncludingArchived(): Flow<List<HabitEntity>>

    @Query("SELECT * FROM habits WHERE id = :id")
    suspend fun get(id: Long): HabitEntity?

    @Query("SELECT COUNT(*) FROM habits WHERE archived = 0")
    suspend fun countActive(): Int

    @Query("SELECT COALESCE(MAX(sortOrder), 0) FROM habits")
    suspend fun maxSort(): Int

    @Insert
    suspend fun insert(habit: HabitEntity): Long

    @Update
    suspend fun update(habit: HabitEntity)

    @Query("SELECT * FROM habit_logs ORDER BY epochDay ASC")
    fun observeLogs(): Flow<List<HabitLogEntity>>

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertLog(log: HabitLogEntity): Long

    @Query(
        "SELECT COUNT(*) FROM habit_logs l INNER JOIN habits h ON h.id = l.habitId " +
            "WHERE l.epochDay = :day AND h.archived = 0"
    )
    suspend fun countActiveLogsForDay(day: Long): Int

    @Query("SELECT COUNT(*) FROM habit_logs WHERE epochDay = :day")
    suspend fun countLogsForDay(day: Long): Int

    @Query("SELECT DISTINCT epochDay FROM habit_logs")
    suspend fun logDays(): List<Long>

    @Query("SELECT COUNT(*) FROM habit_logs")
    suspend fun countLogs(): Int
}

@Dao
interface InventoryDao {
    @Query("SELECT * FROM inventory")
    fun observeAll(): Flow<List<InventoryEntity>>

    @Query("SELECT quantity FROM inventory WHERE itemId = :itemId")
    suspend fun quantity(itemId: String): Int?

    @Upsert
    suspend fun upsert(item: InventoryEntity)
}

@Dao
interface ActivityDao {
    @Insert
    suspend fun insert(activity: ActivityEntity)

    @Query("SELECT * FROM activity WHERE epochDay >= :day")
    fun observeSince(day: Long): Flow<List<ActivityEntity>>

    @Query("SELECT * FROM activity WHERE epochDay >= :day")
    suspend fun getSince(day: Long): List<ActivityEntity>

    @Query("SELECT type, SUM(amount) AS total FROM activity GROUP BY type")
    fun observeCounts(): Flow<List<TypeCount>>

    @Query("SELECT type, SUM(amount) AS total FROM activity GROUP BY type")
    suspend fun getCounts(): List<TypeCount>
}

@Dao
interface ClaimDao {
    @Query("SELECT claimKey FROM claims")
    fun observeKeys(): Flow<List<String>>

    @Query("SELECT COUNT(*) FROM claims WHERE claimKey = :key")
    suspend fun count(key: String): Int

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insert(claim: ClaimEntity): Long
}

@Dao
interface AchievementDao {
    @Query("SELECT * FROM achievements")
    fun observeAll(): Flow<List<AchievementEntity>>

    @Query("SELECT * FROM achievements")
    suspend fun getAll(): List<AchievementEntity>

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insert(entity: AchievementEntity): Long
}

// ------------------------------------------------------------------
// Database
// ------------------------------------------------------------------

@Database(
    entities = [
        PlayerEntity::class, PetEntity::class, HabitEntity::class, HabitLogEntity::class,
        InventoryEntity::class, ActivityEntity::class, ClaimEntity::class, AchievementEntity::class,
    ],
    version = 1,
    exportSchema = false,
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun playerDao(): PlayerDao
    abstract fun petDao(): PetDao
    abstract fun habitDao(): HabitDao
    abstract fun inventoryDao(): InventoryDao
    abstract fun activityDao(): ActivityDao
    abstract fun claimDao(): ClaimDao
    abstract fun achievementDao(): AchievementDao

    companion object {
        @Volatile
        private var instance: AppDatabase? = null

        fun get(context: Context): AppDatabase =
            instance ?: synchronized(this) {
                instance ?: Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "petverse.db"
                )
                    .fallbackToDestructiveMigration()
                    .build()
                    .also { instance = it }
            }
    }
}
