package com.petverse.app.ui

import android.app.Application
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider.AndroidViewModelFactory.Companion.APPLICATION_KEY
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.petverse.app.PetVerseApp
import com.petverse.app.data.catalog.MissionDef
import com.petverse.app.data.db.ActivityEntity
import com.petverse.app.data.db.HabitEntity
import com.petverse.app.data.db.HabitLogEntity
import com.petverse.app.data.db.PetEntity
import com.petverse.app.data.db.PlayerEntity
import com.petverse.app.data.model.Difficulty
import com.petverse.app.data.model.HabitCategory
import com.petverse.app.data.model.PetAction
import com.petverse.app.data.model.Reaction
import com.petverse.app.data.repo.GameRepository
import com.petverse.app.domain.ActionOutcome
import com.petverse.app.domain.GameEvent
import com.petverse.app.domain.GameStats
import com.petverse.app.domain.StatsCalculator
import com.petverse.app.notifications.ReminderScheduler
import com.petverse.app.util.Time
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class ReactionEvent(val petId: Long, val reaction: Reaction, val emoji: String?, val nonce: Long)

class GameViewModel(
    private val repo: GameRepository,
    private val app: Application,
) : ViewModel() {

    private val started = SharingStarted.Eagerly

    val player: StateFlow<PlayerEntity?> = repo.player.stateIn(viewModelScope, started, null)
    val pets: StateFlow<List<PetEntity>> = repo.pets.stateIn(viewModelScope, started, emptyList())
    val habits: StateFlow<List<HabitEntity>> = repo.habits.stateIn(viewModelScope, started, emptyList())
    val allHabits: StateFlow<List<HabitEntity>> = repo.allHabits.stateIn(viewModelScope, started, emptyList())
    val logs: StateFlow<List<HabitLogEntity>> = repo.logs.stateIn(viewModelScope, started, emptyList())
    val inventory: StateFlow<Map<String, Int>> = repo.inventory.stateIn(viewModelScope, started, emptyMap())
    val activities: StateFlow<List<ActivityEntity>> =
        repo.activitiesSince(Time.today() - 45).stateIn(viewModelScope, started, emptyList())
    val counts: StateFlow<Map<String, Int>> = repo.activityCounts.stateIn(viewModelScope, started, emptyMap())
    val claims: StateFlow<Set<String>> = repo.claims.stateIn(viewModelScope, started, emptySet())
    val achievements: StateFlow<Map<String, Long>> = repo.achievements.stateIn(viewModelScope, started, emptyMap())

    val stats: StateFlow<GameStats> = combine(player, pets, logs, counts) { p, ps, l, c ->
        StatsCalculator.compute(p, ps, l.map { it.epochDay }, l.size, c, Time.today())
    }.stateIn(viewModelScope, started, GameStats())

    private val _ready = MutableStateFlow(false)
    val ready: StateFlow<Boolean> = _ready.asStateFlow()

    private val _events = MutableSharedFlow<GameEvent>(extraBufferCapacity = 32)
    val events: SharedFlow<GameEvent> = _events.asSharedFlow()

    private val _reaction = MutableStateFlow<ReactionEvent?>(null)
    val reaction: StateFlow<ReactionEvent?> = _reaction.asStateFlow()

    init {
        viewModelScope.launch {
            repo.ensureInitialized()
            repo.onAppOpen()
            _ready.value = true
            val p = repo.player.first()
            if (p != null && p.onboarded && p.notificationsEnabled) {
                ReminderScheduler.schedule(app, p.reminderHour, p.reminderMinute)
            }
            while (true) {
                delay(60_000)
                repo.applyDriftAll()
            }
        }
    }

    // ---------------- Helpers ----------------
    private fun handle(outcome: ActionOutcome) {
        outcome.events.forEach { _events.tryEmit(it) }
        val petId = outcome.petId
        val r = outcome.reaction
        if (outcome.success && r != null && petId != null) {
            _reaction.value = ReactionEvent(petId, r, outcome.reactionEmoji, System.nanoTime())
        }
    }

    private fun run(block: suspend () -> ActionOutcome) {
        viewModelScope.launch { handle(block()) }
    }

    fun toast(text: String, emoji: String = "ℹ️") {
        _events.tryEmit(GameEvent.Toast(text, emoji))
    }

    fun problem(text: String) {
        _events.tryEmit(GameEvent.Problem(text))
    }

    /** Lets screens trigger a purely visual reaction (e.g. a training hit). */
    fun localReaction(petId: Long, reaction: Reaction, emoji: String?) {
        _reaction.value = ReactionEvent(petId, reaction, emoji, System.nanoTime())
    }

    // ---------------- Onboarding & profile ----------------
    fun completeOnboarding(
        name: String,
        avatar: String,
        starterId: String,
        petName: String,
        presetIds: Set<String>,
        onDone: () -> Unit,
    ) {
        viewModelScope.launch {
            repo.completeOnboarding(name, avatar, starterId, petName, presetIds)
            val p = player.value
            ReminderScheduler.schedule(app, p?.reminderHour ?: 19, p?.reminderMinute ?: 0)
            onDone()
        }
    }

    fun updateProfile(name: String, avatar: String) {
        viewModelScope.launch { repo.updatePlayer { it.copy(name = name.trim().ifBlank { it.name }, avatar = avatar) } }
    }

    fun claimLoginReward() = run { repo.claimLoginReward() }

    // ---------------- Habits ----------------
    fun completeHabit(id: Long) = run { repo.completeHabit(id) }

    fun addHabit(name: String, emoji: String, category: HabitCategory, difficulty: Difficulty) {
        if (name.isBlank()) {
            problem("Give your habit a name first.")
            return
        }
        viewModelScope.launch {
            repo.addHabit(name, emoji, category, difficulty)
            _events.tryEmit(GameEvent.Toast("Habit added: $name", emoji))
        }
    }

    fun updateHabit(habit: HabitEntity) {
        viewModelScope.launch { repo.updateHabit(habit) }
    }

    fun archiveHabit(id: Long) {
        viewModelScope.launch {
            repo.archiveHabit(id)
            _events.tryEmit(GameEvent.Toast("Habit archived. Its history is kept in Statistics.", "🗂️"))
        }
    }

    fun addPresetHabits(ids: Set<String>) {
        if (ids.isEmpty()) return
        viewModelScope.launch {
            repo.addPresetHabits(ids)
            _events.tryEmit(GameEvent.Toast("Added ${ids.size} habit${if (ids.size == 1) "" else "s"}", "✅"))
        }
    }

    // ---------------- Pets ----------------
    fun action(petId: Long, action: PetAction, itemId: String? = null) = run { repo.performAction(petId, action, itemId) }
    fun train(petId: Long, skillId: String, hits: Int) = run { repo.train(petId, skillId, hits) }
    fun grow(petId: Long) = run { repo.grow(petId) }
    fun equip(petId: Long, itemId: String?) = run { repo.equip(petId, itemId) }

    fun adopt(speciesId: String, name: String, onAdopted: (Long) -> Unit) {
        viewModelScope.launch {
            val outcome = repo.adopt(speciesId, name)
            handle(outcome)
            val id = outcome.petId
            if (outcome.success && id != null) onAdopted(id)
        }
    }

    fun rename(petId: Long, name: String) {
        viewModelScope.launch { repo.rename(petId, name) }
    }

    fun setPartner(petId: Long) {
        viewModelScope.launch {
            repo.setPartner(petId)
            _events.tryEmit(GameEvent.Toast("New partner chosen! Habit rewards now go to them.", "⭐"))
        }
    }

    // ---------------- Shop, missions, achievements ----------------
    fun buy(itemId: String) = run { repo.buy(itemId) }
    fun claimMission(def: MissionDef) = run { repo.claimMission(def) }
    fun claimAchievement(id: String) = run { repo.claimAchievement(id) }

    // ---------------- Settings ----------------
    fun setTheme(mode: Int) {
        viewModelScope.launch { repo.updatePlayer { it.copy(themeMode = mode) } }
    }

    fun setHaptics(enabled: Boolean) {
        viewModelScope.launch { repo.updatePlayer { it.copy(hapticsEnabled = enabled) } }
    }

    fun setNotifications(enabled: Boolean) {
        viewModelScope.launch {
            repo.updatePlayer { it.copy(notificationsEnabled = enabled) }
            val p = player.value
            if (enabled) ReminderScheduler.schedule(app, p?.reminderHour ?: 19, p?.reminderMinute ?: 0)
            else ReminderScheduler.cancel(app)
        }
    }

    fun setReminderTime(hour: Int, minute: Int) {
        viewModelScope.launch {
            repo.updatePlayer { it.copy(reminderHour = hour, reminderMinute = minute) }
            if (player.value?.notificationsEnabled != false) ReminderScheduler.schedule(app, hour, minute)
            _events.tryEmit(GameEvent.Toast("Daily reminder set for ${Time.formatTime(hour, minute)}", "⏰"))
        }
    }

    fun resetProgress(onDone: () -> Unit) {
        viewModelScope.launch {
            ReminderScheduler.cancel(app)
            repo.resetAll()
            onDone()
        }
    }

    companion object {
        val Factory = viewModelFactory {
            initializer {
                val app = this[APPLICATION_KEY] as PetVerseApp
                GameViewModel(app.container.repository, app)
            }
        }
    }
}
