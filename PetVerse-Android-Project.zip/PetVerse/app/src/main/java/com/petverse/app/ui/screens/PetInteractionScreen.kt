package com.petverse.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.Star
import androidx.compose.material.icons.rounded.StarBorder
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavHostController
import com.petverse.app.data.catalog.ItemCatalog
import com.petverse.app.data.catalog.ItemDef
import com.petverse.app.data.catalog.ItemType
import com.petverse.app.data.catalog.SpeciesCatalog
import com.petverse.app.data.catalog.TrainingCatalog
import com.petverse.app.data.db.PetEntity
import com.petverse.app.data.model.PetAction
import com.petverse.app.domain.GameRules
import com.petverse.app.ui.GameViewModel
import com.petverse.app.ui.components.AnimatedPet
import com.petverse.app.ui.components.BondBadge
import com.petverse.app.ui.components.EnvironmentBackdrop
import com.petverse.app.ui.components.GradientButton
import com.petverse.app.ui.components.PVCard
import com.petverse.app.ui.components.Pill
import com.petverse.app.ui.components.ProgressTrack
import com.petverse.app.ui.components.RarityBadge
import com.petverse.app.ui.components.ScreenHeader
import com.petverse.app.ui.components.SectionTitle
import com.petverse.app.ui.components.StatBar
import com.petverse.app.ui.components.rememberNow
import com.petverse.app.ui.navigation.Routes
import com.petverse.app.ui.theme.CleanColor
import com.petverse.app.ui.theme.EnergyColor
import com.petverse.app.ui.theme.FriendshipColor
import com.petverse.app.ui.theme.FullnessColor
import com.petverse.app.ui.theme.HappinessColor
import com.petverse.app.ui.theme.HealthColor
import com.petverse.app.ui.theme.HydrationColor
import com.petverse.app.ui.theme.IntelligenceColor
import com.petverse.app.ui.theme.LoyaltyColor
import com.petverse.app.ui.theme.StrengthColor
import com.petverse.app.ui.theme.XpColor

private enum class PetSheet { FOOD, TOY, ITEMS, STYLE }

// ------------------------------------------------------------------
// 7. Pet Interaction
// ------------------------------------------------------------------

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PetInteractionScreen(vm: GameViewModel, nav: NavHostController, petId: Long) {
    val pets by vm.pets.collectAsStateWithLifecycle()
    val player by vm.player.collectAsStateWithLifecycle()
    val inventory by vm.inventory.collectAsStateWithLifecycle()
    val reaction by vm.reaction.collectAsStateWithLifecycle()
    val now by rememberNow()
    val haptics = LocalHapticFeedback.current
    var sheet by remember { mutableStateOf<PetSheet?>(null) }
    var renaming by remember { mutableStateOf(false) }

    val pet = pets.firstOrNull { it.id == petId }
    if (pet == null) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
        return
    }
    val sp = SpeciesCatalog.byId(pet.speciesId)
    val p = player
    val sleeping = pet.sleepUntil > now
    val bond = GameRules.bondLevel(pet.loyaltyPoints)
    val isPartner = p?.partnerPetId == pet.id
    val r = reaction?.takeIf { it.petId == pet.id }
    val (moodEmoji, moodText) = GameRules.mood(pet, now)
    val hapticsOn = p?.hapticsEnabled != false

    fun doAction(action: PetAction) {
        if (hapticsOn) haptics.performHapticFeedback(HapticFeedbackType.LongPress)
        if (bond < action.minBond) {
            vm.problem("Reach ${GameRules.bondName(action.minBond)} bond to unlock ${if (sp.wild) action.wildLabel else action.label}.")
            return
        }
        when (action) {
            PetAction.FEED -> sheet = PetSheet.FOOD
            PetAction.TOY -> sheet = PetSheet.TOY
            PetAction.USE_ITEM -> sheet = PetSheet.ITEMS
            PetAction.TRAIN -> nav.navigate(Routes.train(pet.id))
            else -> vm.action(pet.id, action)
        }
    }

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 28.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        item {
            ScreenHeader(pet.name, onBack = { nav.popBackStack() }, subtitle = "${sp.name} • ${sp.stageName(pet.stage)}") {
                IconButton(onClick = { renaming = true }) { Icon(Icons.Rounded.Edit, contentDescription = "Rename") }
                IconButton(onClick = { if (!isPartner) vm.setPartner(pet.id) }) {
                    Icon(
                        if (isPartner) Icons.Rounded.Star else Icons.Rounded.StarBorder,
                        contentDescription = "Habit partner",
                        tint = if (isPartner) Color(0xFFFFB547) else MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
        }

        // ---------------- Scene ----------------
        item {
            EnvironmentBackdrop(sp.habitat, Modifier.fillMaxWidth().height(320.dp)) {
                AnimatedPet(
                    sp, pet.stage,
                    modifier = Modifier.align(Alignment.Center).padding(top = 40.dp),
                    size = 210.dp,
                    accessory = pet.accessory,
                    sleeping = sleeping,
                    reaction = r?.reaction,
                    reactionEmoji = r?.emoji,
                    reactionNonce = r?.nonce ?: 0L,
                    goldenAura = bond >= 6,
                )
                Row(Modifier.align(Alignment.TopStart).padding(12.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    RarityBadge(sp.rarity)
                    BondBadge(pet.loyaltyPoints)
                }
                if (isPartner) {
                    Pill("Habit partner", Modifier.align(Alignment.TopEnd).padding(12.dp), color = Color(0xFFF59E0B), emoji = "⭐", filled = true)
                }
                Row(
                    Modifier
                        .align(Alignment.BottomCenter)
                        .padding(12.dp)
                        .clip(RoundedCornerShape(50))
                        .background(Color.White.copy(alpha = 0.88f))
                        .padding(horizontal = 14.dp, vertical = 7.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text(moodEmoji, fontSize = 15.sp)
                    Spacer(Modifier.width(6.dp))
                    Text(
                        if (sleeping) "Sleeping… ${((pet.sleepUntil - now) / 1000).coerceAtLeast(0)}s" else moodText,
                        style = MaterialTheme.typography.labelLarge, color = Color(0xFF1B1A2E), maxLines = 1,
                    )
                }
            }
        }

        // ---------------- Level, growth ----------------
        item {
            PVCard {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Level ${pet.level}", style = MaterialTheme.typography.titleLarge)
                        Text(
                            "Stage ${pet.stage}/5 • ${sp.stageName(pet.stage)} • 💎 ${pet.developmentPoints} DP",
                            style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                    Text("${sp.personality.emoji} ${sp.personality.label}", style = MaterialTheme.typography.labelLarge)
                }
                Spacer(Modifier.height(8.dp))
                ProgressTrack(pet.xp / GameRules.petXpForNext(pet.level).toFloat(), XpColor, Modifier.fillMaxWidth().height(10.dp))
                Text(
                    "${pet.xp} / ${GameRules.petXpForNext(pet.level)} XP",
                    style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(top = 4.dp),
                )
                Spacer(Modifier.height(10.dp))
                if (pet.stage < 5) {
                    val next = pet.stage + 1
                    val needLevel = GameRules.levelForStage(next)
                    val needDp = GameRules.dpForStage(next)
                    if (GameRules.canGrow(pet)) {
                        GradientButton(
                            "Grow into ${sp.stageName(next)}!",
                            onClick = { vm.grow(pet.id) },
                            modifier = Modifier.fillMaxWidth(),
                            emoji = "🌱",
                            colors = listOf(Color(0xFF2ED3A5), Color(0xFF12A383)),
                        )
                    } else {
                        Text(
                            "Next stage: ${sp.stageName(next)} — needs Level $needLevel and $needDp 💎 Development Point${if (needDp == 1) "" else "s"}. Earn DP with Habit Power (5 habits in a day)!",
                            style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                } else {
                    Text("🌳 Fully grown — a true ${sp.stageName(5)}!", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.tertiary)
                }
            }
        }

        // ---------------- Actions ----------------
        item {
            PVCard {
                SectionTitle(if (sp.wild) "Keeper care" else "Care & play")
                Spacer(Modifier.height(10.dp))
                val actions = PetAction.entries.filter { it != PetAction.WALK || sp.walkable }
                actions.chunked(4).forEach { row ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        row.forEach { a ->
                            val locked = bond < a.minBond
                            val disabled = sleeping && a != PetAction.REST
                            val label = when {
                                a == PetAction.REST && sleeping -> "Wake Up"
                                sp.wild -> a.wildLabel
                                else -> a.label
                            }
                            val emoji = when {
                                a == PetAction.REST && sleeping -> "☀️"
                                a == PetAction.PLAY -> sp.group.playEmoji
                                else -> a.emoji
                            }
                            ActionTile(emoji, label, locked, disabled, GameRules.bondName(a.minBond), Modifier.weight(1f)) {
                                doAction(a)
                            }
                        }
                        repeat(4 - row.size) { Spacer(Modifier.weight(1f)) }
                    }
                    Spacer(Modifier.height(8.dp))
                }
                if (sp.wild) {
                    Text(
                        "🌿 Sanctuary care: you build trust from a respectful distance through enrichment, observation and cooperative training.",
                        style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
        }

        // ---------------- Needs ----------------
        item {
            PVCard {
                SectionTitle("Wellbeing")
                Spacer(Modifier.height(10.dp))
                StatGrid(
                    listOf(
                        Triple("😊", "Happiness", pet.happiness) to HappinessColor,
                        Triple("❤️", "Health", pet.health) to HealthColor,
                        Triple("⚡", "Energy", pet.energy) to EnergyColor,
                        Triple("🥣", "Fullness", pet.fullness) to FullnessColor,
                        Triple("💧", "Hydration", pet.hydration) to HydrationColor,
                        Triple("🧽", "Habitat", pet.cleanliness) to CleanColor,
                    )
                )
                Spacer(Modifier.height(6.dp))
                Text(
                    "Needs drift gently over time but never cause harm — your friend just loves extra attention.",
                    style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }

        // ---------------- Attributes & bond ----------------
        item {
            PVCard {
                SectionTitle("Attributes & bond")
                Spacer(Modifier.height(10.dp))
                StatGrid(
                    listOf(
                        Triple("🧠", "Intelligence", pet.intelligence) to IntelligenceColor,
                        Triple("💪", "Strength", pet.strength) to StrengthColor,
                        Triple("🤝", "Friendship", pet.friendship) to FriendshipColor,
                    )
                )
                Spacer(Modifier.height(12.dp))
                val nextThreshold = GameRules.nextBondThreshold(bond)
                val prevThreshold = GameRules.bondThresholds[bond - 1]
                StatBar(
                    GameRules.bondEmoji(bond), "Loyalty • ${GameRules.bondName(bond)}",
                    if (nextThreshold == null) 1 else pet.loyaltyPoints - prevThreshold,
                    LoyaltyColor,
                    max = if (nextThreshold == null) 1 else nextThreshold - prevThreshold,
                    valueText = if (nextThreshold == null) "MAX" else "${pet.loyaltyPoints}/$nextThreshold",
                )
                Spacer(Modifier.height(10.dp))
                GameRules.bondNames.forEachIndexed { i, nm ->
                    val reached = bond >= i + 1
                    Row(Modifier.padding(vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(if (reached) GameRules.bondEmojis[i] else "🔒", fontSize = 13.sp)
                        Spacer(Modifier.width(8.dp))
                        Text(
                            "$nm — ${GameRules.bondUnlocks[i]}",
                            style = MaterialTheme.typography.labelSmall,
                            color = if (reached) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
            }
        }

        // ---------------- Abilities & skills ----------------
        item {
            PVCard {
                SectionTitle("Abilities & skills")
                Spacer(Modifier.height(8.dp))
                sp.abilities.forEachIndexed { i, ab ->
                    val stageNeeded = sp.abilityUnlockStage(i)
                    val unlocked = pet.stage >= stageNeeded
                    Row(Modifier.padding(vertical = 3.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(if (unlocked) "✨" else "🔒", fontSize = 14.sp)
                        Spacer(Modifier.width(8.dp))
                        Text(ab, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
                        Text(
                            if (unlocked) "Unlocked" else "Stage $stageNeeded",
                            style = MaterialTheme.typography.labelSmall,
                            color = if (unlocked) MaterialTheme.colorScheme.tertiary else MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
                Spacer(Modifier.height(10.dp))
                val learned = GameRules.learnedSkills(pet)
                val progress = GameRules.parseProgress(pet.skillProgress)
                TrainingCatalog.skillsFor(sp.group, sp.wild).forEach { sk ->
                    val done = sk.id in learned
                    Row(Modifier.padding(vertical = 3.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(sk.emoji, fontSize = 14.sp)
                        Spacer(Modifier.width(8.dp))
                        Text(sk.name, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
                        Text(
                            if (done) "Mastered 🎓" else "${progress[sk.id] ?: 0}/${sk.sessions}",
                            style = MaterialTheme.typography.labelSmall,
                            color = if (done) MaterialTheme.colorScheme.tertiary else MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
                Spacer(Modifier.height(10.dp))
                GradientButton("Go to training", onClick = { doAction(PetAction.TRAIN) }, modifier = Modifier.fillMaxWidth(), emoji = "🎯")
            }
        }

        // ---------------- Style ----------------
        item {
            PVCard(onClick = { if (bond >= 3) sheet = PetSheet.STYLE else vm.problem("Accessories unlock at Friend bond 💚") }) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(ItemCatalog.find(pet.accessory)?.emoji ?: "👕", fontSize = 30.sp)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text("Style", style = MaterialTheme.typography.titleMedium)
                        Text(
                            if (bond >= 3) (ItemCatalog.find(pet.accessory)?.name ?: "No accessory — tap to dress up") else "Unlocks at Friend bond",
                            style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                    Text(if (bond >= 3) "›" else "🔒", fontSize = 22.sp)
                }
            }
        }
    }

    // ---------------- Sheets ----------------
    sheet?.let { s ->
        ModalBottomSheet(
            onDismissRequest = { sheet = null },
            sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
        ) {
            Column(Modifier.padding(horizontal = 20.dp).padding(bottom = 28.dp)) {
                when (s) {
                    PetSheet.FOOD -> {
                        Text(if (sp.wild) "Prepare a meal" else "Choose food", style = MaterialTheme.typography.headlineSmall)
                        Text("Favourite diet: ${sp.diet.emoji} ${sp.diet.label}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Spacer(Modifier.height(12.dp))
                        ItemList(ItemCatalog.feedable, inventory, emptyText = "No food left — complete a habit to earn Pet Food!") { item ->
                            vm.action(pet.id, PetAction.FEED, item.id)
                            sheet = null
                        }
                    }
                    PetSheet.TOY -> {
                        Text("Choose a toy", style = MaterialTheme.typography.headlineSmall)
                        Text("Toys are yours forever. Look for ⭐ favourites!", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Spacer(Modifier.height(12.dp))
                        ItemList(
                            ItemCatalog.ofType(ItemType.TOY), inventory, emptyText = "You don't own any toys yet.",
                            favourite = { sp.group in it.favoriteOf },
                        ) { item ->
                            vm.action(pet.id, PetAction.TOY, item.id)
                            sheet = null
                        }
                    }
                    PetSheet.ITEMS -> {
                        Text("Use an item", style = MaterialTheme.typography.headlineSmall)
                        Spacer(Modifier.height(12.dp))
                        ItemList(ItemCatalog.usable, inventory, emptyText = "No care items yet. Visit the Shop or complete missions.") { item ->
                            vm.action(pet.id, PetAction.USE_ITEM, item.id)
                            sheet = null
                        }
                    }
                    PetSheet.STYLE -> {
                        Text("Accessories", style = MaterialTheme.typography.headlineSmall)
                        Text("New styles unlock as ${pet.name} grows.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Spacer(Modifier.height(12.dp))
                        if (pet.accessory != null) {
                            TextButton(onClick = { vm.equip(pet.id, null); sheet = null }) { Text("Remove current accessory") }
                        }
                        ItemList(
                            ItemCatalog.ofType(ItemType.ACCESSORY), inventory, emptyText = "Buy accessories in the Pet Shop.",
                            lockedReason = { if (pet.stage < it.minStage) "Stage ${it.minStage}" else null },
                        ) { item ->
                            vm.equip(pet.id, item.id)
                            sheet = null
                        }
                    }
                }
                Spacer(Modifier.height(8.dp))
                TextButton(onClick = { sheet = null; nav.navigate(Routes.SHOP) }, modifier = Modifier.fillMaxWidth()) {
                    Text("🛍️ Visit the Pet Shop")
                }
            }
        }
    }

    if (renaming) {
        RenameDialog(pet, onDismiss = { renaming = false }) { name ->
            vm.rename(pet.id, name)
            renaming = false
        }
    }
}

@Composable
private fun ActionTile(
    emoji: String,
    label: String,
    locked: Boolean,
    disabled: Boolean,
    lockLabel: String,
    modifier: Modifier = Modifier,
    onClick: () -> Unit,
) {
    val alpha = if (locked || disabled) 0.45f else 1f
    Column(
        modifier
            .clip(RoundedCornerShape(18.dp))
            .background(
                if (locked) Brush.linearGradient(listOf(MaterialTheme.colorScheme.surfaceVariant, MaterialTheme.colorScheme.surfaceVariant))
                else Brush.linearGradient(listOf(MaterialTheme.colorScheme.primary.copy(alpha = 0.16f), MaterialTheme.colorScheme.secondary.copy(alpha = 0.10f)))
            )
            .clickable(onClick = onClick)
            .padding(vertical = 10.dp, horizontal = 4.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text(if (locked) "🔒" else emoji, fontSize = 24.sp, modifier = Modifier.padding(bottom = 2.dp))
        Text(
            if (locked) lockLabel else label,
            style = MaterialTheme.typography.labelSmall,
            textAlign = TextAlign.Center,
            maxLines = 2,
            color = MaterialTheme.colorScheme.onSurface.copy(alpha = alpha),
        )
    }
}

@Composable
private fun StatGrid(stats: List<Pair<Triple<String, String, Int>, Color>>) {
    stats.chunked(2).forEach { row ->
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            row.forEach { (t, color) ->
                StatBar(t.first, t.second, t.third, color, Modifier.weight(1f))
            }
            if (row.size == 1) Spacer(Modifier.weight(1f))
        }
        Spacer(Modifier.height(10.dp))
    }
}

@Composable
private fun ItemList(
    items: List<ItemDef>,
    inventory: Map<String, Int>,
    emptyText: String,
    favourite: (ItemDef) -> Boolean = { false },
    lockedReason: (ItemDef) -> String? = { null },
    onUse: (ItemDef) -> Unit,
) {
    val owned = items.filter { (inventory[it.id] ?: 0) > 0 }
    if (owned.isEmpty()) {
        Text(emptyText, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        return
    }
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        owned.forEach { item ->
            val lock = lockedReason(item)
            Row(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(MaterialTheme.colorScheme.surfaceVariant)
                    .border(
                        1.5.dp,
                        if (favourite(item)) Color(0xFFFFB547) else Color.Transparent,
                        RoundedCornerShape(16.dp),
                    )
                    .clickable(enabled = lock == null) { onUse(item) }
                    .padding(12.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Box(Modifier.size(44.dp).clip(CircleShape).background(MaterialTheme.colorScheme.surface), contentAlignment = Alignment.Center) {
                    Text(item.emoji, fontSize = 24.sp)
                }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(item.name + if (favourite(item)) "  ⭐" else "", style = MaterialTheme.typography.titleSmall)
                    Text(item.description, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 2)
                }
                Spacer(Modifier.width(8.dp))
                when {
                    lock != null -> Pill("🔒 $lock", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    item.permanent -> Pill("Use", color = MaterialTheme.colorScheme.primary, filled = true)
                    else -> Pill("x${inventory[item.id] ?: 0}", color = MaterialTheme.colorScheme.primary, filled = true)
                }
            }
        }
    }
}

@Composable
private fun RenameDialog(pet: PetEntity, onDismiss: () -> Unit, onSave: (String) -> Unit) {
    var name by remember { mutableStateOf(pet.name) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Rename ${pet.name}") },
        text = {
            OutlinedTextField(
                value = name, onValueChange = { if (it.length <= 16) name = it },
                singleLine = true, label = { Text("New name") }, shape = RoundedCornerShape(14.dp),
            )
        },
        confirmButton = { TextButton(enabled = name.isNotBlank(), onClick = { onSave(name) }) { Text("Save") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}
