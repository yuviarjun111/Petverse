package com.petverse.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavHostController
import com.petverse.app.data.catalog.Species
import com.petverse.app.data.catalog.SpeciesCatalog
import com.petverse.app.data.catalog.TrainingCatalog
import com.petverse.app.data.db.PetEntity
import com.petverse.app.data.db.PlayerEntity
import com.petverse.app.data.model.AnimalCategory
import com.petverse.app.data.model.Rarity
import com.petverse.app.domain.GameRules
import com.petverse.app.ui.GameViewModel
import com.petverse.app.ui.components.AnimatedPet
import com.petverse.app.ui.components.BondBadge
import com.petverse.app.ui.components.ChoiceChip
import com.petverse.app.ui.components.EnvironmentBackdrop
import com.petverse.app.ui.components.GradientButton
import com.petverse.app.ui.components.PVCard
import com.petverse.app.ui.components.PetPortrait
import com.petverse.app.ui.components.Pill
import com.petverse.app.ui.components.ProgressTrack
import com.petverse.app.ui.components.RarityBadge
import com.petverse.app.ui.components.ScreenHeader
import com.petverse.app.ui.components.rememberNow
import com.petverse.app.ui.navigation.Routes
import com.petverse.app.ui.theme.XpColor

// ------------------------------------------------------------------
// 5. My Pets
// ------------------------------------------------------------------

@Composable
fun MyPetsScreen(vm: GameViewModel, nav: NavHostController) {
    val pets by vm.pets.collectAsStateWithLifecycle()
    val player by vm.player.collectAsStateWithLifecycle()
    val now by rememberNow(10_000)
    val household = pets.filter { !SpeciesCatalog.byId(it.speciesId).wild }
    val sanctuary = pets.filter { SpeciesCatalog.byId(it.speciesId).wild }

    LazyVerticalGrid(
        columns = GridCells.Fixed(2),
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 24.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item(span = { GridItemSpan(maxLineSpan) }) {
            ScreenHeader("My Pets", subtitle = "${pets.size} companion${if (pets.size == 1) "" else "s"} • ⭐ = habit partner")
        }
        if (household.isNotEmpty()) {
            item(span = { GridItemSpan(maxLineSpan) }) {
                Text("🏡 Companions", style = MaterialTheme.typography.titleMedium)
            }
            items(household, key = { it.id }) { pet ->
                PetCard(pet, pet.id == player?.partnerPetId, now) { nav.navigate(Routes.pet(pet.id)) }
            }
        }
        if (sanctuary.isNotEmpty()) {
            item(span = { GridItemSpan(maxLineSpan) }) {
                Column {
                    Text("🏞️ Sanctuary residents", style = MaterialTheme.typography.titleMedium)
                    Text("Wild animals cared for in protected virtual reserves", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            items(sanctuary, key = { it.id }) { pet ->
                PetCard(pet, pet.id == player?.partnerPetId, now) { nav.navigate(Routes.pet(pet.id)) }
            }
        }
        item {
            Column(
                Modifier
                    .fillMaxWidth()
                    .aspectRatio(0.78f)
                    .clip(RoundedCornerShape(24.dp))
                    .border(2.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.5f), RoundedCornerShape(24.dp))
                    .clickable { nav.navigate(Routes.COLLECTION) }
                    .padding(12.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center,
            ) {
                Text("➕", fontSize = 40.sp)
                Spacer(Modifier.height(8.dp))
                Text("Discover more", style = MaterialTheme.typography.titleSmall)
                Text("Open the collection book", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, textAlign = TextAlign.Center)
            }
        }
    }
}

@Composable
private fun PetCard(pet: PetEntity, isPartner: Boolean, now: Long, onClick: () -> Unit) {
    val sp = SpeciesCatalog.byId(pet.speciesId)
    PVCard(onClick = onClick, padding = PaddingValues(0.dp)) {
        EnvironmentBackdrop(
            sp.habitat,
            Modifier.fillMaxWidth().height(130.dp),
            shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp),
            showDecor = false,
        ) {
            AnimatedPet(
                sp, pet.stage, Modifier.align(Alignment.Center).padding(top = 14.dp), size = 100.dp,
                accessory = pet.accessory, sleeping = pet.sleepUntil > now,
                goldenAura = GameRules.bondLevel(pet.loyaltyPoints) >= 6,
            )
            if (isPartner) Text("⭐", fontSize = 20.sp, modifier = Modifier.align(Alignment.TopEnd).padding(8.dp))
            if (GameRules.canGrow(pet)) Text("🌱", fontSize = 18.sp, modifier = Modifier.align(Alignment.TopStart).padding(8.dp))
        }
        Column(Modifier.padding(12.dp)) {
            Text(pet.name, style = MaterialTheme.typography.titleMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(
                "${sp.name} • Lv ${pet.level}", style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis,
            )
            Spacer(Modifier.height(6.dp))
            ProgressTrack(pet.xp / GameRules.petXpForNext(pet.level).toFloat(), XpColor, Modifier.fillMaxWidth().height(6.dp))
            Spacer(Modifier.height(6.dp))
            BondBadge(pet.loyaltyPoints)
        }
    }
}

// ------------------------------------------------------------------
// 6. Animal Collection book + adoption
// ------------------------------------------------------------------

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CollectionScreen(vm: GameViewModel, nav: NavHostController) {
    val pets by vm.pets.collectAsStateWithLifecycle()
    val player by vm.player.collectAsStateWithLifecycle()
    var category by remember { mutableStateOf<AnimalCategory?>(null) }
    var rarity by remember { mutableStateOf<Rarity?>(null) }
    var selected by remember { mutableStateOf<Species?>(null) }
    val p = player ?: return
    val owned = pets.associateBy { it.speciesId }
    val list = SpeciesCatalog.all.filter { (category == null || it.category == category) && (rarity == null || it.rarity == rarity) }

    LazyVerticalGrid(
        columns = GridCells.Fixed(3),
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 24.dp),
        horizontalArrangement = Arrangement.spacedBy(10.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        item(span = { GridItemSpan(maxLineSpan) }) {
            ScreenHeader("Collection Book", onBack = { nav.popBackStack() }, subtitle = "Discovered ${owned.size} of ${SpeciesCatalog.all.size} species")
        }
        item(span = { GridItemSpan(maxLineSpan) }) {
            Column {
                ProgressTrack(owned.size / SpeciesCatalog.all.size.toFloat(), MaterialTheme.colorScheme.primary, Modifier.fillMaxWidth().height(8.dp))
                Spacer(Modifier.height(10.dp))
                Text(
                    "Rarity shows how rarely a species is discovered in PetVerse. Every animal matters equally.",
                    style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Spacer(Modifier.height(10.dp))
                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    item { ChoiceChip("All", category == null, { category = null }) }
                    items(AnimalCategory.entries) { c ->
                        ChoiceChip(c.label, category == c, { category = if (category == c) null else c }, emoji = c.emoji)
                    }
                }
                Spacer(Modifier.height(8.dp))
                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    item { ChoiceChip("Any rarity", rarity == null, { rarity = null }) }
                    items(Rarity.entries) { r ->
                        ChoiceChip(r.label, rarity == r, { rarity = if (rarity == r) null else r })
                    }
                }
            }
        }
        items(list, key = { it.id }) { sp ->
            SpeciesTile(sp, owned[sp.id], p) { selected = sp }
        }
    }

    selected?.let { sp ->
        ModalBottomSheet(
            onDismissRequest = { selected = null },
            sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
        ) {
            SpeciesDetail(
                sp, owned[sp.id], p, pets,
                onOpen = { id -> selected = null; nav.navigate(Routes.pet(id)) },
                onAdopt = { name ->
                    vm.adopt(sp.id, name) { id ->
                        selected = null
                        nav.navigate(Routes.pet(id))
                    }
                },
            )
        }
    }
}

@Composable
private fun SpeciesTile(sp: Species, pet: PetEntity?, player: PlayerEntity, onClick: () -> Unit) {
    val unlocked = player.level >= sp.minLevel
    Column(
        Modifier
            .clip(RoundedCornerShape(20.dp))
            .background(MaterialTheme.colorScheme.surface)
            .border(
                1.5.dp,
                if (pet != null) Color(sp.rarity.color) else MaterialTheme.colorScheme.outline.copy(alpha = 0.5f),
                RoundedCornerShape(20.dp),
            )
            .clickable(onClick = onClick)
            .padding(vertical = 12.dp, horizontal = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        PetPortrait(sp, size = 58.dp, locked = pet == null && !unlocked)
        Spacer(Modifier.height(6.dp))
        Text(
            if (pet == null && !unlocked) "???" else sp.name,
            style = MaterialTheme.typography.labelMedium, maxLines = 1, overflow = TextOverflow.Ellipsis,
            textAlign = TextAlign.Center,
        )
        Text(
            when {
                pet != null -> "✓ ${pet.name}"
                unlocked -> "Available"
                else -> "🔒 Lv ${sp.minLevel}"
            },
            style = MaterialTheme.typography.labelSmall,
            color = when {
                pet != null -> MaterialTheme.colorScheme.tertiary
                unlocked -> MaterialTheme.colorScheme.primary
                else -> MaterialTheme.colorScheme.onSurfaceVariant
            },
            maxLines = 1, overflow = TextOverflow.Ellipsis,
        )
        Spacer(Modifier.height(4.dp))
        Box(
            Modifier
                .size(width = 28.dp, height = 4.dp)
                .clip(RoundedCornerShape(50))
                .background(Color(sp.rarity.color))
        )
    }
}

@Composable
private fun SpeciesDetail(
    sp: Species,
    pet: PetEntity?,
    player: PlayerEntity,
    pets: List<PetEntity>,
    onOpen: (Long) -> Unit,
    onAdopt: (String) -> Unit,
) {
    var name by remember(sp.id) { mutableStateOf("") }
    val levelOk = player.level >= sp.minLevel
    val coinsOk = player.coins >= sp.setupCost
    val bondOk = !sp.needsBestFriend || pets.any { GameRules.bondLevel(it.loyaltyPoints) >= 5 }
    Column(
        Modifier
            .fillMaxWidth()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp)
            .padding(bottom = 28.dp),
    ) {
        EnvironmentBackdrop(sp.habitat, Modifier.fillMaxWidth().height(200.dp)) {
            if (levelOk || pet != null) {
                AnimatedPet(sp, stage = pet?.stage ?: 3, modifier = Modifier.align(Alignment.Center).padding(top = 20.dp), size = 150.dp)
            } else {
                PetPortrait(sp, Modifier.align(Alignment.Center), size = 110.dp, locked = true)
            }
        }
        Spacer(Modifier.height(14.dp))
        Text(if (levelOk || pet != null) sp.name else "Undiscovered species", style = MaterialTheme.typography.headlineMedium)
        Spacer(Modifier.height(6.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            RarityBadge(sp.rarity)
            Pill(sp.category.label, emoji = sp.category.emoji)
            if (sp.wild) Pill("Sanctuary animal", color = Color(0xFF2EAD6B), emoji = "🏞️")
        }
        Spacer(Modifier.height(12.dp))
        Text(sp.description, style = MaterialTheme.typography.bodyMedium)
        if (sp.wild) {
            Spacer(Modifier.height(8.dp))
            Text(
                "🌿 Wild animals in PetVerse are never household pets. You care for them as a keeper in a protected virtual reserve, building trust through enrichment and calm observation.",
                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        Spacer(Modifier.height(14.dp))
        InfoGrid(
            listOf(
                "Personality" to "${sp.personality.emoji} ${sp.personality.label}",
                "Trait" to sp.personality.effect,
                "Home" to "${sp.habitat.emoji} ${sp.habitat.title}",
                "Diet" to "${sp.diet.emoji} ${sp.diet.label}",
                "Walks" to if (sp.walkable) "🦮 Loves walks" else "Explores its habitat",
                "Skills" to TrainingCatalog.skillsFor(sp.group, sp.wild).joinToString { it.name },
            )
        )
        Spacer(Modifier.height(14.dp))
        Text("Growth path", style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(6.dp))
        sp.group.stages.forEachIndexed { i, st ->
            val ability = if (i >= 1) sp.abilities.getOrNull(i - 1) else null
            Row(Modifier.padding(vertical = 3.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("${i + 1}", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary, modifier = Modifier.width(22.dp))
                Text(st, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
                if (ability != null) Text("✨ $ability", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        Spacer(Modifier.height(18.dp))
        if (pet != null) {
            GradientButton("Visit ${pet.name}", onClick = { onOpen(pet.id) }, modifier = Modifier.fillMaxWidth(), emoji = sp.emoji)
        } else {
            Text("Requirements", style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(6.dp))
            Requirement("Trainer Level ${sp.minLevel}", levelOk)
            Requirement("Habitat setup: ${sp.setupCost} 🪙 (you have ${player.coins})", coinsOk)
            if (sp.needsBestFriend) Requirement("A Best Friend bond with any pet", bondOk)
            Spacer(Modifier.height(12.dp))
            if (levelOk && bondOk) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { if (it.length <= 16) name = it },
                    label = { Text("Name (optional)") },
                    placeholder = { Text(sp.name) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                )
                Spacer(Modifier.height(12.dp))
            }
            GradientButton(
                if (sp.wild) "Become their keeper" else "Adopt ${sp.name}",
                onClick = { onAdopt(name) },
                enabled = levelOk && coinsOk && bondOk,
                modifier = Modifier.fillMaxWidth(),
                emoji = if (sp.wild) "🏞️" else "🏡",
            )
        }
    }
}

@Composable
private fun Requirement(text: String, ok: Boolean) {
    Row(Modifier.padding(vertical = 3.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(if (ok) "✅" else "⬜", fontSize = 15.sp)
        Spacer(Modifier.width(8.dp))
        Text(text, style = MaterialTheme.typography.bodyMedium, color = if (ok) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
internal fun InfoGrid(rows: List<Pair<String, String>>) {
    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant)
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        rows.forEach { (k, v) ->
            Row {
                Text(k, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.width(92.dp))
                Text(v, style = MaterialTheme.typography.bodySmall, modifier = Modifier.weight(1f))
            }
        }
    }
}
