package com.petverse.app.data.repo

import androidx.room.withTransaction
import com.petverse.app.data.catalog.AchievementCatalog
import com.petverse.app.data.catalog.HabitPresets
import com.petverse.app.data.catalog.ItemCatalog
import com.petverse.app.data.catalog.LoginRewards
import com.petverse.app.data.catalog.MissionDef
import com.petverse.app.data.catalog.SkillFocus
import com.petverse.app.data.catalog.SpeciesCatalog
import com.petverse.app.data.catalog.TrainingCatalog
import com.petverse.app.data.db.AchievementEntity
import com.petverse.app.data.db.ActivityEntity
import com.petverse.app.data.db.AppDatabase
import com.petverse.app.data.db.ClaimEntity
import com.petverse.app.data.db.HabitEntity
import com.petverse.app.data.db.HabitLogEntity
import com.petverse.app.data.db.InventoryEntity
import com.petverse.app.data.db.PetEntity
import com.petverse.app.data.db.PlayerEntity
import com.petverse.app.data.model.ActivityTypes
import com.petverse.app.data.model.Difficulty
import com.petverse.app.data.model.EnvironmentId
import com.petverse.app.data.model.HabitCategory
import com.petverse.app.data.model.PetAction
import com.petverse.app.data.model.Personality
import com.petverse.app.data.model.Reaction
import com.petverse.app.domain.ActionOutcome
import com.petverse.app.domain.GameEvent
import com.petverse.app.domain.GameRules
import com.petverse.app.domain.GameStats
import com.petverse.app.domain.MissionEngine
import com.petverse.app.domain.StatsCalculator
import com.petverse.app.util.Streaks
import com.petverse.app.util.Time
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext
import kotlin.random.Random

/**
 * Single source of truth for all game state. Every mutation runs inside a Room
 * transaction and returns the events (toasts / celebrations) the UI should show.
 */
class GameRepository(private val db: AppDatabase) {

    private val playerDao = db.playerDao()
    private val petDao = db.petDao()
    private val habitDao = db.habitDao()
    private val inventoryDao = db.inventoryDao()
    private val activityDao = db.activityDao()
    private val claimDao = db.claimDao()
    private val achievementDao = db.achievementDao()

    // ---------------- Observable state ----------------
    val player: Flow<PlayerEntity?> = playerDao.observe()
    val pets: Flow<List<PetEntity>> = petDao.observeAll()
    val habits: Flow<List<HabitEntity>> = habitDao.observeActive()
    val allHabits: Flow<List<HabitEntity>> = habitDao.observeAllIncludingArchived()
    val logs: Flow<List<HabitLogEntity>> = habitDao.observeLogs()
    val inventory: Flow<Map<String, Int>> =
        inventoryDao.observeAll().map { list -> list.filter { it.quantity > 0 }.associate { it.itemId to it.quantity } }
    val activityCounts: Flow<Map<String, Int>> =
        activityDao.observeCounts().map { list -> list.associate { it.type to it.total } }
    val claims: Flow<Set<String>> = claimDao.observeKeys().map { it.toSet() }
    val achievements: Flow<Map<String, Long>> =
        achievementDao.observeAll().map { list -> list.associate { it.id to it.unlockedAt } }

    fun activitiesSince(day: Long): Flow<List<ActivityEntity>> = activityDao.observeSince(day)

    // ---------------- Setup ----------------
    suspend fun ensureInitialized() {
        if (playerDao.get() == null) playerDao.upsert(PlayerEntity())
    }

    suspend fun onAppOpen() {
        db.withTransaction {
            val p = player()
            val today = Time.today()
            if (p.lastLoginDay != today) {
                val streak = if (p.lastLoginDay == today - 1) p.loginStreak + 1 else 1
                playerDao.upsert(p.copy(lastLoginDay = today, loginStreak = streak))
                logActivity(ActivityTypes.LOGIN, null)
            }
            applyDriftInternal()
        }
    }

    suspend fun applyDriftAll() {
        db.withTransaction { applyDriftInternal() }
    }

    private suspend fun applyDriftInternal() {
        val now = Time.now()
        val pets = petDao.getAll()
        val changed = pets.map { GameRules.applyDrift(it, now) }.filterIndexed { i, p -> p != pets[i] }
        if (changed.isNotEmpty()) petDao.updateAll(changed)
    }

    suspend fun completeOnboarding(
        name: String,
        avatar: String,
        starterId: String,
        petName: String,
        presetIds: Collection<String>,
    ) {
        db.withTransaction {
            val p = player()
            var sort = habitDao.maxSort()
            HabitPresets.all.filter { it.id in presetIds }.forEach { preset ->
                sort++
                habitDao.insert(
                    HabitEntity(
                        name = preset.name, emoji = preset.emoji, category = preset.category.name,
                        difficulty = preset.difficulty.name, sortOrder = sort, presetId = preset.id,
                    )
                )
            }
            val existing = petDao.getBySpecies(starterId)
            val petId = existing?.id ?: petDao.insert(
                PetEntity(speciesId = starterId, name = petName.trim().ifBlank { "Buddy" })
            )
            addItem("pet_food", 5)
            addItem("healthy_treat", 2)
            addItem("ball", 1)
            playerDao.upsert(
                p.copy(
                    name = name.trim().ifBlank { "Trainer" },
                    avatar = avatar,
                    onboarded = true,
                    partnerPetId = petId,
                )
            )
            logActivity(ActivityTypes.ADOPT, petId)
        }
    }

    suspend fun resetAll() {
        withContext(Dispatchers.IO) { db.clearAllTables() }
        ensureInitialized()
        onAppOpen()
    }

    // ---------------- Player & settings ----------------
    suspend fun updatePlayer(transform: (PlayerEntity) -> PlayerEntity) {
        db.withTransaction { playerDao.upsert(transform(player())) }
    }

    suspend fun claimLoginReward(): ActionOutcome = db.withTransaction { claimLoginRewardTx() }

    private suspend fun claimLoginRewardTx(): ActionOutcome {
        val p = player()
        val today = Time.today()
        if (p.lastLoginRewardDay == today) return ActionOutcome.fail("Today's reward is already claimed. See you tomorrow!")
        val reward = LoginRewards.forStreak(p.loginStreak)
        reward.items.forEach { (id, q) -> addItem(id, q) }
        playerDao.upsert(
            p.copy(
                coins = p.coins + reward.coins,
                totalCoinsEarned = p.totalCoinsEarned + reward.coins,
                trainingPoints = p.trainingPoints + reward.trainingPoints,
                lastLoginRewardDay = today,
            )
        )
        val events = mutableListOf<GameEvent>(
            GameEvent.Celebration("Day ${reward.day} Reward!", "You received ${reward.label}.\nCome back tomorrow for the next gift!", reward.emoji)
        )
        checkAchievements(events)
        return ActionOutcome(true, events)
    }

    // ---------------- Habits ----------------
    suspend fun addHabit(name: String, emoji: String, category: HabitCategory, difficulty: Difficulty) {
        db.withTransaction {
            habitDao.insert(
                HabitEntity(
                    name = name.trim(), emoji = emoji, category = category.name,
                    difficulty = difficulty.name, sortOrder = habitDao.maxSort() + 1,
                )
            )
        }
    }

    suspend fun updateHabit(habit: HabitEntity) {
        habitDao.update(habit)
    }

    suspend fun archiveHabit(id: Long) {
        db.withTransaction {
            habitDao.get(id)?.let { habitDao.update(it.copy(archived = true)) }
        }
    }

    suspend fun addPresetHabits(ids: Collection<String>) {
        db.withTransaction {
            var sort = habitDao.maxSort()
            HabitPresets.all.filter { it.id in ids }.forEach { preset ->
                sort++
                habitDao.insert(
                    HabitEntity(
                        name = preset.name, emoji = preset.emoji, category = preset.category.name,
                        difficulty = preset.difficulty.name, sortOrder = sort, presetId = preset.id,
                    )
                )
            }
        }
    }

    suspend fun completeHabit(habitId: Long): ActionOutcome = db.withTransaction { completeHabitTx(habitId) }

    private suspend fun completeHabitTx(habitId: Long): ActionOutcome {
        val today = Time.today()
        val now = Time.now()
        val habit = habitDao.get(habitId) ?: return ActionOutcome.fail("Habit not found")
        val logId = habitDao.insertLog(HabitLogEntity(habitId = habitId, epochDay = today, completedAt = now))
        if (logId == -1L) return ActionOutcome.fail("Already completed today ✅")

        val events = mutableListOf<GameEvent>()
        val diff = runCatching { Difficulty.valueOf(habit.difficulty) }.getOrDefault(Difficulty.MEDIUM)
        val cat = runCatching { HabitCategory.valueOf(habit.category) }.getOrDefault(HabitCategory.CUSTOM)

        var player = player()
        val tp = if (cat == HabitCategory.LEARNING) 1 else 0
        player = player.copy(
            coins = player.coins + diff.coins,
            totalCoinsEarned = player.totalCoinsEarned + diff.coins,
            trainingPoints = player.trainingPoints + tp,
        )
        player = gainPlayerXp(player, diff.playerXp, events)
        addItem("pet_food", 1)
        logActivity(ActivityTypes.HABIT, null)

        val doneToday = habitDao.countLogsForDay(today)
        val activeDone = habitDao.countActiveLogsForDay(today)
        val activeCount = habitDao.countActive()

        var reaction: Reaction? = Reaction.PET
        val partner = player.partnerPetId?.let { petDao.get(it) }
        if (partner != null) {
            val sp = SpeciesCatalog.byId(partner.speciesId)
            var pet = GameRules.applyDrift(partner, now)
            var loyalty = 2 + if (cat == HabitCategory.PERSONAL) 3 else 0
            var xp = diff.petXp
            pet = when (cat) {
                HabitCategory.MORNING -> pet.copy(happiness = (pet.happiness + 5).cap())
                HabitCategory.HEALTH -> pet.copy(health = (pet.health + 5).cap(), energy = (pet.energy + 5).cap())
                else -> pet
            }
            if (doneToday == 5 || doneToday == 10) {
                xp += 50
                loyalty += 10
                pet = pet.copy(happiness = (pet.happiness + 20).cap(), developmentPoints = pet.developmentPoints + 1)
                events += GameEvent.Celebration(
                    "Habit Power! ⚡",
                    "You completed $doneToday habits today!\n${pet.name} received +50 XP, +20 Happiness, +10 Loyalty and +1 Development Point.",
                    "⚡"
                )
                reaction = Reaction.LEVEL_UP
            }
            pet = addLoyalty(pet, GameRules.loyaltyFor(loyalty, sp), capped = false, events = events)
            pet = gainPetXp(pet, GameRules.xpFor(xp, sp), events)
            petDao.update(pet)
        }

        if (doneToday == 3) {
            addItem("healthy_treat", 1)
            events += GameEvent.Toast("3 habits today! +1 Healthy Treat", "🍪")
        }
        if (activeCount >= 3 && activeDone >= activeCount &&
            claimDao.insert(ClaimEntity("perfect:$today", now)) != -1L
        ) {
            addItem("golden_treat", 1)
            logActivity(ActivityTypes.PERFECT_DAY, null)
            events += GameEvent.Celebration("Perfect Day! 🌟", "You completed every habit today.\nYou earned a Golden Treat!", "🌟")
        }
        if (doneToday == 1) {
            val streak = Streaks.current(habitDao.logDays().toSet(), today)
            if (streak > 0 && streak % 7 == 0) {
                player = player.copy(coins = player.coins + 100, totalCoinsEarned = player.totalCoinsEarned + 100)
                addItem("premium_meal", 1)
                events += GameEvent.Celebration("$streak-day streak! 🔥", "Amazing consistency!\n+100 coins and a Premium Meal.", "🔥")
            }
        }
        playerDao.upsert(player)
        checkAchievements(events)

        val petPart = partner?.let { "  •  ${it.name} +${diff.petXp} XP" } ?: ""
        val tpPart = if (tp > 0) "  +1 🎯" else ""
        events.add(0, GameEvent.Toast("${habit.name} done!  +${diff.coins} 🪙  +1 🥣$tpPart$petPart", "✅"))
        return ActionOutcome(true, events, reaction, "💖", partner?.id)
    }

    // ---------------- Pet interactions ----------------
    suspend fun performAction(petId: Long, action: PetAction, itemId: String? = null): ActionOutcome =
        db.withTransaction { performActionTx(petId, action, itemId) }

    private suspend fun performActionTx(petId: Long, action: PetAction, itemId: String?): ActionOutcome {
        val now = Time.now()
        val today = Time.today()
        val original = petDao.get(petId) ?: return ActionOutcome.fail("Pet not found")
        var pet = GameRules.applyDrift(original, now)
        val sp = SpeciesCatalog.byId(pet.speciesId)
        val sleeping = pet.sleepUntil > now

        if (sleeping && action != PetAction.REST) {
            return ActionOutcome.fail("${pet.name} is napping 💤 Wake them up or let them rest.")
        }
        if (GameRules.bondLevel(pet.loyaltyPoints) < action.minBond) {
            return ActionOutcome.fail("Reach ${GameRules.bondName(action.minBond)} bond to unlock this.")
        }
        val cost = GameRules.energyCost(action, sp)
        if (cost > 0 && pet.energy < cost) {
            return ActionOutcome.fail("${pet.name} is a bit tired. Let them rest first 😴")
        }

        val events = mutableListOf<GameEvent>()
        var player = player()
        var xp = 0
        var loyalty = 0
        var reaction: Reaction? = null
        var reactionEmoji: String? = null
        var message = ""

        when (action) {
            PetAction.FEED -> {
                val item = ItemCatalog.find(itemId ?: "pet_food") ?: return ActionOutcome.fail("Choose some food first.")
                if (quantity(item.id) <= 0) return ActionOutcome.fail("No ${item.name} left. Complete habits or visit the Shop!")
                if (pet.fullness >= 95 && item.xp < 50) return ActionOutcome.fail("${pet.name} is full and content right now.")
                addItem(item.id, -1)
                pet = pet.copy(
                    fullness = (pet.fullness + item.fullness).cap(),
                    happiness = (pet.happiness + item.happiness).cap(),
                    health = (pet.health + item.health).cap(),
                )
                xp = item.xp
                loyalty = 3
                reaction = Reaction.EAT
                reactionEmoji = if (item.id == "pet_food") sp.diet.emoji else item.emoji
                message = "${pet.name} enjoyed the ${item.name}!"
            }
            PetAction.WATER -> {
                if (pet.hydration >= 95) return ActionOutcome.fail("${pet.name} isn't thirsty right now.")
                pet = pet.copy(hydration = (pet.hydration + 40).cap(), health = (pet.health + 2).cap())
                xp = 3
                loyalty = 2
                reaction = Reaction.DRINK
                reactionEmoji = "💧"
                message = "Fresh, cool water!"
            }
            PetAction.PET -> {
                val fr = if (sp.personality == Personality.GENTLE) 4 else 2
                pet = pet.copy(happiness = (pet.happiness + 6).cap(), friendship = (pet.friendship + fr).cap())
                xp = 2
                loyalty = 2
                reaction = Reaction.PET
                reactionEmoji = "❤️"
                message = if (sp.wild) "${pet.name} watched you calmly — trust is growing." else "${pet.name} loved the attention!"
            }
            PetAction.PLAY -> {
                val h = if (sp.personality == Personality.PLAYFUL) 22 else 15
                val fr = if (sp.personality == Personality.SOCIAL) 5 else 3
                pet = pet.copy(
                    happiness = (pet.happiness + h).cap(),
                    friendship = (pet.friendship + fr).cap(),
                    energy = (pet.energy - cost).coerceAtLeast(0),
                    fullness = (pet.fullness - 4).coerceAtLeast(40),
                )
                xp = 10
                loyalty = 4
                reaction = Reaction.PLAY
                reactionEmoji = sp.group.playEmoji
                message = if (sp.wild) "A fun enrichment session!" else "Playtime with ${pet.name}!"
            }
            PetAction.TOY -> {
                val toy = ItemCatalog.find(itemId) ?: return ActionOutcome.fail("Choose a toy first.")
                if (quantity(toy.id) <= 0) return ActionOutcome.fail("You don't own a ${toy.name} yet. Visit the Shop!")
                val favourite = sp.group in toy.favoriteOf
                pet = pet.copy(
                    happiness = (pet.happiness + if (favourite) 27 else 18).cap(),
                    friendship = (pet.friendship + 3).cap(),
                    energy = (pet.energy - cost).coerceAtLeast(0),
                )
                xp = if (favourite) 12 else 8
                loyalty = 3
                reaction = Reaction.TOY
                reactionEmoji = toy.emoji
                message = if (favourite) "${toy.name} is ${pet.name}'s favourite! ⭐" else "${pet.name} is having fun with the ${toy.name}."
            }
            PetAction.CLEAN -> {
                if (pet.cleanliness >= 95) return ActionOutcome.fail("The habitat is already sparkling ✨")
                pet = pet.copy(cleanliness = 100, happiness = (pet.happiness + 4).cap())
                xp = 4
                loyalty = 2
                reaction = Reaction.CLEAN
                reactionEmoji = "✨"
                message = "Sparkling clean habitat!"
            }
            PetAction.REST -> {
                if (sleeping) {
                    petDao.update(pet.copy(sleepUntil = 0))
                    return ActionOutcome(true, listOf(GameEvent.Toast("${pet.name} woke up refreshed!", "☀️")), petId = pet.id)
                }
                val gain = if (sp.personality == Personality.CALM) 60 else 40
                pet = pet.copy(sleepUntil = now + 40_000L, energy = (pet.energy + gain).cap(), health = (pet.health + 3).cap())
                xp = 2
                loyalty = 1
                reaction = Reaction.SLEEP
                reactionEmoji = "💤"
                message = "${pet.name} is taking a cozy nap."
            }
            PetAction.USE_ITEM -> {
                val item = ItemCatalog.find(itemId) ?: return ActionOutcome.fail("Choose an item first.")
                if (quantity(item.id) <= 0) return ActionOutcome.fail("You don't have any ${item.name}.")
                addItem(item.id, -1)
                pet = pet.copy(
                    cleanliness = (pet.cleanliness + item.cleanliness).cap(),
                    energy = (pet.energy + item.energy).cap(),
                    health = (pet.health + item.health).cap(),
                    happiness = (pet.happiness + item.happiness).cap(),
                    fullness = (pet.fullness + item.fullness).cap(),
                    developmentPoints = pet.developmentPoints + item.developmentPoints,
                )
                xp = item.xp
                loyalty = 2
                reaction = when {
                    item.developmentPoints > 0 -> Reaction.GROW
                    item.cleanliness > 0 -> Reaction.CLEAN
                    item.energy > 0 -> Reaction.CUDDLE
                    else -> Reaction.EAT
                }
                reactionEmoji = item.emoji
                message = if (item.developmentPoints > 0) "${pet.name} gained a Development Point! 💎" else "Used ${item.name} on ${pet.name}."
            }
            PetAction.TRAIN -> return ActionOutcome.fail("Open Training to start a session.")
            PetAction.WALK -> {
                if (!sp.walkable) return ActionOutcome.fail("${sp.name}s prefer exploring their own habitat.")
                pet = pet.copy(
                    happiness = (pet.happiness + 12).cap(),
                    health = (pet.health + 6).cap(),
                    energy = (pet.energy - cost).coerceAtLeast(0),
                    strength = (pet.strength + 1).cap(),
                    friendship = (pet.friendship + 2).cap(),
                )
                xp = 14
                loyalty = 4
                reaction = Reaction.WALK
                reactionEmoji = "🐾"
                message = "What a lovely walk!"
            }
            PetAction.TRICK -> {
                val learned = GameRules.learnedSkills(pet)
                if (learned.isEmpty()) return ActionOutcome.fail("Teach ${pet.name} a skill in Training first.")
                val skill = TrainingCatalog.skillsFor(sp.group, sp.wild).filter { it.id in learned }.randomOrNull()
                pet = pet.copy(happiness = (pet.happiness + 8).cap(), energy = (pet.energy - cost).coerceAtLeast(0))
                xp = if (sp.personality == Personality.PROUD) 15 else 10
                loyalty = 3
                reaction = Reaction.TRICK
                reactionEmoji = skill?.emoji ?: "✨"
                message = "${pet.name} performed ${skill?.name ?: "a trick"}! 👏"
            }
            PetAction.CUDDLE -> {
                pet = pet.copy(happiness = (pet.happiness + 15).cap(), friendship = (pet.friendship + 5).cap())
                xp = 6
                loyalty = 5
                reaction = Reaction.CUDDLE
                reactionEmoji = "💞"
                message = if (sp.wild) "A peaceful trust moment with ${pet.name} 🌿" else "Warm cuddles with ${pet.name}!"
            }
            PetAction.ADVENTURE -> {
                if (pet.lastAdventureDay == today) return ActionOutcome.fail("${pet.name} already explored today. Come back tomorrow!")
                val coins = Random.nextInt(30, 81)
                val foundId = listOf("healthy_treat", "pet_food", "vitamin_snack", "cloud_pillow").random()
                val found = ItemCatalog.byId(foundId)
                addItem(foundId, 1)
                player = player.copy(coins = player.coins + coins, totalCoinsEarned = player.totalCoinsEarned + coins)
                pet = pet.copy(lastAdventureDay = today, energy = (pet.energy - cost).coerceAtLeast(0), happiness = (pet.happiness + 10).cap())
                xp = 20
                loyalty = 5
                reaction = Reaction.ADVENTURE
                reactionEmoji = "🪙"
                message = "Adventure complete!"
                events += GameEvent.Celebration("Adventure complete! 🗺️", "${pet.name} discovered $coins coins and a ${found.name} ${found.emoji}!", "🗺️")
            }
            PetAction.GIFT -> {
                if (pet.lastGiftDay == today) return ActionOutcome.fail("${pet.name} already gave you a gift today 🎁")
                val roll = Random.nextInt(100)
                val giftText = when {
                    roll < 20 -> { addItem("golden_treat", 1); "a Golden Treat 🌟" }
                    roll < 60 -> { addItem("premium_meal", 1); "a Premium Meal 🥗" }
                    else -> {
                        player = player.copy(coins = player.coins + 100, totalCoinsEarned = player.totalCoinsEarned + 100)
                        "100 coins 🪙"
                    }
                }
                pet = pet.copy(lastGiftDay = today)
                xp = 5
                reaction = Reaction.GIFT
                reactionEmoji = "🎁"
                message = "A gift from ${pet.name}!"
                events += GameEvent.Celebration("A gift from ${pet.name}! 🎁", "Your unbreakable bond brought you $giftText.", "🎁")
            }
        }

        val loyaltyBefore = pet.loyaltyPoints
        pet = addLoyalty(pet, GameRules.loyaltyFor(loyalty, sp), capped = true, events = events)
        val loyaltyGained = pet.loyaltyPoints - loyaltyBefore
        val xpGain = GameRules.xpFor(xp, sp)
        pet = gainPetXp(pet, xpGain, events)
        player = gainPlayerXp(player, 2, events)
        petDao.update(pet)
        playerDao.upsert(player)
        logActivity(action.name, pet.id)
        checkAchievements(events)

        val parts = buildList {
            if (xpGain > 0) add("+$xpGain XP")
            if (loyaltyGained > 0) add("+$loyaltyGained 💞")
            else if (loyalty > 0) add("daily bond limit reached")
        }
        val suffix = if (parts.isEmpty()) "" else "  " + parts.joinToString("  ")
        events.add(0, GameEvent.Toast(message + suffix, action.emoji))
        return ActionOutcome(true, events, reaction, reactionEmoji, pet.id)
    }

    suspend fun train(petId: Long, skillId: String, hits: Int): ActionOutcome =
        db.withTransaction { trainTx(petId, skillId, hits.coerceIn(0, 3)) }

    private suspend fun trainTx(petId: Long, skillId: String, hits: Int): ActionOutcome {
        val now = Time.now()
        val original = petDao.get(petId) ?: return ActionOutcome.fail("Pet not found")
        var pet = GameRules.applyDrift(original, now)
        val sp = SpeciesCatalog.byId(pet.speciesId)
        if (pet.sleepUntil > now) return ActionOutcome.fail("${pet.name} is napping 💤")
        val skill = TrainingCatalog.skillsFor(sp.group, sp.wild).firstOrNull { it.id == skillId }
            ?: return ActionOutcome.fail("Unknown skill")
        if (pet.stage < skill.minStage) return ActionOutcome.fail("Requires growth stage ${skill.minStage}.")
        var player = player()
        if (player.trainingPoints < 1) return ActionOutcome.fail("No Training Points left. Complete Learning habits to earn more 🎯")
        val cost = GameRules.energyCost(PetAction.TRAIN, sp)
        if (pet.energy < cost) return ActionOutcome.fail("${pet.name} is a bit tired. Let them rest first 😴")

        val events = mutableListOf<GameEvent>()
        player = player.copy(trainingPoints = player.trainingPoints - 1)
        val gain = 1 + hits
        pet = if (skill.focus == SkillFocus.INTELLIGENCE) {
            pet.copy(intelligence = (pet.intelligence + gain + if (sp.personality == Personality.CURIOUS) 1 else 0).cap())
        } else {
            pet.copy(strength = (pet.strength + gain + if (sp.personality == Personality.BRAVE) 1 else 0).cap())
        }
        pet = pet.copy(
            energy = (pet.energy - cost).coerceAtLeast(0),
            happiness = (pet.happiness + 4 + hits * 2).cap(),
            friendship = (pet.friendship + 2).cap(),
        )
        val progress = GameRules.parseProgress(pet.skillProgress).toMutableMap()
        val learned = GameRules.learnedSkills(pet).toMutableSet()
        if (skill.id !in learned && hits >= 1) {
            val next = (progress[skill.id] ?: 0) + 1
            progress[skill.id] = next
            if (next >= skill.sessions) {
                learned += skill.id
                events += GameEvent.Celebration(
                    "New skill learned! 🎓",
                    "${pet.name} mastered ${skill.emoji} ${skill.name}!\nTry “Show Trick” once you reach Friend bond.",
                    "🎓"
                )
            }
        }
        pet = pet.copy(skillProgress = GameRules.encodeProgress(progress), learnedSkills = learned.joinToString(","))
        pet = addLoyalty(pet, GameRules.loyaltyFor(3 + hits, sp), capped = true, events = events)
        val xpGain = GameRules.xpFor(12 + hits * 6, sp)
        pet = gainPetXp(pet, xpGain, events)
        player = gainPlayerXp(player, 5 + hits * 2, events)
        petDao.update(pet)
        playerDao.upsert(player)
        logActivity(PetAction.TRAIN.name, pet.id)
        checkAchievements(events)
        events.add(0, GameEvent.Toast("Training done: $hits/3 ⭐  +$xpGain XP", "🎯"))
        return ActionOutcome(true, events, Reaction.TRAIN, "⭐", pet.id)
    }

    suspend fun grow(petId: Long): ActionOutcome = db.withTransaction { growTx(petId) }

    private suspend fun growTx(petId: Long): ActionOutcome {
        val pet = petDao.get(petId) ?: return ActionOutcome.fail("Pet not found")
        if (!GameRules.canGrow(pet)) return ActionOutcome.fail("${pet.name} isn't ready to grow yet.")
        val sp = SpeciesCatalog.byId(pet.speciesId)
        val next = pet.stage + 1
        val updated = pet.copy(
            stage = next,
            developmentPoints = pet.developmentPoints - GameRules.dpForStage(next),
            happiness = 100,
            energy = 100,
        )
        petDao.update(updated)
        val events = mutableListOf<GameEvent>()
        val ability = sp.abilities.getOrNull(next - 2)
        events += GameEvent.Celebration(
            "${pet.name} grew up! 🌟",
            "${pet.name} is now a ${sp.stageName(next)}.\nNew ability: ${ability ?: "—"}\nNew animations, activities and accessories unlocked!",
            sp.emoji
        )
        var player = player()
        player = gainPlayerXp(player, 30, events)
        playerDao.upsert(player)
        logActivity(ActivityTypes.GROW, petId)
        checkAchievements(events)
        return ActionOutcome(true, events, Reaction.GROW, "🌟", petId)
    }

    suspend fun adopt(speciesId: String, name: String): ActionOutcome = db.withTransaction { adoptTx(speciesId, name) }

    private suspend fun adoptTx(speciesId: String, name: String): ActionOutcome {
        val sp = SpeciesCatalog.find(speciesId) ?: return ActionOutcome.fail("Unknown species")
        if (petDao.getBySpecies(speciesId) != null) return ActionOutcome.fail("${sp.name} is already part of your world.")
        var player = player()
        if (player.level < sp.minLevel) return ActionOutcome.fail("Requires Trainer Level ${sp.minLevel}.")
        if (player.coins < sp.setupCost) return ActionOutcome.fail("Habitat setup needs ${sp.setupCost} coins.")
        if (sp.needsBestFriend && petDao.getAll().none { GameRules.bondLevel(it.loyaltyPoints) >= 5 }) {
            return ActionOutcome.fail("Mythical creatures appear only to trainers who share a Best Friend bond.")
        }
        val petName = name.trim().ifBlank { sp.name }
        val id = petDao.insert(PetEntity(speciesId = speciesId, name = petName))
        val events = mutableListOf<GameEvent>()
        player = player.copy(coins = player.coins - sp.setupCost, partnerPetId = player.partnerPetId ?: id)
        player = gainPlayerXp(player, 20, events)
        playerDao.upsert(player)
        logActivity(ActivityTypes.ADOPT, id)
        checkAchievements(events)
        events.add(
            0,
            if (sp.wild) GameEvent.Celebration(
                "Welcome to the reserve!",
                "$petName the ${sp.name} is now under your care in the ${sp.habitat.title}.\nWild animals live freely in a protected virtual sanctuary.",
                sp.emoji
            ) else GameEvent.Celebration("Welcome home, $petName!", "$petName the ${sp.name} joined your PetVerse family!", sp.emoji)
        )
        return ActionOutcome(true, events, Reaction.GROW, "✨", id)
    }

    suspend fun rename(petId: Long, name: String) {
        db.withTransaction {
            petDao.get(petId)?.let { if (name.isNotBlank()) petDao.update(it.copy(name = name.trim())) }
        }
    }

    suspend fun setPartner(petId: Long) {
        updatePlayer { it.copy(partnerPetId = petId) }
    }

    suspend fun equip(petId: Long, itemId: String?): ActionOutcome = db.withTransaction { equipTx(petId, itemId) }

    private suspend fun equipTx(petId: Long, itemId: String?): ActionOutcome {
        val pet = petDao.get(petId) ?: return ActionOutcome.fail("Pet not found")
        if (itemId == null) {
            petDao.update(pet.copy(accessory = null))
            return ActionOutcome(true, listOf(GameEvent.Toast("Accessory removed", "👕")))
        }
        val item = ItemCatalog.find(itemId) ?: return ActionOutcome.fail("Unknown item")
        if (quantity(itemId) <= 0) return ActionOutcome.fail("Buy the ${item.name} in the Shop first.")
        if (GameRules.bondLevel(pet.loyaltyPoints) < 3) return ActionOutcome.fail("Accessories unlock at Friend bond.")
        if (pet.stage < item.minStage) return ActionOutcome.fail("${item.name} unlocks at growth stage ${item.minStage}.")
        petDao.update(pet.copy(accessory = itemId))
        return ActionOutcome(true, listOf(GameEvent.Toast("${pet.name} looks amazing in the ${item.name}!", item.emoji)), Reaction.TRICK, item.emoji, petId)
    }

    // ---------------- Shop ----------------
    suspend fun buy(itemId: String): ActionOutcome = db.withTransaction { buyTx(itemId) }

    private suspend fun buyTx(itemId: String): ActionOutcome {
        val item = ItemCatalog.find(itemId) ?: return ActionOutcome.fail("Unknown item")
        val price = item.price ?: return ActionOutcome.fail("This item can't be bought.")
        if (item.permanent && quantity(itemId) > 0) return ActionOutcome.fail("You already own the ${item.name}.")
        val player = player()
        if (player.coins < price) return ActionOutcome.fail("Not enough coins. Complete habits to earn more 🪙")
        playerDao.upsert(player.copy(coins = player.coins - price))
        addItem(itemId, 1)
        logActivity(ActivityTypes.SHOP, null)
        return ActionOutcome(true, listOf(GameEvent.Toast("Bought ${item.name}!", item.emoji)))
    }

    // ---------------- Missions & achievements ----------------
    suspend fun claimMission(def: MissionDef): ActionOutcome = db.withTransaction { claimMissionTx(def) }

    private suspend fun claimMissionTx(def: MissionDef): ActionOutcome {
        val today = Time.today()
        val start = MissionEngine.periodStart(def.period, today)
        val progress = MissionEngine.progress(def, activityDao.getSince(start), habitDao.logDays().toSet(), today)
        if (progress < def.target) return ActionOutcome.fail("Mission not complete yet.")
        val key = MissionEngine.claimKey(def, today)
        if (claimDao.insert(ClaimEntity(key, Time.now())) == -1L) return ActionOutcome.fail("Already claimed.")
        val events = mutableListOf<GameEvent>()
        var player = player()
        player = player.copy(
            coins = player.coins + def.coins,
            totalCoinsEarned = player.totalCoinsEarned + def.coins,
            trainingPoints = player.trainingPoints + def.trainingPoints,
        )
        player = gainPlayerXp(player, def.xp, events)
        def.itemId?.let { addItem(it, def.itemQty) }
        playerDao.upsert(player)
        checkAchievements(events)
        val itemText = def.itemId?.let { "  +${def.itemQty} ${ItemCatalog.byId(it).emoji}" } ?: ""
        val tpText = if (def.trainingPoints > 0) "  +${def.trainingPoints} 🎯" else ""
        events.add(0, GameEvent.Toast("Mission complete! +${def.coins} 🪙  +${def.xp} XP$itemText$tpText", def.emoji))
        return ActionOutcome(true, events)
    }

    suspend fun claimAchievement(id: String): ActionOutcome = db.withTransaction { claimAchievementTx(id) }

    private suspend fun claimAchievementTx(id: String): ActionOutcome {
        val def = AchievementCatalog.byId(id) ?: return ActionOutcome.fail("Unknown badge")
        if (achievementDao.getAll().none { it.id == id }) return ActionOutcome.fail("Badge not unlocked yet.")
        if (claimDao.insert(ClaimEntity("ach:$id", Time.now())) == -1L) return ActionOutcome.fail("Reward already claimed.")
        val player = player()
        playerDao.upsert(player.copy(coins = player.coins + def.coins, totalCoinsEarned = player.totalCoinsEarned + def.coins))
        def.itemId?.let { addItem(it, 1) }
        val itemText = def.itemId?.let { "  +1 ${ItemCatalog.byId(it).emoji}" } ?: ""
        return ActionOutcome(true, listOf(GameEvent.Toast("${def.title} reward: +${def.coins} 🪙$itemText", def.emoji)))
    }

    // ---------------- Internals ----------------
    private suspend fun player(): PlayerEntity = playerDao.get() ?: PlayerEntity().also { playerDao.upsert(it) }

    private suspend fun quantity(itemId: String): Int = inventoryDao.quantity(itemId) ?: 0

    private suspend fun addItem(itemId: String, delta: Int) {
        val current = quantity(itemId)
        inventoryDao.upsert(InventoryEntity(itemId, (current + delta).coerceAtLeast(0)))
    }

    private suspend fun logActivity(type: String, petId: Long?) {
        activityDao.insert(ActivityEntity(type = type, petId = petId, epochDay = Time.today(), timestamp = Time.now()))
    }

    private suspend fun currentStats(): GameStats = StatsCalculator.compute(
        player = player(),
        pets = petDao.getAll(),
        logDays = habitDao.logDays(),
        totalHabits = habitDao.countLogs(),
        counts = activityDao.getCounts().associate { it.type to it.total },
        today = Time.today(),
    )

    private suspend fun checkAchievements(events: MutableList<GameEvent>) {
        val unlocked = achievementDao.getAll().map { it.id }.toSet()
        val stats = currentStats()
        AchievementCatalog.all.forEach { def ->
            if (def.id !in unlocked && StatsCalculator.achievementProgress(def, stats) >= def.target) {
                achievementDao.insert(AchievementEntity(def.id, Time.now()))
                events += GameEvent.Celebration(
                    "Badge unlocked!",
                    "${def.emoji} ${def.title}\n${def.description}\nClaim your reward in Achievements.",
                    "🏅"
                )
            }
        }
    }

    private fun addLoyalty(pet: PetEntity, amount: Int, capped: Boolean, events: MutableList<GameEvent>): PetEntity {
        if (amount <= 0) return pet
        val today = Time.today()
        val gainedToday = if (pet.dailyLoyaltyDay == today) pet.dailyLoyaltyGained else 0
        val add = if (capped) amount.coerceAtMost((GameRules.DAILY_LOYALTY_CAP - gainedToday).coerceAtLeast(0)) else amount
        if (add <= 0) return pet
        val before = GameRules.bondLevel(pet.loyaltyPoints)
        val newPoints = pet.loyaltyPoints + add
        val after = GameRules.bondLevel(newPoints)
        if (after > before) {
            events += GameEvent.Celebration(
                "Bond level up! ${GameRules.bondEmoji(after)}",
                "${pet.name} is now your ${GameRules.bondName(after)}.\nUnlocked: ${GameRules.bondUnlocks[after - 1]}",
                GameRules.bondEmoji(after)
            )
        }
        return pet.copy(
            loyaltyPoints = newPoints,
            dailyLoyaltyDay = today,
            dailyLoyaltyGained = gainedToday + if (capped) add else 0,
        )
    }

    private fun gainPetXp(pet: PetEntity, amount: Int, events: MutableList<GameEvent>): PetEntity {
        if (amount <= 0 || pet.level >= GameRules.MAX_PET_LEVEL) return pet
        val couldGrow = GameRules.canGrow(pet)
        var level = pet.level
        var xp = pet.xp + amount
        while (level < GameRules.MAX_PET_LEVEL && xp >= GameRules.petXpForNext(level)) {
            xp -= GameRules.petXpForNext(level)
            level++
            events += GameEvent.Toast("${pet.name} reached level $level!", "⬆️")
        }
        if (level >= GameRules.MAX_PET_LEVEL) xp = 0
        val updated = pet.copy(level = level, xp = xp)
        if (!couldGrow && GameRules.canGrow(updated)) {
            events += GameEvent.Toast("${pet.name} is ready to grow! Open their page 🌱", "🌱")
        }
        return updated
    }

    private fun gainPlayerXp(p: PlayerEntity, amount: Int, events: MutableList<GameEvent>): PlayerEntity {
        if (amount <= 0) return p
        var level = p.level
        var xp = p.xp + amount
        var coins = p.coins
        var earned = p.totalCoinsEarned
        while (level < GameRules.MAX_PLAYER_LEVEL && xp >= GameRules.playerXpForNext(level)) {
            xp -= GameRules.playerXpForNext(level)
            level++
            val bonus = 40 + level * 10
            coins += bonus
            earned += bonus
            val newAreas = EnvironmentId.entries.filter { it.unlockLevel == level }
            val areaText = if (newAreas.isEmpty()) "" else "\nNew area unlocked: " + newAreas.joinToString { it.title }
            val speciesCount = SpeciesCatalog.all.count { it.minLevel == level }
            val speciesText = if (speciesCount > 0) "\n$speciesCount new species can now be discovered!" else ""
            events += GameEvent.Celebration("Trainer Level $level!", "You earned $bonus coins.$areaText$speciesText", "🏆")
        }
        if (level >= GameRules.MAX_PLAYER_LEVEL) xp = 0
        return p.copy(level = level, xp = xp, coins = coins, totalCoinsEarned = earned)
    }

    private fun Int.cap(): Int = coerceIn(0, 100)
}
