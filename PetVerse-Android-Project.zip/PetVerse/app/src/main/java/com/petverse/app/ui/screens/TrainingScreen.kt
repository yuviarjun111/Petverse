package com.petverse.app.ui.screens

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavHostController
import com.petverse.app.data.catalog.SkillDef
import com.petverse.app.data.catalog.SpeciesCatalog
import com.petverse.app.data.catalog.TrainingCatalog
import com.petverse.app.data.model.EnvironmentId
import com.petverse.app.data.model.PetAction
import com.petverse.app.data.model.Reaction
import com.petverse.app.domain.GameRules
import com.petverse.app.ui.GameViewModel
import com.petverse.app.ui.components.AnimatedPet
import com.petverse.app.ui.components.CurrencyChip
import com.petverse.app.ui.components.EnvironmentBackdrop
import com.petverse.app.ui.components.GradientButton
import com.petverse.app.ui.components.PVCard
import com.petverse.app.ui.components.Pill
import com.petverse.app.ui.components.ProgressTrack
import com.petverse.app.ui.components.ScreenHeader
import com.petverse.app.ui.components.StatBar
import com.petverse.app.ui.components.rememberNow
import com.petverse.app.ui.theme.EnergyColor
import kotlin.random.Random

// ------------------------------------------------------------------
// 8. Pet Training — timing mini-game
// ------------------------------------------------------------------

@Composable
fun TrainingScreen(vm: GameViewModel, nav: NavHostController, petId: Long) {
    val pets by vm.pets.collectAsStateWithLifecycle()
    val player by vm.player.collectAsStateWithLifecycle()
    val reaction by vm.reaction.collectAsStateWithLifecycle()
    val now by rememberNow()
    val haptics = LocalHapticFeedback.current

    var selected by remember { mutableStateOf<SkillDef?>(null) }
    var playing by remember { mutableStateOf(false) }
    var round by remember { mutableIntStateOf(0) }
    var results by remember { mutableStateOf(listOf<Boolean>()) }
    var zoneStart by remember { mutableFloatStateOf(0.4f) }
    var zoneWidth by remember { mutableFloatStateOf(0.26f) }
    var finished by remember { mutableStateOf(false) }
    val marker = remember { Animatable(0f) }

    val pet = pets.firstOrNull { it.id == petId }
    val p = player
    if (pet == null || p == null) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
        return
    }
    val sp = SpeciesCatalog.byId(pet.speciesId)
    val skills = TrainingCatalog.skillsFor(sp.group, sp.wild)
    val learned = GameRules.learnedSkills(pet)
    val progress = GameRules.parseProgress(pet.skillProgress)
    val cost = GameRules.energyCost(PetAction.TRAIN, sp)
    val sleeping = pet.sleepUntil > now
    val r = reaction?.takeIf { it.petId == pet.id }

    LaunchedEffect(playing, round) {
        if (playing && round < 3) {
            zoneWidth = listOf(0.28f, 0.21f, 0.15f)[round]
            zoneStart = Random.nextFloat() * (1f - zoneWidth)
            val duration = listOf(1150, 900, 700)[round]
            marker.snapTo(0f)
            while (true) {
                marker.animateTo(1f, tween(duration, easing = LinearEasing))
                marker.animateTo(0f, tween(duration, easing = LinearEasing))
            }
        }
    }

    fun start(skill: SkillDef) {
        when {
            sleeping -> vm.problem("${pet.name} is napping 💤")
            p.trainingPoints < 1 -> vm.problem("No Training Points. Complete Learning habits (📚) to earn more!")
            pet.energy < cost -> vm.problem("${pet.name} needs rest before training 😴")
            pet.stage < skill.minStage -> vm.problem("${skill.name} unlocks at growth stage ${skill.minStage}.")
            else -> {
                selected = skill
                results = emptyList()
                round = 0
                finished = false
                playing = true
            }
        }
    }

    fun command() {
        if (!playing) return
        val pos = marker.value
        val hit = pos >= zoneStart && pos <= zoneStart + zoneWidth
        if (p.hapticsEnabled) haptics.performHapticFeedback(HapticFeedbackType.LongPress)
        results = results + hit
        if (hit) vm.localReaction(pet.id, Reaction.TRAIN, "⭐")
        if (round >= 2) {
            playing = false
            finished = true
            val skill = selected
            if (skill != null) vm.train(pet.id, skill.id, results.count { it })
        } else {
            round++
        }
    }

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 28.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        item {
            ScreenHeader("Training", onBack = { nav.popBackStack() }, subtitle = "${pet.name} • ${sp.stageName(pet.stage)}") {
                CurrencyChip("🎯", p.trainingPoints)
            }
        }
        item {
            EnvironmentBackdrop(EnvironmentId.TRAINING_GROUND, Modifier.fillMaxWidth().height(230.dp)) {
                AnimatedPet(
                    sp, pet.stage, Modifier.align(Alignment.Center).padding(top = 30.dp), size = 170.dp,
                    accessory = pet.accessory, sleeping = sleeping,
                    reaction = r?.reaction, reactionEmoji = r?.emoji, reactionNonce = r?.nonce ?: 0L,
                )
                val sk = selected
                if (sk != null && (playing || finished)) {
                    Pill("${sk.emoji} ${sk.name}", Modifier.align(Alignment.TopCenter).padding(12.dp), color = Color(0xFF5B3FE0), filled = true)
                }
            }
        }
        item {
            PVCard {
                StatBar("⚡", "Energy (training costs $cost)", pet.energy, EnergyColor)
                Spacer(Modifier.height(8.dp))
                Text(
                    "Each session uses 1 🎯 Training Point. Tap COMMAND when the marker is inside the green zone. 3 rounds — more hits, bigger rewards!",
                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }

        if (playing || finished) {
            item {
                PVCard {
                    Text(
                        if (playing) "Round ${round + 1} of 3" else "Session complete!",
                        style = MaterialTheme.typography.titleLarge,
                    )
                    Spacer(Modifier.height(4.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        repeat(3) { i ->
                            val res = results.getOrNull(i)
                            Text(
                                when (res) {
                                    true -> "⭐"
                                    false -> "✖️"
                                    null -> "◻️"
                                },
                                fontSize = 26.sp,
                            )
                        }
                    }
                    Spacer(Modifier.height(14.dp))
                    BoxWithConstraints(
                        Modifier
                            .fillMaxWidth()
                            .height(46.dp)
                            .clip(RoundedCornerShape(50))
                            .background(MaterialTheme.colorScheme.surfaceVariant)
                    ) {
                        val w = maxWidth
                        Box(
                            Modifier
                                .offset(x = w * zoneStart)
                                .width(w * zoneWidth)
                                .fillMaxHeight()
                                .background(Color(0xFF2ED3A5).copy(alpha = 0.75f))
                        )
                        Box(
                            Modifier
                                .offset(x = (w - 8.dp) * marker.value)
                                .width(8.dp)
                                .fillMaxHeight()
                                .clip(RoundedCornerShape(50))
                                .background(Color(0xFFFFB547))
                        )
                    }
                    Spacer(Modifier.height(14.dp))
                    if (playing) {
                        GradientButton("COMMAND!", onClick = { command() }, modifier = Modifier.fillMaxWidth(), emoji = "📣")
                    } else {
                        val hits = results.count { it }
                        Text(
                            when (hits) {
                                3 -> "Perfect session! ${pet.name} nailed it! 🏆"
                                2 -> "Great job! ${pet.name} is improving fast."
                                1 -> "Good effort — practice makes perfect."
                                else -> "Tricky one! ${pet.name} still had fun and earned XP."
                            },
                            style = MaterialTheme.typography.bodyMedium,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.fillMaxWidth(),
                        )
                        Spacer(Modifier.height(10.dp))
                        GradientButton(
                            "Train again", onClick = { selected?.let { start(it) } },
                            modifier = Modifier.fillMaxWidth(), emoji = "🔁",
                        )
                    }
                }
            }
        }

        item { Text("Skills", style = MaterialTheme.typography.titleLarge) }
        items(skills, key = { it.id }) { skill ->
            val done = skill.id in learned
            val locked = pet.stage < skill.minStage
            val prog = if (done) skill.sessions else (progress[skill.id] ?: 0)
            Row(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(20.dp))
                    .background(MaterialTheme.colorScheme.surface)
                    .border(
                        1.5.dp,
                        if (selected?.id == skill.id) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline.copy(alpha = 0.5f),
                        RoundedCornerShape(20.dp),
                    )
                    .clickable(enabled = !playing) { start(skill) }
                    .padding(14.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(if (locked) "🔒" else skill.emoji, fontSize = 28.sp)
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(skill.name, style = MaterialTheme.typography.titleSmall)
                    Text(
                        if (locked) "Unlocks at stage ${skill.minStage}" else "${skill.focus.emoji} ${skill.focus.label} • ${skill.sessions} good sessions to master",
                        style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    Spacer(Modifier.height(6.dp))
                    ProgressTrack(prog / skill.sessions.toFloat(), MaterialTheme.colorScheme.primary, Modifier.fillMaxWidth().height(6.dp))
                }
                Spacer(Modifier.width(10.dp))
                Text(if (done) "🎓" else "▶️", fontSize = 22.sp, modifier = Modifier.size(28.dp))
            }
        }
    }
}
