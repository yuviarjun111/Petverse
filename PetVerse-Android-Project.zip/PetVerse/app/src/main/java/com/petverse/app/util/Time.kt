package com.petverse.app.util

import java.time.DayOfWeek
import java.time.LocalDate
import java.time.LocalTime
import java.time.format.TextStyle
import java.util.Locale

object Time {
    fun now(): Long = System.currentTimeMillis()
    fun today(): Long = LocalDate.now().toEpochDay()
    fun weekStart(day: Long): Long = LocalDate.ofEpochDay(day).with(DayOfWeek.MONDAY).toEpochDay()
    fun monthStart(day: Long): Long = LocalDate.ofEpochDay(day).withDayOfMonth(1).toEpochDay()

    fun shortDay(day: Long): String =
        LocalDate.ofEpochDay(day).dayOfWeek.getDisplayName(TextStyle.SHORT, Locale.getDefault())

    fun dayOfMonth(day: Long): Int = LocalDate.ofEpochDay(day).dayOfMonth

    fun prettyDate(day: Long): String {
        val d = LocalDate.ofEpochDay(day)
        val dow = d.dayOfWeek.getDisplayName(TextStyle.FULL, Locale.getDefault())
        val month = d.month.getDisplayName(TextStyle.SHORT, Locale.getDefault())
        return "$dow, $month ${d.dayOfMonth}"
    }

    fun daysLeftInWeek(day: Long): Long = 6 - (day - weekStart(day))

    fun daysLeftInMonth(day: Long): Long {
        val d = LocalDate.ofEpochDay(day)
        return (d.lengthOfMonth() - d.dayOfMonth).toLong()
    }

    fun greeting(): String {
        val h = LocalTime.now().hour
        return when {
            h < 5 -> "Good night"
            h < 12 -> "Good morning"
            h < 17 -> "Good afternoon"
            else -> "Good evening"
        }
    }

    fun formatTime(hour: Int, minute: Int): String {
        val h12 = if (hour % 12 == 0) 12 else hour % 12
        val ampm = if (hour < 12) "AM" else "PM"
        return "%d:%02d %s".format(h12, minute, ampm)
    }
}

object Streaks {
    /** Consecutive days ending today (or yesterday, so a streak stays alive until the day ends). */
    fun current(days: Set<Long>, today: Long): Int {
        var d = if (today in days) today else today - 1
        var count = 0
        while (d in days) {
            count++
            d--
        }
        return count
    }

    fun best(days: Collection<Long>): Int {
        if (days.isEmpty()) return 0
        val sorted = days.toSortedSet().toList()
        var best = 1
        var run = 1
        for (i in 1 until sorted.size) {
            if (sorted[i] == sorted[i - 1] + 1) {
                run++
                if (run > best) best = run
            } else {
                run = 1
            }
        }
        return best
    }
}
