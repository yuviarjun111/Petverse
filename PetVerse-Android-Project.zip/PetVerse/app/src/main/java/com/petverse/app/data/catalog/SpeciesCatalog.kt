package com.petverse.app.data.catalog

import com.petverse.app.data.model.AnimStyle
import com.petverse.app.data.model.AnimalCategory
import com.petverse.app.data.model.Diet
import com.petverse.app.data.model.EnvironmentId
import com.petverse.app.data.model.Personality
import com.petverse.app.data.model.Rarity
import com.petverse.app.data.model.SpeciesGroup

data class Species(
    val id: String,
    val name: String,
    val emoji: String,
    val category: AnimalCategory,
    val group: SpeciesGroup,
    val rarity: Rarity,
    val habitat: EnvironmentId,
    val personality: Personality,
    val diet: Diet,
    val tint: Long,
    val description: String,
    val wild: Boolean = false,
    val walkable: Boolean = group.walkable,
    val styleOverride: AnimStyle? = null,
    val aura: String? = null,
) {
    val style: AnimStyle get() = styleOverride ?: group.style
    val minLevel: Int get() = maxOf(rarity.minLevel, habitat.unlockLevel)
    val setupCost: Int get() = rarity.setupCost
    val needsBestFriend: Boolean get() = rarity == Rarity.MYTHICAL
    fun stageName(stage: Int): String = group.stages[(stage - 1).coerceIn(0, 4)]
    val abilities: List<String> get() = group.abilities

    /** Ability index i unlocks at growth stage i + 2. */
    fun abilityUnlockStage(index: Int): Int = index + 2
}

object SpeciesCatalog {
    private val M = AnimalCategory.MAMMAL
    private val B = AnimalCategory.BIRD
    private val A = AnimalCategory.AQUATIC
    private val R = AnimalCategory.REPTILE
    private val X = AnimalCategory.MYTHICAL

    val all: List<Species> = listOf(
        // ---------------- Dogs ----------------
        Species("mixed_puppy", "Mixed-Breed Puppy", "🐶", M, SpeciesGroup.DOG, Rarity.COMMON, EnvironmentId.DOG_PARK,
            Personality.PLAYFUL, Diet.OMNIVORE, 0xFFFFC07A, "A cheerful bundle of energy who loves every person it meets."),
        Species("labrador", "Labrador", "🦮", M, SpeciesGroup.DOG, Rarity.COMMON, EnvironmentId.DOG_PARK,
            Personality.SOCIAL, Diet.OMNIVORE, 0xFFF2C46D, "Friendly, patient and always ready to help."),
        Species("pug", "Pug", "🐶", M, SpeciesGroup.DOG, Rarity.COMMON, EnvironmentId.DOG_PARK,
            Personality.CALM, Diet.OMNIVORE, 0xFFE0B98A, "A small comedian with a big heart and a love of naps."),
        Species("beagle", "Beagle", "🐕", M, SpeciesGroup.DOG, Rarity.UNCOMMON, EnvironmentId.DOG_PARK,
            Personality.CURIOUS, Diet.OMNIVORE, 0xFFD9A066, "Follows its nose on every adventure."),
        Species("golden_retriever", "Golden Retriever", "🐕", M, SpeciesGroup.DOG, Rarity.UNCOMMON, EnvironmentId.DOG_PARK,
            Personality.GENTLE, Diet.OMNIVORE, 0xFFFFC857, "Gentle, loyal and famous for its sunny smile."),
        Species("poodle", "Poodle", "🐩", M, SpeciesGroup.DOG, Rarity.UNCOMMON, EnvironmentId.DOG_PARK,
            Personality.PROUD, Diet.OMNIVORE, 0xFFF4B6D2, "Elegant, clever and a natural performer."),
        Species("husky", "Husky", "🐕", M, SpeciesGroup.DOG, Rarity.RARE, EnvironmentId.DOG_PARK,
            Personality.ENERGETIC, Diet.OMNIVORE, 0xFFB8D4F0, "Built for snowy trails and long runs."),
        Species("german_shepherd", "German Shepherd", "🐕‍🦺", M, SpeciesGroup.DOG, Rarity.RARE, EnvironmentId.DOG_PARK,
            Personality.LOYAL, Diet.OMNIVORE, 0xFFC9925A, "Smart, devoted and eager to learn new tasks."),
        Species("rottweiler", "Rottweiler", "🐕", M, SpeciesGroup.DOG, Rarity.RARE, EnvironmentId.DOG_PARK,
            Personality.BRAVE, Diet.OMNIVORE, 0xFFA77A55, "Strong and protective, with a soft spot for cuddles."),

        // ---------------- Cats ----------------
        Species("kitten", "Kitten", "🐱", M, SpeciesGroup.CAT, Rarity.COMMON, EnvironmentId.CAT_HOUSE,
            Personality.PLAYFUL, Diet.CARNIVORE, 0xFFFFB38A, "Tiny paws, big curiosity and endless pounces."),
        Species("black_cat", "Black Cat", "🐈‍⬛", M, SpeciesGroup.CAT, Rarity.UNCOMMON, EnvironmentId.CAT_HOUSE,
            Personality.CURIOUS, Diet.CARNIVORE, 0xFF9D8CD8, "A sleek explorer of shadows and sunbeams."),
        Species("persian", "Persian Cat", "🐈", M, SpeciesGroup.CAT, Rarity.UNCOMMON, EnvironmentId.CAT_HOUSE,
            Personality.CALM, Diet.CARNIVORE, 0xFFF3D9C6, "Fluffy, serene and fond of soft pillows."),
        Species("siamese", "Siamese Cat", "🐈", M, SpeciesGroup.CAT, Rarity.UNCOMMON, EnvironmentId.CAT_HOUSE,
            Personality.SOCIAL, Diet.CARNIVORE, 0xFFE8D2B0, "Chatty and affectionate — always has something to say."),
        Species("bengal", "Bengal Cat", "🐈", M, SpeciesGroup.CAT, Rarity.RARE, EnvironmentId.CAT_HOUSE,
            Personality.ENERGETIC, Diet.CARNIVORE, 0xFFFFB04D, "A spotted acrobat who loves climbing high."),
        Species("maine_coon", "Maine Coon", "🐈", M, SpeciesGroup.CAT, Rarity.RARE, EnvironmentId.CAT_HOUSE,
            Personality.GENTLE, Diet.CARNIVORE, 0xFFC79A6B, "A gentle giant of the cat world."),

        // ---------------- Small mammals ----------------
        Species("rabbit", "Rabbit", "🐰", M, SpeciesGroup.SMALL, Rarity.COMMON, EnvironmentId.HOME,
            Personality.GENTLE, Diet.HERBIVORE, 0xFFFFD1DC, "Soft ears, twitchy nose and happy hops."),
        Species("hamster", "Hamster", "🐹", M, SpeciesGroup.SMALL, Rarity.COMMON, EnvironmentId.HOME,
            Personality.ENERGETIC, Diet.SEEDS, 0xFFFFD08A, "A tiny athlete who runs marathons on its wheel."),
        Species("guinea_pig", "Guinea Pig", "🐹", M, SpeciesGroup.SMALL, Rarity.UNCOMMON, EnvironmentId.HOME,
            Personality.SOCIAL, Diet.HERBIVORE, 0xFFE6B98C, "Squeaks with joy whenever veggies appear."),
        Species("hedgehog", "Hedgehog", "🦔", M, SpeciesGroup.SMALL, Rarity.UNCOMMON, EnvironmentId.HOME,
            Personality.CURIOUS, Diet.INSECTS, 0xFFC8A27A, "A prickly little explorer with a sweet face."),

        // ---------------- Horses ----------------
        Species("pony", "Pony", "🐴", M, SpeciesGroup.EQUINE, Rarity.UNCOMMON, EnvironmentId.STABLE,
            Personality.GENTLE, Diet.HERBIVORE, 0xFFD9B38C, "Small, sturdy and full of friendly nuzzles."),
        Species("horse", "Horse", "🐎", M, SpeciesGroup.EQUINE, Rarity.RARE, EnvironmentId.STABLE,
            Personality.ENERGETIC, Diet.HERBIVORE, 0xFFB98455, "Graceful and powerful, born to run free."),

        // ---------------- Forest wildlife (sanctuary) ----------------
        Species("fox", "Red Fox", "🦊", M, SpeciesGroup.WILD_CANINE, Rarity.EPIC, EnvironmentId.FOREST,
            Personality.CURIOUS, Diet.OMNIVORE, 0xFFFF8A3D, "A clever forest resident with a fluffy tail.", wild = true),
        Species("wolf", "Grey Wolf", "🐺", M, SpeciesGroup.WILD_CANINE, Rarity.EPIC, EnvironmentId.FOREST,
            Personality.LOYAL, Diet.CARNIVORE, 0xFFA9B4C2, "A devoted pack animal who sings to the moon.", wild = true),
        Species("deer", "Deer", "🦌", M, SpeciesGroup.LARGE_MAMMAL, Rarity.EPIC, EnvironmentId.FOREST,
            Personality.GENTLE, Diet.HERBIVORE, 0xFFC99A6B, "Quiet, graceful and quick on its feet.", wild = true),
        Species("brown_bear", "Brown Bear", "🐻", M, SpeciesGroup.LARGE_MAMMAL, Rarity.EPIC, EnvironmentId.FOREST,
            Personality.CALM, Diet.OMNIVORE, 0xFFA0703F, "A strong forager who loves berries and long naps.",
            wild = true, styleOverride = AnimStyle.MAJESTIC),
        Species("koala", "Koala", "🐨", M, SpeciesGroup.LARGE_MAMMAL, Rarity.RARE, EnvironmentId.FOREST,
            Personality.CALM, Diet.HERBIVORE, 0xFFB7C0C8, "A sleepy tree-hugger who naps most of the day.",
            wild = true, styleOverride = AnimStyle.MAJESTIC),
        Species("panda", "Giant Panda", "🐼", M, SpeciesGroup.LARGE_MAMMAL, Rarity.LEGENDARY, EnvironmentId.FOREST,
            Personality.CALM, Diet.BAMBOO, 0xFFE8EEF2, "A peaceful bamboo lover with a playful side.",
            wild = true, styleOverride = AnimStyle.MAJESTIC),
        Species("monkey", "Monkey", "🐒", M, SpeciesGroup.PRIMATE, Rarity.RARE, EnvironmentId.FOREST,
            Personality.PLAYFUL, Diet.OMNIVORE, 0xFFC08A5B, "A nimble climber who loves puzzles and treats.", wild = true),

        // ---------------- Savanna & sanctuary giants ----------------
        Species("zebra", "Zebra", "🦓", M, SpeciesGroup.LARGE_MAMMAL, Rarity.EPIC, EnvironmentId.ANIMAL_SANCTUARY,
            Personality.SOCIAL, Diet.HERBIVORE, 0xFFE2E2E2, "Every stripe pattern is one of a kind.", wild = true),
        Species("giraffe", "Giraffe", "🦒", M, SpeciesGroup.LARGE_MAMMAL, Rarity.EPIC, EnvironmentId.ANIMAL_SANCTUARY,
            Personality.GENTLE, Diet.HERBIVORE, 0xFFF2C46D, "Reaches the tastiest leaves at the treetops.", wild = true),
        Species("leopard", "Leopard", "🐆", M, SpeciesGroup.BIG_CAT, Rarity.EPIC, EnvironmentId.ANIMAL_SANCTUARY,
            Personality.CURIOUS, Diet.CARNIVORE, 0xFFF2B35B, "A silent climber with beautiful rosettes.", wild = true),
        Species("elephant", "Elephant", "🐘", M, SpeciesGroup.LARGE_MAMMAL, Rarity.LEGENDARY, EnvironmentId.ANIMAL_SANCTUARY,
            Personality.WISE, Diet.HERBIVORE, 0xFFB5BCC6, "Wise and caring, with a memory that never fades.",
            wild = true, styleOverride = AnimStyle.MAJESTIC),
        Species("lion", "Lion", "🦁", M, SpeciesGroup.BIG_CAT, Rarity.LEGENDARY, EnvironmentId.ANIMAL_SANCTUARY,
            Personality.PROUD, Diet.CARNIVORE, 0xFFFFB347, "The proud guardian of the sanctuary plains.", wild = true),
        Species("tiger", "Tiger", "🐅", M, SpeciesGroup.BIG_CAT, Rarity.LEGENDARY, EnvironmentId.ANIMAL_SANCTUARY,
            Personality.BRAVE, Diet.CARNIVORE, 0xFFFF8F3A, "Powerful, striped and a surprisingly good swimmer.", wild = true),
        Species("cheetah", "Cheetah", "🐆", M, SpeciesGroup.BIG_CAT, Rarity.LEGENDARY, EnvironmentId.ANIMAL_SANCTUARY,
            Personality.ENERGETIC, Diet.CARNIVORE, 0xFFFFC65C, "The fastest sprinter on land.", wild = true),
        Species("polar_bear", "Polar Bear", "🐻‍❄️", M, SpeciesGroup.LARGE_MAMMAL, Rarity.LEGENDARY, EnvironmentId.ANIMAL_SANCTUARY,
            Personality.BRAVE, Diet.CARNIVORE, 0xFFE3F2FF, "A snowy giant who loves a cool splash.",
            wild = true, styleOverride = AnimStyle.MAJESTIC),
        Species("gorilla", "Gorilla", "🦍", M, SpeciesGroup.PRIMATE, Rarity.LEGENDARY, EnvironmentId.ANIMAL_SANCTUARY,
            Personality.WISE, Diet.HERBIVORE, 0xFF8A8F99, "A calm, thoughtful leader of its family group.",
            wild = true, styleOverride = AnimStyle.MAJESTIC),

        // ---------------- Birds ----------------
        Species("budgie", "Budgie", "🐦", B, SpeciesGroup.BIRD, Rarity.COMMON, EnvironmentId.BIRD_SANCTUARY,
            Personality.SOCIAL, Diet.SEEDS, 0xFF8FE3A1, "A chirpy little singer who loves company."),
        Species("parrot", "Parrot", "🦜", B, SpeciesGroup.BIRD, Rarity.UNCOMMON, EnvironmentId.BIRD_SANCTUARY,
            Personality.SOCIAL, Diet.SEEDS, 0xFF5FD38A, "Colourful, clever and a brilliant mimic."),
        Species("owl", "Owl", "🦉", B, SpeciesGroup.BIRD, Rarity.RARE, EnvironmentId.BIRD_SANCTUARY,
            Personality.WISE, Diet.CARNIVORE, 0xFFB08D6E, "A quiet night watcher with wise eyes.", wild = true),
        Species("peacock", "Peacock", "🦚", B, SpeciesGroup.BIRD, Rarity.RARE, EnvironmentId.BIRD_SANCTUARY,
            Personality.PROUD, Diet.SEEDS, 0xFF3FC1B0, "Shows off a magnificent fan of feathers.",
            wild = true, styleOverride = AnimStyle.MAJESTIC),
        Species("penguin", "Penguin", "🐧", B, SpeciesGroup.BIRD, Rarity.RARE, EnvironmentId.BIRD_SANCTUARY,
            Personality.SOCIAL, Diet.FISH_FOOD, 0xFFAFC8E8, "Waddles on land, flies underwater.",
            wild = true, styleOverride = AnimStyle.BOUNCE),
        Species("flamingo", "Flamingo", "🦩", B, SpeciesGroup.BIRD, Rarity.RARE, EnvironmentId.BIRD_SANCTUARY,
            Personality.CALM, Diet.FISH_FOOD, 0xFFFF9EC4, "Balances on one leg like a pink ballerina.",
            wild = true, styleOverride = AnimStyle.MAJESTIC),
        Species("eagle", "Bald Eagle", "🦅", B, SpeciesGroup.BIRD, Rarity.EPIC, EnvironmentId.BIRD_SANCTUARY,
            Personality.BRAVE, Diet.CARNIVORE, 0xFFC9A27A, "Soars high with incredible eyesight.", wild = true),
        Species("falcon", "Falcon", "🦅", B, SpeciesGroup.BIRD, Rarity.EPIC, EnvironmentId.BIRD_SANCTUARY,
            Personality.ENERGETIC, Diet.CARNIVORE, 0xFFA3B1C6, "The swiftest diver in the sky.", wild = true),

        // ---------------- Aquatic ----------------
        Species("goldfish", "Goldfish", "🐟", A, SpeciesGroup.FISH, Rarity.COMMON, EnvironmentId.AQUARIUM,
            Personality.CALM, Diet.FISH_FOOD, 0xFFFFA94D, "A shimmering friend who loves gentle currents."),
        Species("clownfish", "Clownfish", "🐠", A, SpeciesGroup.FISH, Rarity.UNCOMMON, EnvironmentId.AQUARIUM,
            Personality.PLAYFUL, Diet.FISH_FOOD, 0xFFFF7A3D, "Bright stripes and a cozy anemone home."),
        Species("seahorse", "Seahorse", "🐠", A, SpeciesGroup.FISH, Rarity.UNCOMMON, EnvironmentId.AQUARIUM,
            Personality.GENTLE, Diet.FISH_FOOD, 0xFFFFB3D9, "Drifts upright and holds on with its curly tail."),
        Species("pufferfish", "Pufferfish", "🐡", A, SpeciesGroup.FISH, Rarity.UNCOMMON, EnvironmentId.AQUARIUM,
            Personality.CURIOUS, Diet.FISH_FOOD, 0xFFF5E07A, "Puffs up into a round ball when surprised."),
        Species("sea_turtle", "Sea Turtle", "🐢", A, SpeciesGroup.REPTILE, Rarity.RARE, EnvironmentId.AQUARIUM,
            Personality.WISE, Diet.HERBIVORE, 0xFF7BCB8A, "An ancient ocean traveller.",
            wild = true, styleOverride = AnimStyle.SWIM),
        Species("octopus", "Octopus", "🐙", A, SpeciesGroup.FISH, Rarity.RARE, EnvironmentId.AQUARIUM,
            Personality.CURIOUS, Diet.FISH_FOOD, 0xFFFF7FA8, "Eight arms and a brilliant puzzle-solving mind.", wild = true),
        Species("reef_shark", "Reef Shark", "🦈", A, SpeciesGroup.FISH, Rarity.EPIC, EnvironmentId.AQUARIUM,
            Personality.BRAVE, Diet.FISH_FOOD, 0xFF8FB3D9, "A sleek reef patroller that keeps the ocean healthy.", wild = true),
        Species("seal", "Seal", "🦭", A, SpeciesGroup.MARINE, Rarity.EPIC, EnvironmentId.AQUARIUM,
            Personality.SOCIAL, Diet.FISH_FOOD, 0xFFA8B5C2, "A playful swimmer who loves sunbathing.", wild = true),
        Species("dolphin", "Dolphin", "🐬", A, SpeciesGroup.MARINE, Rarity.LEGENDARY, EnvironmentId.AQUARIUM,
            Personality.PLAYFUL, Diet.FISH_FOOD, 0xFF6EC6FF, "Joyful, social and wonderfully smart.", wild = true),
        Species("blue_whale", "Blue Whale", "🐋", A, SpeciesGroup.MARINE, Rarity.LEGENDARY, EnvironmentId.AQUARIUM,
            Personality.WISE, Diet.FISH_FOOD, 0xFF5B8DEF, "The largest animal on Earth, with a gentle song.", wild = true),

        // ---------------- Reptiles ----------------
        Species("gecko", "Leopard Gecko", "🦎", R, SpeciesGroup.REPTILE, Rarity.COMMON, EnvironmentId.HOME,
            Personality.CALM, Diet.INSECTS, 0xFFF2D06B, "A spotted little smiler who loves warm rocks."),
        Species("tortoise", "Tortoise", "🐢", R, SpeciesGroup.REPTILE, Rarity.UNCOMMON, EnvironmentId.HOME,
            Personality.WISE, Diet.HERBIVORE, 0xFF9CCB6B, "Slow, steady and full of patience."),
        Species("iguana", "Iguana", "🦎", R, SpeciesGroup.REPTILE, Rarity.UNCOMMON, EnvironmentId.HOME,
            Personality.CALM, Diet.HERBIVORE, 0xFF6FCF8A, "A sun-loving climber with a spiky crest."),
        Species("chameleon", "Chameleon", "🦎", R, SpeciesGroup.REPTILE, Rarity.RARE, EnvironmentId.HOME,
            Personality.CURIOUS, Diet.INSECTS, 0xFF4FD1A5, "Changes colours and watches everything at once."),
        Species("corn_snake", "Corn Snake", "🐍", R, SpeciesGroup.REPTILE, Rarity.RARE, EnvironmentId.HOME,
            Personality.CALM, Diet.CARNIVORE, 0xFFFF9466, "A calm, curious climber with bright patterns."),
        Species("crocodile", "Crocodile", "🐊", R, SpeciesGroup.REPTILE, Rarity.LEGENDARY, EnvironmentId.ANIMAL_SANCTUARY,
            Personality.BRAVE, Diet.CARNIVORE, 0xFF6E9E5A, "An ancient river guardian resting in the sanctuary.", wild = true),

        // ---------------- Mythical ----------------
        Species("phoenix", "Phoenix", "🦅", X, SpeciesGroup.MYTHIC, Rarity.MYTHICAL, EnvironmentId.MYTHIC_GROVE,
            Personality.PROUD, Diet.STARLIGHT, 0xFFFF7A2F, "A fantasy firebird reborn in golden flame.", aura = "🔥"),
        Species("dragon", "Dragon", "🐉", X, SpeciesGroup.MYTHIC, Rarity.MYTHICAL, EnvironmentId.MYTHIC_GROVE,
            Personality.BRAVE, Diet.STARLIGHT, 0xFF46D17A, "A wise fantasy dragon guarding the grove.", aura = "✨"),
        Species("celestial_wolf", "Celestial Wolf", "🐺", X, SpeciesGroup.MYTHIC, Rarity.MYTHICAL, EnvironmentId.MYTHIC_GROVE,
            Personality.WISE, Diet.STARLIGHT, 0xFF8FA8FF, "A fantasy wolf woven from starlight.", aura = "⭐"),
        Species("unicorn", "Unicorn", "🦄", X, SpeciesGroup.MYTHIC, Rarity.MYTHICAL, EnvironmentId.MYTHIC_GROVE,
            Personality.GENTLE, Diet.STARLIGHT, 0xFFFF9EE5, "A fantasy unicorn that leaves rainbows behind.", aura = "🌈"),
        Species("moon_fox", "Moon Fox", "🦊", X, SpeciesGroup.MYTHIC, Rarity.MYTHICAL, EnvironmentId.MYTHIC_GROVE,
            Personality.CURIOUS, Diet.STARLIGHT, 0xFFC6B3FF, "A fantasy fox whose tails glow like moonlight.", aura = "🌙"),
    )

    private val byIdMap: Map<String, Species> = all.associateBy { it.id }

    fun byId(id: String): Species = byIdMap[id] ?: all.first()
    fun find(id: String): Species? = byIdMap[id]

    val starters: List<Pair<Species, String>> = listOf(
        byId("mixed_puppy") to "Biscuit",
        byId("kitten") to "Mochi",
        byId("rabbit") to "Clover",
    )
}
