package com.petverse.app.ui.screens

import android.Manifest
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.petverse.app.data.catalog.HabitPresets
import com.petverse.app.data.catalog.SpeciesCatalog
import com.petverse.app.data.model.HabitCategory
import com.petverse.app.ui.GameViewModel
import com.petverse.app.ui.components.AnimatedPet
import com.petverse.app.ui.components.EnvironmentBackdrop
import com.petverse.app.ui.components.GradientButton
import com.petverse.app.ui.components.Pill
import com.petverse.app.ui.components.RarityBadge
import com.petverse.app.ui.theme.Honey
import kotlinx.coroutines.delay
import kotlin.math.cos
import kotlin.math.sin

// ------------------------------------------------------------------
// 1. Splash
// ------------------------------------------------------------------

@Composable
fun SplashScreen(vm: GameViewModel, onDone: (onboarded: Boolean) -> Unit) {
    val ready by vm.ready.collectAsStateWithLifecycle()
    LaunchedEffect(ready) {
        if (ready) {
            delay(1700)
            onDone(vm.player.value?.onboarded == true)
        }
    }
    val inf = rememberInfiniteTransition(label = "splash")
    val orbit by inf.animateFloat(0f, 360f, infiniteRepeatable(tween(9000, easing = LinearEasing)), label = "orbit")
    val pulse by inf.animateFloat(0.92f, 1.08f, infiniteRepeatable(tween(900), RepeatMode.Reverse), label = "pulse")
    val dots by inf.animateFloat(0f, 3f, infiniteRepeatable(tween(1200, easing = LinearEasing)), label = "dots")
    val orbiters = listOf("🐶", "🐱", "🦊", "🐼", "🦄", "🐬", "🦜", "🐢")

    Box(
        Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(Color(0xFF2A1B6E), Color(0xFF120E33), Color(0xFF0B0A1F)))),
        contentAlignment = Alignment.Center,
    ) {
        Box(Modifier.size(260.dp), contentAlignment = Alignment.Center) {
            orbiters.forEachIndexed { i, e ->
                val a = Math.toRadians((orbit + i * 45f).toDouble())
                Text(
                    e, fontSize = 30.sp,
                    modifier = Modifier.graphicsLayer {
                        translationX = (cos(a) * 110.dp.toPx()).toFloat()
                        translationY = (sin(a) * 110.dp.toPx()).toFloat()
                    },
                )
            }
            Box(
                Modifier
                    .size(120.dp)
                    .graphicsLayer { scaleX = pulse; scaleY = pulse }
                    .clip(CircleShape)
                    .background(Brush.radialGradient(listOf(Color(0xFF9B82FF), Color(0xFF5B3FE0)))),
                contentAlignment = Alignment.Center,
            ) {
                Text("🐾", fontSize = 58.sp)
            }
        }
        Column(
            Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 72.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Text(
                "PETVERSE",
                color = Color.White,
                fontSize = 40.sp,
                fontWeight = FontWeight.Black,
                letterSpacing = 6.sp,
            )
            Spacer(Modifier.height(6.dp))
            Text("Your Habits. Your Pets. Your World.", color = Color(0xFFCFC6FF), style = MaterialTheme.typography.bodyLarge)
            Spacer(Modifier.height(24.dp))
            Text("Loading" + ".".repeat(dots.toInt() + 1), color = Honey, style = MaterialTheme.typography.labelLarge)
        }
    }
}

// ------------------------------------------------------------------
// 2. Onboarding
// ------------------------------------------------------------------

private data class IntroPage(val emojis: String, val title: String, val text: String)

private val introPages = listOf(
    IntroPage("🐶 🐱 🐰", "Adopt & raise amazing animals", "Care for puppies, kittens, horses, dolphins, sanctuary lions — and even mythical dragons."),
    IntroPage("✅ ➜ 🐾", "Your habits power their growth", "Every real-life habit you complete earns food, coins, XP and loyalty that help your pets grow."),
    IntroPage("🌳 🏞️ 🌊", "Explore a living world", "Unlock parks, stables, forests, aquariums and a protected Animal Sanctuary as you level up."),
)

private val avatars = listOf("🧑", "👩", "👨", "🧒", "🧑‍🎓", "🧑‍💻", "🧑‍🚀", "🧙", "🦸", "🥷", "🧑‍🌾", "🧑‍🎨")

@Composable
fun OnboardingScreen(vm: GameViewModel, onFinished: () -> Unit) {
    var step by remember { mutableIntStateOf(0) }
    var name by remember { mutableStateOf("") }
    var avatar by remember { mutableStateOf(avatars.first()) }
    var starterIndex by remember { mutableIntStateOf(0) }
    var petName by remember { mutableStateOf(SpeciesCatalog.starters.first().second) }
    var selectedHabits by remember { mutableStateOf(HabitPresets.defaultSelection) }
    var finishing by remember { mutableStateOf(false) }

    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }

    fun finish() {
        if (finishing) return
        finishing = true
        val starter = SpeciesCatalog.starters[starterIndex].first
        vm.completeOnboarding(name, avatar, starter.id, petName, selectedHabits) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                permissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
            onFinished()
        }
    }

    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).imePadding()) {
        // Progress dots
        Row(
            Modifier.fillMaxWidth().padding(top = 16.dp),
            horizontalArrangement = Arrangement.Center,
        ) {
            repeat(6) { i ->
                Box(
                    Modifier
                        .padding(horizontal = 3.dp)
                        .size(width = if (i == step) 22.dp else 8.dp, height = 8.dp)
                        .clip(CircleShape)
                        .background(if (i <= step) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant)
                )
            }
        }
        AnimatedContent(
            targetState = step,
            transitionSpec = {
                (slideInHorizontally { it / 3 } + fadeIn()) togetherWith (slideOutHorizontally { -it / 3 } + fadeOut())
            },
            modifier = Modifier.weight(1f),
            label = "onboarding",
        ) { s ->
            when (s) {
                0, 1, 2 -> IntroStep(introPages[s])
                3 -> ProfileStep(name, { name = it }, avatar, { avatar = it })
                4 -> StarterStep(starterIndex, {
                    starterIndex = it
                    petName = SpeciesCatalog.starters[it].second
                }, petName, { petName = it })
                else -> HabitStep(selectedHabits) { id ->
                    selectedHabits = if (id in selectedHabits) selectedHabits - id else selectedHabits + id
                }
            }
        }
        Row(
            Modifier.fillMaxWidth().padding(20.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            if (step > 0) {
                Text(
                    "Back",
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier
                        .clip(RoundedCornerShape(50))
                        .clickable { step-- }
                        .padding(14.dp),
                )
            } else {
                Text(
                    "Skip intro",
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier
                        .clip(RoundedCornerShape(50))
                        .clickable { step = 3 }
                        .padding(14.dp),
                )
            }
            Spacer(Modifier.weight(1f))
            val canContinue = when (step) {
                3 -> name.isNotBlank()
                4 -> petName.isNotBlank()
                5 -> selectedHabits.isNotEmpty() && !finishing
                else -> true
            }
            GradientButton(
                text = when (step) {
                    5 -> "Start my journey"
                    else -> "Continue"
                },
                emoji = if (step == 5) "🚀" else null,
                enabled = canContinue,
                onClick = { if (step < 5) step++ else finish() },
            )
        }
    }
}

@Composable
private fun IntroStep(page: IntroPage) {
    Column(
        Modifier.fillMaxSize().padding(28.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Box(
            Modifier
                .size(220.dp)
                .clip(CircleShape)
                .background(Brush.radialGradient(listOf(Color(0xFF9B82FF).copy(alpha = 0.45f), Color.Transparent))),
            contentAlignment = Alignment.Center,
        ) {
            Text(page.emojis, fontSize = 48.sp, textAlign = TextAlign.Center)
        }
        Spacer(Modifier.height(28.dp))
        Text(page.title, style = MaterialTheme.typography.headlineLarge, textAlign = TextAlign.Center)
        Spacer(Modifier.height(12.dp))
        Text(
            page.text, style = MaterialTheme.typography.bodyLarge,
            color = MaterialTheme.colorScheme.onSurfaceVariant, textAlign = TextAlign.Center,
        )
    }
}

@Composable
private fun ProfileStep(name: String, onName: (String) -> Unit, avatar: String, onAvatar: (String) -> Unit) {
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Spacer(Modifier.height(24.dp))
        Box(
            Modifier
                .size(110.dp)
                .clip(CircleShape)
                .background(Brush.linearGradient(listOf(Color(0xFF8B6CFF), Color(0xFFFF8BC2)))),
            contentAlignment = Alignment.Center,
        ) { Text(avatar, fontSize = 56.sp) }
        Spacer(Modifier.height(20.dp))
        Text("Create your trainer", style = MaterialTheme.typography.headlineMedium)
        Spacer(Modifier.height(6.dp))
        Text("No account needed — everything stays on your phone.", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(20.dp))
        OutlinedTextField(
            value = name,
            onValueChange = { if (it.length <= 20) onName(it) },
            label = { Text("Your name") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
        )
        Spacer(Modifier.height(20.dp))
        Text("Pick an avatar", style = MaterialTheme.typography.titleMedium, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(10.dp))
        avatars.chunked(6).forEach { row ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                row.forEach { a ->
                    val sel = a == avatar
                    Box(
                        Modifier
                            .size(48.dp)
                            .clip(CircleShape)
                            .background(if (sel) MaterialTheme.colorScheme.primary.copy(alpha = 0.25f) else MaterialTheme.colorScheme.surfaceVariant)
                            .border(2.dp, if (sel) MaterialTheme.colorScheme.primary else Color.Transparent, CircleShape)
                            .clickable { onAvatar(a) },
                        contentAlignment = Alignment.Center,
                    ) { Text(a, fontSize = 24.sp) }
                }
            }
            Spacer(Modifier.height(10.dp))
        }
    }
}

@Composable
private fun StarterStep(selected: Int, onSelect: (Int) -> Unit, petName: String, onPetName: (String) -> Unit) {
    val (species, _) = SpeciesCatalog.starters[selected]
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 24.dp)) {
        Spacer(Modifier.height(16.dp))
        Text("Choose your first companion", style = MaterialTheme.typography.headlineMedium)
        Text("They'll grow alongside your habits.", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(16.dp))
        EnvironmentBackdrop(species.habitat, Modifier.fillMaxWidth().height(220.dp)) {
            AnimatedPet(species, stage = 2, size = 170.dp, modifier = Modifier.align(Alignment.Center))
            Row(Modifier.align(Alignment.TopStart).padding(12.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                RarityBadge(species.rarity)
                Pill(species.personality.label, color = Color(0xFF5B3FE0), emoji = species.personality.emoji, filled = true)
            }
        }
        Spacer(Modifier.height(14.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            SpeciesCatalog.starters.forEachIndexed { i, (sp, _) ->
                val sel = i == selected
                Column(
                    Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(20.dp))
                        .background(if (sel) MaterialTheme.colorScheme.primary.copy(alpha = 0.18f) else MaterialTheme.colorScheme.surfaceVariant)
                        .border(2.dp, if (sel) MaterialTheme.colorScheme.primary else Color.Transparent, RoundedCornerShape(20.dp))
                        .clickable { onSelect(i) }
                        .padding(vertical = 12.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    Text(sp.emoji, fontSize = 36.sp)
                    Text(sp.name.substringAfterLast(' '), style = MaterialTheme.typography.labelLarge)
                }
            }
        }
        Spacer(Modifier.height(12.dp))
        Text(species.description, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(
            value = petName,
            onValueChange = { if (it.length <= 16) onPetName(it) },
            label = { Text("Name your ${species.name.substringAfterLast(' ').lowercase()}") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
        )
    }
}

@Composable
private fun HabitStep(selected: Set<String>, onToggle: (String) -> Unit) {
    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 24.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        item {
            Text("Pick your starting habits", style = MaterialTheme.typography.headlineMedium)
            Text(
                "Choose at least one. You can add, edit or create custom habits anytime.",
                style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Spacer(Modifier.height(8.dp))
        }
        HabitCategory.entries.filter { it != HabitCategory.CUSTOM }.forEach { cat ->
            item(key = "h_${cat.name}") {
                Text("${cat.emoji}  ${cat.label}", style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(top = 8.dp))
            }
            items(HabitPresets.all.filter { it.category == cat }, key = { it.id }) { preset ->
                val sel = preset.id in selected
                Row(
                    Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .background(if (sel) MaterialTheme.colorScheme.primary.copy(alpha = 0.15f) else MaterialTheme.colorScheme.surfaceVariant)
                        .border(1.5.dp, if (sel) MaterialTheme.colorScheme.primary else Color.Transparent, RoundedCornerShape(16.dp))
                        .clickable { onToggle(preset.id) }
                        .padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text(preset.emoji, fontSize = 22.sp)
                    Spacer(Modifier.width(12.dp))
                    Text(preset.name, style = MaterialTheme.typography.titleSmall, modifier = Modifier.weight(1f))
                    Pill(preset.difficulty.label, color = MaterialTheme.colorScheme.secondary)
                    Spacer(Modifier.width(8.dp))
                    Text(if (sel) "✅" else "⬜", fontSize = 18.sp)
                }
            }
        }
    }
}
