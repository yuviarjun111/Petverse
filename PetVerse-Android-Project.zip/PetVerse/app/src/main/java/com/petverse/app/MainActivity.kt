package com.petverse.app

import android.graphics.Color
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.petverse.app.ui.GameViewModel
import com.petverse.app.ui.navigation.PetVerseRoot
import com.petverse.app.ui.theme.PetVerseTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val vm: GameViewModel = viewModel(factory = GameViewModel.Factory)
            val player by vm.player.collectAsStateWithLifecycle()
            val systemDark = isSystemInDarkTheme()
            val dark = when (player?.themeMode ?: 0) {
                1 -> false
                2 -> true
                else -> systemDark
            }
            DisposableEffect(dark) {
                val style = if (dark) {
                    SystemBarStyle.dark(Color.TRANSPARENT)
                } else {
                    SystemBarStyle.light(Color.TRANSPARENT, Color.TRANSPARENT)
                }
                enableEdgeToEdge(statusBarStyle = style, navigationBarStyle = style)
                onDispose { }
            }
            PetVerseTheme(dark = dark) {
                PetVerseRoot(vm)
            }
        }
    }
}
