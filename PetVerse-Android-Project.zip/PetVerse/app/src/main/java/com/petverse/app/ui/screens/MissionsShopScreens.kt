package com.petverse.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavHostController
import com.petverse.app.data.catalog.ItemCatalog
import com.petverse.app.data.catalog.ItemDef
import com.petverse.app.data.catalog.ItemType
import com.petverse.app.data.catalog.LoginRewards
import com.petverse.app.data.catalog.MissionDef
import com.petverse.app.data.catalog.MissionPeriod
import com.petverse.app.domain.MissionEngine
import com.petverse.app.ui.GameViewModel
import com.petverse.app.ui.components.CurrencyChip
import com.petverse.app.ui.components.PVCard
import com.petverse.app.ui.components.Pill
import com.petverse.app.ui.components.ProgressTrack
import com.petverse.app.ui.components.ScreenHeader
import com.petverse.app.ui.components.SectionTitle
import com.petverse.app.ui.components.SegmentedTabs
import com.petverse.app.util.Time

// ------------------------------------------------------------------
// 10. Daily missions / weekly challenges / monthly achievements
// ------------------------------------------------------------------

@Composable
fun MissionRow(def: MissionDef, progress: Int, claimed: Boolean, onClaim: () -> Unit) {
    val complete = progress >= def.target
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant)
            .padding(12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            Modifier.size(42.dp).clip(CircleShape).background(MaterialTheme.colorScheme.surface),
            contentAlignment = Alignment.Center,
        ) { Text(def.emoji, fontSize = 20.sp) }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(def.title, style = MaterialTheme.typography.titleSmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Spacer(Modifier.height(4.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                ProgressTrack(
                    (progress.coerceAtMost(def.target)) / def.target.toFloat(),
                    MaterialTheme.colorScheme.secondary,
                    Modifier.weight(1f).height(7.dp),
                )
                Spacer(Modifier.width(8.dp))
                Text("${progress.coerceAtMost(def.target)}/${def.target}", style = MaterialTheme.typography.labelSmall)
            }
            Spacer(Modifier.height(3.dp))
            val reward = buildString {
                append("+${def.coins} 🪙  +${def.xp} XP")
                def.itemId?.let { append("  +${def.itemQty} ${ItemCatalog.byId(it).emoji}") }
                if (def.trainingPoints > 0) append("  +${def.trainingPoints} 🎯")
            }
            Text(reward, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Spacer(Modifier.width(10.dp))
        when {
            claimed -> Text("✅", fontSize = 22.sp)
            complete -> Text(
                "Claim",
                style = MaterialTheme.typography.labelLarge,
                color = Color.White,
                modifier = Modifier
                    .clip(RoundedCornerShape(50))
                    .background(Brush.horizontalGradient(listOf(Color(0xFFFFB547), Color(0xFFFF7A3D))))
                    .clickable(onClick = onClaim)
                    .padding(horizontal = 14.dp, vertical = 8.dp),
            )
            else -> Text("🔒", fontSize = 18.sp)
        }
    }
}

@Composable
fun MissionsScreen(vm: GameViewModel, nav: NavHostController) {
    val player by vm.player.collectAsStateWithLifecycle()
    val pets by vm.pets.collectAsStateWithLifecycle()
    val logs by vm.logs.collectAsStateWithLifecycle()
    val activities by vm.activities.collectAsStateWithLifecycle()
    val claims by vm.claims.collectAsStateWithLifecycle()
    var tab by remember { mutableIntStateOf(0) }
    val today = Time.today()
    val logDays = logs.map { it.epochDay }.toSet()
    val period = MissionPeriod.entries[tab]
    val missions = MissionEngine.missionsFor(period, today, MissionEngine.hasWalker(pets))
    val p = player ?: return

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 24.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        item { ScreenHeader("Missions", onBack = { nav.popBackStack() }, subtitle = "Complete challenges for bonus rewards") }
        item { SegmentedTabs(listOf("Daily", "Weekly", "Monthly"), tab, { tab = it }) }
        item {
            val left = when (period) {
                MissionPeriod.DAILY -> "Resets at midnight"
                MissionPeriod.WEEKLY -> "${Time.daysLeftInWeek(today)} days left this week"
                MissionPeriod.MONTHLY -> "${Time.daysLeftInMonth(today)} days left this month"
            }
            Text("⏳ $left", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        items(missions, key = { it.id }) { m ->
            val prog = MissionEngine.progress(m, activities, logDays, today)
            MissionRow(m, prog, MissionEngine.claimKey(m, today) in claims) { vm.claimMission(m) }
        }
        if (period == MissionPeriod.DAILY) {
            item {
                Spacer(Modifier.height(6.dp))
                PVCard {
                    SectionTitle("Daily login calendar")
                    Text(
                        "Login streak: ${p.loginStreak} day${if (p.loginStreak == 1) "" else "s"} 🔥",
                        style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    Spacer(Modifier.height(10.dp))
                    val currentIndex = ((p.loginStreak - 1).coerceAtLeast(0)) % 7
                    val claimedToday = p.lastLoginRewardDay == today
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        LoginRewards.cycle.forEachIndexed { i, r ->
                            val isCurrent = i == currentIndex
                            val done = i < currentIndex || (isCurrent && claimedToday)
                            Column(
                                Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(14.dp))
                                    .background(
                                        when {
                                            done -> MaterialTheme.colorScheme.tertiary.copy(alpha = 0.2f)
                                            isCurrent -> MaterialTheme.colorScheme.secondary.copy(alpha = 0.25f)
                                            else -> MaterialTheme.colorScheme.surfaceVariant
                                        }
                                    )
                                    .border(
                                        2.dp,
                                        if (isCurrent && !claimedToday) MaterialTheme.colorScheme.secondary else Color.Transparent,
                                        RoundedCornerShape(14.dp),
                                    )
                                    .clickable(enabled = isCurrent && !claimedToday) { vm.claimLoginReward() }
                                    .padding(vertical = 8.dp),
                                horizontalAlignment = Alignment.CenterHorizontally,
                            ) {
                                Text("D${r.day}", style = MaterialTheme.typography.labelSmall)
                                Text(if (done) "✅" else r.emoji, fontSize = 18.sp)
                            }
                        }
                    }
                    if (!claimedToday) {
                        Spacer(Modifier.height(8.dp))
                        Text("Tap today's tile to claim!", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.secondary)
                    }
                }
            }
        }
    }
}

// ------------------------------------------------------------------
// 11. Pet Shop
// ------------------------------------------------------------------

@Composable
fun ShopScreen(vm: GameViewModel, nav: NavHostController) {
    val player by vm.player.collectAsStateWithLifecycle()
    val inventory by vm.inventory.collectAsStateWithLifecycle()
    var tab by remember { mutableIntStateOf(0) }
    val types = listOf(ItemType.FOOD, ItemType.CARE, ItemType.TOY, ItemType.ACCESSORY, ItemType.SPECIAL)
    val p = player ?: return
    val type = types[tab]
    val shopItems = ItemCatalog.ofType(type)

    LazyVerticalGrid(
        columns = GridCells.Fixed(2),
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 24.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item(span = { GridItemSpan(maxLineSpan) }) {
            ScreenHeader("Pet Shop", onBack = { nav.popBackStack() }, subtitle = "Spend coins earned from your habits") {
                CurrencyChip("🪙", p.coins)
            }
        }
        item(span = { GridItemSpan(maxLineSpan) }) {
            SegmentedTabs(types.map { it.emoji }, tab, { tab = it })
        }
        item(span = { GridItemSpan(maxLineSpan) }) {
            Text(
                when (type) {
                    ItemType.FOOD -> "Food — every habit also gives you free Pet Food 🥣"
                    ItemType.CARE -> "Care — instant boosts for energy, health and cleanliness"
                    ItemType.TOY -> "Toys — owned forever. Each pet has favourites!"
                    ItemType.ACCESSORY -> "Style — accessories unlock at Friend bond and by growth stage"
                    ItemType.SPECIAL -> "Special — can't be bought. Earn them through habits & challenges"
                },
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        items(shopItems, key = { it.id }) { item ->
            ShopItemCard(item, owned = inventory[item.id] ?: 0, coins = p.coins) { vm.buy(item.id) }
        }
    }
}

@Composable
private fun ShopItemCard(item: ItemDef, owned: Int, coins: Int, onBuy: () -> Unit) {
    val price = item.price
    val ownedPermanent = item.permanent && owned > 0
    val canBuy = price != null && !ownedPermanent && coins >= price
    PVCard(padding = PaddingValues(14.dp)) {
        Box(
            Modifier
                .fillMaxWidth()
                .height(84.dp)
                .clip(RoundedCornerShape(18.dp))
                .background(Brush.linearGradient(listOf(Color(0xFF8B6CFF).copy(alpha = 0.22f), Color(0xFFFF8BC2).copy(alpha = 0.18f)))),
            contentAlignment = Alignment.Center,
        ) {
            Text(item.emoji, fontSize = 44.sp)
            if (owned > 0) {
                Pill(if (item.permanent) "Owned" else "x$owned", Modifier.align(Alignment.TopEnd).padding(6.dp), color = MaterialTheme.colorScheme.tertiary, filled = true)
            }
        }
        Spacer(Modifier.height(10.dp))
        Text(item.name, style = MaterialTheme.typography.titleSmall, maxLines = 1)
        Text(
            item.description, style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 2, minLines = 2, overflow = TextOverflow.Ellipsis,
        )
        if (item.type == ItemType.ACCESSORY) {
            Text("Stage ${item.minStage}+", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
        }
        Spacer(Modifier.height(8.dp))
        val label = when {
            price == null -> "Earn only"
            ownedPermanent -> "Owned ✓"
            else -> "🪙 $price"
        }
        Text(
            label,
            style = MaterialTheme.typography.labelLarge,
            color = if (canBuy) Color.White else MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center,
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(14.dp))
                .background(
                    if (canBuy) Brush.horizontalGradient(listOf(Color(0xFF8B6CFF), Color(0xFF5B3FE0)))
                    else Brush.horizontalGradient(listOf(MaterialTheme.colorScheme.surfaceVariant, MaterialTheme.colorScheme.surfaceVariant))
                )
                .clickable(enabled = price != null && !ownedPermanent, onClick = onBuy)
                .padding(vertical = 10.dp),
        )
    }
}
