package com.petverse.app.ui.screens

import android.Manifest
import android.app.TimePickerDialog
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavHostController
import com.petverse.app.data.catalog.AchievementCatalog
import com.petverse.app.data.catalog.ItemCatalog
import com.petverse.app.data.catalog.SpeciesCatalog
import com.petverse.app.data.model.ActivityTypes
import com.petverse.app.data.model.HabitCategory
import com.petverse.app.data.model.PetAction
import com.petverse.app.domain.GameRules
import com.petverse.app.domain.StatsCalculator
import com.petverse.app.notifications.NotificationHelper
import com.petverse.app.ui.GameViewModel
import com.petverse.app.ui.components.AnimatedPet
import com.petverse.app.ui.components.BondBadge
import com.petverse.app.ui.components.EnvironmentBackdrop
import com.petverse.app.ui.components.GradientButton
import com.petverse.app.ui.components.PVCard
import com.petverse.app.ui.components.PetPortrait
import com.petverse.app.ui.components.ProgressTrack
import com.petverse.app.ui.components.ScreenHeader
import com.petverse.app.ui.components.SectionTitle
import com.petverse.app.ui.components.SegmentedTabs
import com.petverse.app.ui.components.silhouette
import com.petverse.app.ui.navigation.Routes
import com.petverse.app.ui.theme.XpColor
import com.petverse.app.util.Time

// ------------------------------------------------------------------
// 3. User Profile
// ------------------------------------------------------------------

private val profileAvatars = listOf("🧑", "👩", "👨", "🧒", "🧑‍🎓", "🧑‍💻", "🧑‍🚀", "🧙", "🦸", "🥷", "🧑‍🌾", "🧑‍🎨")

@Composable
fun ProfileScreen(vm: GameViewModel, nav: NavHostController) {
    val player by vm.player.collectAsStateWithLifecycle()
    val pets by vm.pets.collectAsStateWithLifecycle()
    val stats by vm.stats.collectAsStateWithLifecycle()
    val achievements by vm.achievements.collectAsStateWithLifecycle()
    var editing by remember { mutableStateOf(false) }
    val p = player ?: return
    val partner = pets.firstOrNull { it.id == p.partnerPetId }

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 24.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        item { ScreenHeader("Profile") }
        item {
            PVCard(brush = Brush.linearGradient(listOf(Color(0xFF6A47F5), Color(0xFFB45CFF), Color(0xFFFF7AB8)))) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        Modifier
                            .size(78.dp)
                            .clip(CircleShape)
                            .background(Color.White.copy(alpha = 0.25f))
                            .clickable { editing = true },
                        contentAlignment = Alignment.Center,
                    ) { Text(p.avatar, fontSize = 42.sp) }
                    Spacer(Modifier.width(14.dp))
                    Column(Modifier.weight(1f)) {
                        Text(p.name, style = MaterialTheme.typography.headlineSmall, color = Color.White, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text("Trainer Level ${p.level}", style = MaterialTheme.typography.titleSmall, color = Color.White.copy(alpha = 0.9f))
                        Spacer(Modifier.height(8.dp))
                        ProgressTrack(p.xp / GameRules.playerXpForNext(p.level).toFloat(), Color.White, Modifier.fillMaxWidth().height(8.dp))
                        Text("${p.xp} / ${GameRules.playerXpForNext(p.level)} XP", style = MaterialTheme.typography.labelSmall, color = Color.White.copy(alpha = 0.85f))
                    }
                }
                Spacer(Modifier.height(10.dp))
                Text(
                    "✏️ Edit profile",
                    style = MaterialTheme.typography.labelLarge, color = Color.White,
                    modifier = Modifier
                        .clip(RoundedCornerShape(50))
                        .background(Color.White.copy(alpha = 0.2f))
                        .clickable { editing = true }
                        .padding(horizontal = 12.dp, vertical = 6.dp),
                )
            }
        }
        item {
            val tiles = listOf(
                "🐾" to "${pets.size}\npets",
                "✅" to "${stats.totalHabits}\nhabits",
                "🔥" to "${stats.currentStreak}\nstreak",
                "🏅" to "${achievements.size}\nbadges",
                "🪙" to "${p.coins}\ncoins",
                "📆" to "${p.loginStreak}\nlogin days",
            )
            tiles.chunked(3).forEach { row ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    row.forEach { (e, t) -> StatTile(e, t, Modifier.weight(1f)) }
                }
                Spacer(Modifier.height(10.dp))
            }
        }
        if (partner != null) {
            item {
                val sp = SpeciesCatalog.byId(partner.speciesId)
                PVCard(onClick = { nav.navigate(Routes.pet(partner.id)) }) {
                    Text("⭐ Habit partner", style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(8.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        PetPortrait(sp, size = 60.dp)
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(partner.name, style = MaterialTheme.typography.titleLarge)
                            Text("${sp.name} • Lv ${partner.level} • ${sp.stageName(partner.stage)}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        BondBadge(partner.loyaltyPoints)
                    }
                    Spacer(Modifier.height(8.dp))
                    Text(
                        "Your partner receives XP, loyalty and Development Points every time you complete a habit.",
                        style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
        }
        item {
            val recent = AchievementCatalog.all.filter { it.id in achievements }.sortedByDescending { achievements[it.id] }.take(6)
            PVCard {
                SectionTitle("Recent badges", action = "All", onAction = { nav.navigate(Routes.ACHIEVEMENTS) })
                Spacer(Modifier.height(8.dp))
                if (recent.isEmpty()) {
                    Text("Complete your first habit to earn a badge!", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                } else {
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        recent.forEach { Text(it.emoji, fontSize = 30.sp) }
                    }
                }
            }
        }
        item {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                MenuRow("📊", "Statistics") { nav.navigate(Routes.STATS) }
                MenuRow("🏅", "Achievement gallery") { nav.navigate(Routes.ACHIEVEMENTS) }
                MenuRow("🎯", "Missions & challenges") { nav.navigate(Routes.MISSIONS) }
                MenuRow("📘", "Animal collection") { nav.navigate(Routes.COLLECTION) }
                MenuRow("🛍️", "Pet shop") { nav.navigate(Routes.SHOP) }
                MenuRow("⚙️", "Settings") { nav.navigate(Routes.SETTINGS) }
            }
        }
    }

    if (editing) {
        var name by remember { mutableStateOf(p.name) }
        var avatar by remember { mutableStateOf(p.avatar) }
        AlertDialog(
            onDismissRequest = { editing = false },
            title = { Text("Edit profile") },
            text = {
                Column {
                    OutlinedTextField(
                        value = name, onValueChange = { if (it.length <= 20) name = it },
                        singleLine = true, label = { Text("Name") }, shape = RoundedCornerShape(14.dp),
                    )
                    Spacer(Modifier.height(12.dp))
                    profileAvatars.chunked(6).forEach { row ->
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            row.forEach { a ->
                                Box(
                                    Modifier
                                        .size(38.dp)
                                        .clip(CircleShape)
                                        .background(if (a == avatar) MaterialTheme.colorScheme.primary.copy(alpha = 0.3f) else MaterialTheme.colorScheme.surfaceVariant)
                                        .clickable { avatar = a },
                                    contentAlignment = Alignment.Center,
                                ) { Text(a, fontSize = 20.sp) }
                            }
                        }
                        Spacer(Modifier.height(6.dp))
                    }
                }
            },
            confirmButton = { TextButton(onClick = { vm.updateProfile(name, avatar); editing = false }) { Text("Save") } },
            dismissButton = { TextButton(onClick = { editing = false }) { Text("Cancel") } },
        )
    }
}

@Composable
private fun StatTile(emoji: String, text: String, modifier: Modifier = Modifier) {
    Column(
        modifier
            .clip(RoundedCornerShape(20.dp))
            .background(MaterialTheme.colorScheme.surface)
            .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f), RoundedCornerShape(20.dp))
            .padding(vertical = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text(emoji, fontSize = 22.sp)
        Text(text, style = MaterialTheme.typography.labelLarge, textAlign = TextAlign.Center)
    }
}

@Composable
private fun MenuRow(emoji: String, label: String, onClick: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .background(MaterialTheme.colorScheme.surface)
            .clickable(onClick = onClick)
            .padding(16.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(emoji, fontSize = 20.sp)
        Spacer(Modifier.width(12.dp))
        Text(label, style = MaterialTheme.typography.titleSmall, modifier = Modifier.weight(1f))
        Text("›", fontSize = 22.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

// ------------------------------------------------------------------
// 13. Achievements gallery
// ------------------------------------------------------------------

@Composable
fun AchievementsScreen(vm: GameViewModel, nav: NavHostController) {
    val stats by vm.stats.collectAsStateWithLifecycle()
    val unlocked by vm.achievements.collectAsStateWithLifecycle()
    val claims by vm.claims.collectAsStateWithLifecycle()
    val unclaimed = AchievementCatalog.all.count { it.id in unlocked && "ach:${it.id}" !in claims }

    LazyVerticalGrid(
        columns = GridCells.Fixed(2),
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 24.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item(span = { GridItemSpan(maxLineSpan) }) {
            ScreenHeader(
                "Achievements", onBack = { nav.popBackStack() },
                subtitle = "${unlocked.size} of ${AchievementCatalog.all.size} badges" + if (unclaimed > 0) " • $unclaimed reward${if (unclaimed == 1) "" else "s"} to claim!" else "",
            )
        }
        items(AchievementCatalog.all, key = { it.id }) { def ->
            val isUnlocked = def.id in unlocked
            val claimed = "ach:${def.id}" in claims
            val progress = StatsCalculator.achievementProgress(def, stats).coerceAtMost(def.target)
            PVCard(padding = PaddingValues(14.dp)) {
                Box(
                    Modifier
                        .align(Alignment.CenterHorizontally)
                        .size(70.dp)
                        .clip(CircleShape)
                        .background(
                            if (isUnlocked) Brush.radialGradient(listOf(Color(0xFFFFE08A), Color(0xFFFFB547)))
                            else Brush.radialGradient(listOf(MaterialTheme.colorScheme.surfaceVariant, MaterialTheme.colorScheme.surfaceVariant))
                        ),
                    contentAlignment = Alignment.Center,
                ) {
                    if (isUnlocked) {
                        Text(def.emoji, fontSize = 34.sp)
                    } else {
                        Text(def.emoji, fontSize = 34.sp, modifier = Modifier.silhouette(Color(0xFF8C8FAE)))
                    }
                }
                Spacer(Modifier.height(10.dp))
                Text(def.title, style = MaterialTheme.typography.titleSmall, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth(), maxLines = 1)
                Text(
                    def.description, style = MaterialTheme.typography.labelSmall, textAlign = TextAlign.Center,
                    color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.fillMaxWidth(), maxLines = 2, minLines = 2,
                )
                Spacer(Modifier.height(8.dp))
                if (!isUnlocked) {
                    ProgressTrack(progress / def.target.toFloat(), MaterialTheme.colorScheme.secondary, Modifier.fillMaxWidth().height(6.dp))
                    Text("$progress / ${def.target}", style = MaterialTheme.typography.labelSmall, modifier = Modifier.align(Alignment.CenterHorizontally))
                } else {
                    val reward = "+${def.coins} 🪙" + (def.itemId?.let { " +1 ${ItemCatalog.byId(it).emoji}" } ?: "")
                    Text(
                        if (claimed) "Claimed ✓" else "Claim $reward",
                        style = MaterialTheme.typography.labelLarge,
                        color = if (claimed) MaterialTheme.colorScheme.tertiary else Color.White,
                        textAlign = TextAlign.Center,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(
                                if (claimed) Brush.horizontalGradient(listOf(Color.Transparent, Color.Transparent))
                                else Brush.horizontalGradient(listOf(Color(0xFFFFB547), Color(0xFFFF7A3D)))
                            )
                            .clickable(enabled = !claimed) { vm.claimAchievement(def.id) }
                            .padding(vertical = 8.dp),
                    )
                }
            }
        }
    }
}

// ------------------------------------------------------------------
// 14. Statistics
// ------------------------------------------------------------------

@Composable
fun StatisticsScreen(vm: GameViewModel, nav: NavHostController) {
    val stats by vm.stats.collectAsStateWithLifecycle()
    val logs by vm.logs.collectAsStateWithLifecycle()
    val habits by vm.habits.collectAsStateWithLifecycle()
    val allHabits by vm.allHabits.collectAsStateWithLifecycle()
    val pets by vm.pets.collectAsStateWithLifecycle()
    var range by remember { mutableStateOf(0) }
    val today = Time.today()
    val days = if (range == 0) 7 else 30
    val counts = logs.groupingBy { it.epochDay }.eachCount()
    val windowLogs = logs.filter { it.epochDay > today - days }
    val possible = (habits.size * days).coerceAtLeast(1)
    val rate = (windowLogs.size * 100 / possible).coerceAtMost(100)
    val habitById = allHabits.associateBy { it.id }
    val byCategory = windowLogs.groupingBy { habitById[it.habitId]?.category ?: HabitCategory.CUSTOM.name }.eachCount()
    val careTotal = stats.count(ActivityTypes.CARE)

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 24.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        item { ScreenHeader("Statistics", onBack = { nav.popBackStack() }, subtitle = "Your growth, visualised") }
        item {
            val tiles = listOf(
                "✅" to "${stats.totalHabits}\ntotal habits",
                "🔥" to "${stats.currentStreak}\ncurrent streak",
                "🏆" to "${stats.bestStreak}\nbest streak",
                "💞" to "$careTotal\ncare actions",
                "🎯" to "${stats.counts[PetAction.TRAIN.name] ?: 0}\ntrainings",
                "🌟" to "${stats.counts[ActivityTypes.PERFECT_DAY] ?: 0}\nperfect days",
            )
            tiles.chunked(3).forEach { row ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    row.forEach { (e, t) -> StatTile(e, t, Modifier.weight(1f)) }
                }
                Spacer(Modifier.height(10.dp))
            }
        }
        item {
            PVCard {
                SectionTitle("Habits completed")
                Spacer(Modifier.height(8.dp))
                SegmentedTabs(listOf("7 days", "30 days"), range, { range = it })
                Spacer(Modifier.height(14.dp))
                val values = (days - 1 downTo 0).map { counts[today - it] ?: 0 }
                BarChart(values, labels = (days - 1 downTo 0).map { d -> if (days == 7) Time.shortDay(today - d).take(2) else if (d % 5 == 0) "${Time.dayOfMonth(today - d)}" else "" })
                Spacer(Modifier.height(10.dp))
                Text("Completion rate: $rate% of possible habits", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.tertiary)
            }
        }
        item {
            PVCard {
                SectionTitle("By category (last $days days)")
                Spacer(Modifier.height(8.dp))
                val maxCat = (byCategory.values.maxOrNull() ?: 1).coerceAtLeast(1)
                HabitCategory.entries.forEach { cat ->
                    val c = byCategory[cat.name] ?: 0
                    Row(Modifier.padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("${cat.emoji} ${cat.label}", style = MaterialTheme.typography.labelMedium, modifier = Modifier.width(130.dp), maxLines = 1)
                        ProgressTrack(c / maxCat.toFloat(), MaterialTheme.colorScheme.primary, Modifier.weight(1f).height(10.dp))
                        Spacer(Modifier.width(8.dp))
                        Text("$c", style = MaterialTheme.typography.labelLarge)
                    }
                }
            }
        }
        item {
            PVCard {
                SectionTitle("Habit history")
                Spacer(Modifier.height(10.dp))
                HabitHeatmap(logs, habits.size.coerceAtLeast(1), today)
            }
        }
        item {
            PVCard {
                SectionTitle("Pets")
                Spacer(Modifier.height(8.dp))
                if (pets.isEmpty()) Text("No pets yet.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                pets.forEach { pet ->
                    val sp = SpeciesCatalog.byId(pet.speciesId)
                    Row(Modifier.padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                        PetPortrait(sp, size = 40.dp)
                        Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) {
                            Text(pet.name, style = MaterialTheme.typography.titleSmall)
                            ProgressTrack(pet.xp / GameRules.petXpForNext(pet.level).toFloat(), XpColor, Modifier.fillMaxWidth().height(5.dp))
                        }
                        Spacer(Modifier.width(10.dp))
                        Text("Lv ${pet.level} • S${pet.stage} • ${GameRules.bondEmoji(GameRules.bondLevel(pet.loyaltyPoints))}", style = MaterialTheme.typography.labelMedium)
                    }
                }
            }
        }
    }
}

@Composable
private fun BarChart(values: List<Int>, labels: List<String>) {
    val max = (values.maxOrNull() ?: 1).coerceAtLeast(1)
    val color = MaterialTheme.colorScheme.primary
    Row(
        Modifier.fillMaxWidth().height(150.dp),
        horizontalArrangement = Arrangement.spacedBy(if (values.size > 10) 2.dp else 8.dp),
        verticalAlignment = Alignment.Bottom,
    ) {
        values.forEachIndexed { i, v ->
            val target = v / max.toFloat()
            val h by animateFloatAsState(target, tween(700), label = "bar")
            Column(Modifier.weight(1f).fillMaxHeight(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Bottom) {
                if (values.size <= 10 && v > 0) Text("$v", style = MaterialTheme.typography.labelSmall)
                Box(
                    Modifier
                        .fillMaxWidth()
                        .fillMaxHeight((h * 0.78f).coerceAtLeast(0.02f))
                        .clip(RoundedCornerShape(topStart = 8.dp, topEnd = 8.dp))
                        .background(Brush.verticalGradient(listOf(color, color.copy(alpha = 0.5f))))
                )
                Text(labels.getOrElse(i) { "" }, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
            }
        }
    }
}

// ------------------------------------------------------------------
// 15. Settings
// ------------------------------------------------------------------

@Composable
fun SettingsScreen(vm: GameViewModel, nav: NavHostController, onReset: () -> Unit) {
    val player by vm.player.collectAsStateWithLifecycle()
    val context = LocalContext.current
    var confirmReset by remember { mutableStateOf(false) }
    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (!granted) vm.problem("Notifications are blocked. You can allow them in Android settings.")
    }
    val p = player ?: return

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 24.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        item { ScreenHeader("Settings", onBack = { nav.popBackStack() }) }
        item {
            PVCard {
                Text("🎨 Theme", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(10.dp))
                SegmentedTabs(listOf("System", "Light", "Dark"), p.themeMode, { vm.setTheme(it) })
            }
        }
        item {
            PVCard {
                SettingSwitch("🔔", "Daily reminder", "A gentle nudge about your habits and pets", p.notificationsEnabled) { enabled ->
                    if (enabled && Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU && !NotificationHelper.hasPermission(context)) {
                        permissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                    }
                    vm.setNotifications(enabled)
                }
                if (p.notificationsEnabled) {
                    Spacer(Modifier.height(10.dp))
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(14.dp))
                            .background(MaterialTheme.colorScheme.surfaceVariant)
                            .clickable {
                                TimePickerDialog(context, { _, h, m -> vm.setReminderTime(h, m) }, p.reminderHour, p.reminderMinute, false).show()
                            }
                            .padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Text("⏰", fontSize = 18.sp)
                        Spacer(Modifier.width(10.dp))
                        Text("Reminder time", style = MaterialTheme.typography.titleSmall, modifier = Modifier.weight(1f))
                        Text(Time.formatTime(p.reminderHour, p.reminderMinute), style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary)
                    }
                }
                Spacer(Modifier.height(12.dp))
                SettingSwitch("📳", "Haptic feedback", "Vibrate on pet interactions and training", p.hapticsEnabled) { vm.setHaptics(it) }
            }
        }
        item {
            PVCard {
                Text("✅ Habits", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(4.dp))
                Text("Add, edit or archive habits from the Habit Tracker tab (⋮ menu on each habit).", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        item {
            PVCard {
                Text("🔒 Privacy & data", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(4.dp))
                Text(
                    "PetVerse works fully offline. No login, no subscription, no ads, no paid APIs. All progress is saved only on this device in a local database.",
                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Spacer(Modifier.height(12.dp))
                Text(
                    "Reset all progress",
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.error,
                    modifier = Modifier
                        .clip(RoundedCornerShape(50))
                        .border(1.5.dp, MaterialTheme.colorScheme.error, RoundedCornerShape(50))
                        .clickable { confirmReset = true }
                        .padding(horizontal = 16.dp, vertical = 10.dp),
                )
            }
        }
        item {
            EnvironmentBackdrop(com.petverse.app.data.model.EnvironmentId.DOG_PARK, Modifier.fillMaxWidth().height(150.dp)) {
                AnimatedPet(SpeciesCatalog.byId("golden_retriever"), stage = 3, size = 110.dp, modifier = Modifier.align(Alignment.Center).padding(top = 20.dp))
            }
            Spacer(Modifier.height(8.dp))
            Text(
                "PetVerse v1.0.0 — Your Habits. Your Pets. Your World.",
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth(),
            )
        }
    }

    if (confirmReset) {
        AlertDialog(
            onDismissRequest = { confirmReset = false },
            title = { Text("Reset everything?") },
            text = { Text("This permanently deletes your pets, habits, history, coins and badges on this device. This can't be undone.") },
            confirmButton = {
                TextButton(onClick = {
                    confirmReset = false
                    vm.resetProgress(onReset)
                }) { Text("Reset", color = MaterialTheme.colorScheme.error) }
            },
            dismissButton = { TextButton(onClick = { confirmReset = false }) { Text("Cancel") } },
        )
    }
}

@Composable
private fun SettingSwitch(emoji: String, title: String, subtitle: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(emoji, fontSize = 20.sp)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.titleSmall)
            Text(subtitle, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Switch(checked = checked, onCheckedChange = onChange)
    }
}
