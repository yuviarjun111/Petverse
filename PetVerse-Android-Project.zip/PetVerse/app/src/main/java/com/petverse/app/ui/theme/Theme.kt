package com.petverse.app.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

// ---------------- Palette ----------------
val Violet = Color(0xFF7C5CFF)
val VioletDeep = Color(0xFF4A30C9)
val Honey = Color(0xFFFFB547)
val Mint = Color(0xFF2ED3A5)
val Coral = Color(0xFFFF6B8A)
val Sky = Color(0xFF4DA3FF)
val Gold = Color(0xFFFFD25A)

val HappinessColor = Color(0xFFFFC23D)
val HealthColor = Color(0xFFFF5C7A)
val EnergyColor = Color(0xFF3DDC97)
val FullnessColor = Color(0xFFFF9F43)
val HydrationColor = Color(0xFF4DA3FF)
val CleanColor = Color(0xFF5FD4F0)
val IntelligenceColor = Color(0xFFB06BFF)
val StrengthColor = Color(0xFFFF7849)
val FriendshipColor = Color(0xFFFF6BB5)
val LoyaltyColor = Color(0xFFFF4F8B)
val XpColor = Color(0xFF7C5CFF)

private val DarkColors = darkColorScheme(
    primary = Violet,
    onPrimary = Color.White,
    primaryContainer = Color(0xFF2D2466),
    onPrimaryContainer = Color(0xFFDCD3FF),
    secondary = Honey,
    onSecondary = Color(0xFF2A1A00),
    secondaryContainer = Color(0xFF3D2E10),
    onSecondaryContainer = Honey,
    tertiary = Mint,
    onTertiary = Color(0xFF00281C),
    background = Color(0xFF0E1020),
    onBackground = Color(0xFFECEBFF),
    surface = Color(0xFF181B30),
    onSurface = Color(0xFFECEBFF),
    surfaceVariant = Color(0xFF23273F),
    onSurfaceVariant = Color(0xFFA9ABCB),
    surfaceContainer = Color(0xFF1C1F36),
    outline = Color(0xFF34385A),
    error = Coral,
)

private val LightColors = lightColorScheme(
    primary = Color(0xFF6A47F5),
    onPrimary = Color.White,
    primaryContainer = Color(0xFFE6E0FF),
    onPrimaryContainer = Color(0xFF2D1F8F),
    secondary = Color(0xFFF59E0B),
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFFFF0D6),
    onSecondaryContainer = Color(0xFF7A4B00),
    tertiary = Color(0xFF12B886),
    onTertiary = Color.White,
    background = Color(0xFFF6F4FF),
    onBackground = Color(0xFF1B1A2E),
    surface = Color.White,
    onSurface = Color(0xFF1B1A2E),
    surfaceVariant = Color(0xFFEDEAFB),
    onSurfaceVariant = Color(0xFF5E5C7A),
    surfaceContainer = Color(0xFFF1EEFF),
    outline = Color(0xFFDDD8F5),
    error = Color(0xFFE5484D),
)

private val Base = TextStyle(fontFamily = FontFamily.SansSerif)

val PetVerseTypography = Typography(
    displayLarge = Base.copy(fontSize = 44.sp, fontWeight = FontWeight.Black, letterSpacing = (-1).sp),
    displaySmall = Base.copy(fontSize = 32.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = (-0.5).sp),
    headlineLarge = Base.copy(fontSize = 28.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = (-0.5).sp),
    headlineMedium = Base.copy(fontSize = 24.sp, fontWeight = FontWeight.ExtraBold),
    headlineSmall = Base.copy(fontSize = 20.sp, fontWeight = FontWeight.Bold),
    titleLarge = Base.copy(fontSize = 19.sp, fontWeight = FontWeight.Bold),
    titleMedium = Base.copy(fontSize = 16.sp, fontWeight = FontWeight.Bold),
    titleSmall = Base.copy(fontSize = 14.sp, fontWeight = FontWeight.Bold),
    bodyLarge = Base.copy(fontSize = 16.sp, lineHeight = 23.sp),
    bodyMedium = Base.copy(fontSize = 14.sp, lineHeight = 20.sp),
    bodySmall = Base.copy(fontSize = 12.sp, lineHeight = 17.sp),
    labelLarge = Base.copy(fontSize = 14.sp, fontWeight = FontWeight.Bold),
    labelMedium = Base.copy(fontSize = 12.sp, fontWeight = FontWeight.SemiBold),
    labelSmall = Base.copy(fontSize = 11.sp, fontWeight = FontWeight.SemiBold, letterSpacing = 0.3.sp),
)

private val PetVerseShapes = Shapes(
    extraSmall = RoundedCornerShape(8.dp),
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(18.dp),
    large = RoundedCornerShape(24.dp),
    extraLarge = RoundedCornerShape(32.dp),
)

val LocalIsDark = staticCompositionLocalOf { false }

@Composable
fun PetVerseTheme(dark: Boolean, content: @Composable () -> Unit) {
    CompositionLocalProvider(LocalIsDark provides dark) {
        MaterialTheme(
            colorScheme = if (dark) DarkColors else LightColors,
            typography = PetVerseTypography,
            shapes = PetVerseShapes,
            content = content,
        )
    }
}
