package com.petverse.app.data.model

/**
 * Discovery rarity: how rarely a species is discovered inside PetVerse.
 * It never describes an animal's real-world worth.
 */
enum class Rarity(
    val tier: Int,
    val label: String,
    val color: Long,
    val minLevel: Int,
    val setupCost: Int,
) {
    COMMON(1, "Common", 0xFF9AA5B1, 1, 50),
    UNCOMMON(2, "Uncommon", 0xFF2FCB86, 3, 120),
    RARE(3, "Rare", 0xFF4DA3FF, 5, 250),
    EPIC(4, "Epic", 0xFFB06BFF, 8, 450),
    LEGENDARY(5, "Legendary", 0xFFFFA81F, 12, 800),
    MYTHICAL(6, "Mythical", 0xFFFF5FA2, 18, 1500),
}

enum class AnimalCategory(val label: String, val emoji: String) {
    MAMMAL("Mammals", "🐾"),
    BIRD("Birds", "🪶"),
    AQUATIC("Aquatic", "🌊"),
    REPTILE("Reptiles", "🦎"),
    MYTHICAL("Mythical", "✨"),
}

enum class AnimStyle { BOUNCE, PROWL, GALLOP, HOP, FLY, SWIM, SLITHER, MAJESTIC }

enum class Diet(val label: String, val emoji: String) {
    OMNIVORE("Omnivore", "🥣"),
    CARNIVORE("Carnivore", "🍖"),
    HERBIVORE("Herbivore", "🥕"),
    SEEDS("Seeds & fruit", "🌻"),
    FISH_FOOD("Aquatic diet", "🦐"),
    INSECTS("Insects & greens", "🥬"),
    BAMBOO("Bamboo", "🎋"),
    STARLIGHT("Starlight nectar", "🌟"),
}

enum class Personality(val label: String, val emoji: String, val effect: String) {
    PLAYFUL("Playful", "🎈", "Play sessions give +50% happiness"),
    CALM("Calm", "🍃", "Rest restores +50% energy"),
    CURIOUS("Curious", "🔍", "Training gives +1 extra intelligence"),
    BRAVE("Brave", "🛡️", "Training gives +1 extra strength"),
    GENTLE("Gentle", "🌸", "Petting builds extra friendship"),
    LOYAL("Loyal", "💞", "Earns 20% more loyalty"),
    PROUD("Proud", "👑", "Tricks give +50% XP"),
    WISE("Wise", "🦉", "Earns 10% more XP"),
    ENERGETIC("Energetic", "⚡", "Activities cost 30% less energy"),
    SOCIAL("Social", "🤝", "Play builds extra friendship"),
}

enum class SpeciesGroup(
    val stages: List<String>,
    val style: AnimStyle,
    val abilities: List<String>,
    val playEmoji: String,
    val walkable: Boolean,
) {
    DOG(
        listOf("Newborn", "Baby Puppy", "Young Puppy", "Adult Dog", "Advanced Companion"),
        AnimStyle.BOUNCE, listOf("Happy Zoomies", "Keen Nose", "Loyal Guardian", "Hero Companion"), "🎾", true
    ),
    CAT(
        listOf("Newborn Kitten", "Baby Kitten", "Young Cat", "Adult Cat", "Wise Companion"),
        AnimStyle.PROWL, listOf("Purr Therapy", "Silent Paws", "Night Vision", "Graceful Leap"), "🧶", false
    ),
    EQUINE(
        listOf("Newborn Foal", "Foal", "Yearling", "Adult", "Champion Steed"),
        AnimStyle.GALLOP, listOf("Gentle Nuzzle", "Steady Trot", "Wind Gallop", "Champion Jump"), "🌾", true
    ),
    SMALL(
        listOf("Newborn", "Baby", "Juvenile", "Adult", "Elder Friend"),
        AnimStyle.HOP, listOf("Twitchy Nose", "Burrow Builder", "Speedy Sprint", "Cozy Companion"), "🎡", false
    ),
    WILD_CANINE(
        listOf("Newborn Pup", "Cub", "Juvenile", "Adult", "Pack Guardian"),
        AnimStyle.PROWL, listOf("Keen Hearing", "Forest Tracker", "Pack Spirit", "Moon Howl"), "🍂", false
    ),
    BIG_CAT(
        listOf("Newborn Cub", "Cub", "Juvenile", "Adult", "Sanctuary Guardian"),
        AnimStyle.MAJESTIC, listOf("Mighty Yawn", "Stealth Stalk", "Power Pounce", "Royal Roar"), "🪵", false
    ),
    LARGE_MAMMAL(
        listOf("Newborn", "Calf", "Juvenile", "Adult", "Gentle Giant"),
        AnimStyle.GALLOP, listOf("Gentle Strength", "Herd Sense", "Long Memory", "Ancient Wisdom"), "🍃", false
    ),
    PRIMATE(
        listOf("Newborn", "Infant", "Juvenile", "Adult", "Clever Elder"),
        AnimStyle.BOUNCE, listOf("Quick Hands", "Tree Swing", "Puzzle Genius", "Troop Leader"), "🍌", false
    ),
    BIRD(
        listOf("Hatchling", "Nestling", "Fledgling", "Adult", "Sky Master"),
        AnimStyle.FLY, listOf("Sweet Song", "Swift Wings", "Sharp Eyes", "Sky Dance"), "🪁", false
    ),
    FISH(
        listOf("Fry", "Juvenile", "Young", "Adult", "Reef Elder"),
        AnimStyle.SWIM, listOf("Bubble Trail", "Reef Dash", "Shimmer Scales", "Current Rider"), "💧", false
    ),
    MARINE(
        listOf("Newborn Calf", "Calf", "Juvenile", "Adult", "Ocean Elder"),
        AnimStyle.SWIM, listOf("Echo Song", "Wave Leap", "Deep Dive", "Ocean Harmony"), "🌊", false
    ),
    REPTILE(
        listOf("Hatchling", "Juvenile", "Young", "Adult", "Ancient One"),
        AnimStyle.SLITHER, listOf("Sun Basking", "Camouflage", "Calm Mind", "Ancient Patience"), "☀️", false
    ),
    MYTHIC(
        listOf("Ember Hatchling", "Young Spirit", "Rising Spirit", "Ascended", "Celestial"),
        AnimStyle.MAJESTIC, listOf("Spark Glow", "Starlight Wings", "Elemental Aura", "Celestial Ascension"), "✨", false
    ),
}

enum class EnvironmentId(
    val title: String,
    val emoji: String,
    val unlockLevel: Int,
    val skyTop: Long,
    val skyBottom: Long,
    val ground: Long,
    val decor: List<String>,
    val skyDecor: List<String>,
    val description: String,
) {
    HOME(
        "Pet Home", "🏡", 1, 0xFFFFE3BF, 0xFFFFD1A1, 0xFFC98F5B,
        listOf("🪴", "🛋️", "🧺", "🪴"), listOf("🖼️", "💡"),
        "A cozy home for small friends and calm reptiles."
    ),
    DOG_PARK(
        "Dog Park", "🌳", 1, 0xFF8FD3FF, 0xFFD3F1FF, 0xFF6BCB5B,
        listOf("🌳", "🌼", "🦴", "🌳"), listOf("☁️", "☀️"),
        "Open grass, sunshine and endless fetch."
    ),
    CAT_HOUSE(
        "Cat House", "🏠", 1, 0xFFFFD6E7, 0xFFFFEEF4, 0xFFB98AD8,
        listOf("🧶", "🪴", "📦", "🛋️"), listOf("🌙", "🖼️"),
        "Warm cushions, sunny windows and cardboard castles."
    ),
    TRAINING_GROUND(
        "Training Ground", "🎯", 2, 0xFF9AD7FF, 0xFFE4F6FF, 0xFFE8C07A,
        listOf("🚩", "🎯", "🏁", "🚧"), listOf("☁️", "🌤️"),
        "Where every pet practises skills and earns confidence."
    ),
    STABLE(
        "Horse Stable", "🌾", 4, 0xFFFFD59A, 0xFFFFF1D6, 0xFF9CCB5B,
        listOf("🌾", "🪵", "🌻", "🌾"), listOf("☁️", "🌅"),
        "Fresh hay, wide meadows and room to gallop."
    ),
    AQUARIUM(
        "Aquarium & Ocean Reserve", "🌊", 4, 0xFF35C0EE, 0xFF0B5FA8, 0xFFE9D6A6,
        listOf("🌿", "🐚", "🌿", "⚓"), listOf("💧", "💧"),
        "Crystal water for fish, turtles and ocean giants."
    ),
    BIRD_SANCTUARY(
        "Bird Sanctuary", "🕊️", 5, 0xFFA8E6FF, 0xFFE8FBFF, 0xFF7BC96F,
        listOf("🌲", "🌸", "🌳", "🌲"), listOf("☁️", "☁️"),
        "Tall trees and open skies for feathered friends."
    ),
    FOREST(
        "Forest", "🌲", 6, 0xFF9BE3B5, 0xFFDFF7E6, 0xFF3E8E4E,
        listOf("🌲", "🍄", "🌲", "🌿"), listOf("☁️", "🍃"),
        "A protected woodland reserve for forest wildlife."
    ),
    ANIMAL_SANCTUARY(
        "Animal Sanctuary", "🏞️", 10, 0xFFFFC985, 0xFFFFEBC9, 0xFFC9A55B,
        listOf("🌴", "🪨", "🌾", "🌳"), listOf("☀️", "☁️"),
        "A protected virtual reserve where wild animals live freely and are cared for — never kept as household pets."
    ),
    MYTHIC_GROVE(
        "Mythic Grove", "🔮", 18, 0xFF3A1F78, 0xFF9C6BFF, 0xFF4B2C8F,
        listOf("🔮", "🍄", "🌸", "✨"), listOf("🌙", "⭐"),
        "A shimmering realm for legendary fantasy creatures."
    ),
}

enum class HabitCategory(val label: String, val emoji: String, val bonusText: String) {
    MORNING("Morning", "🌅", "+5 partner happiness"),
    LEARNING("Learning", "📚", "+1 Training Point"),
    PERSONAL("Personal Growth", "🌱", "+3 bonus loyalty"),
    HEALTH("Health", "💪", "+5 partner health & energy"),
    CUSTOM("Custom", "⭐", "Classic rewards"),
}

enum class Difficulty(val label: String, val coins: Int, val playerXp: Int, val petXp: Int) {
    EASY("Easy", 10, 10, 8),
    MEDIUM("Medium", 15, 15, 12),
    HARD("Hard", 25, 25, 18),
}

enum class PetAction(
    val label: String,
    val wildLabel: String,
    val emoji: String,
    val minBond: Int,
    val energyCost: Int,
) {
    FEED("Feed", "Prepare Meal", "🍖", 1, 0),
    WATER("Water", "Fresh Water", "💧", 1, 0),
    PET("Pet", "Observe", "🤚", 1, 0),
    PLAY("Play", "Enrichment", "🎾", 1, 10),
    TOY("Give Toy", "Enrichment Toy", "🧸", 1, 5),
    CLEAN("Clean", "Clean Habitat", "🧽", 1, 0),
    REST("Rest", "Rest", "😴", 1, 0),
    USE_ITEM("Use Item", "Use Item", "🎒", 1, 0),
    TRAIN("Train", "Enrichment Training", "🎯", 1, 15),
    WALK("Walk", "Walk", "🦮", 2, 15),
    TRICK("Show Trick", "Show Behaviour", "✨", 3, 5),
    CUDDLE("Cuddle", "Trust Moment", "🤗", 4, 0),
    ADVENTURE("Adventure", "Explore Reserve", "🗺️", 5, 20),
    GIFT("Bond Gift", "Bond Gift", "🎁", 6, 0),
}

enum class Reaction(val durationMs: Int) {
    EAT(1500), DRINK(1400), PET(1500), PLAY(2200), TOY(1800), CLEAN(1500), SLEEP(1600),
    WALK(3200), TRAIN(1300), GROW(2000), LEVEL_UP(1800), TRICK(1200), CUDDLE(1800),
    ADVENTURE(2600), GIFT(1600),
}

object ActivityTypes {
    const val HABIT = "HABIT"
    const val PERFECT_DAY = "PERFECT_DAY"
    const val ADOPT = "ADOPT"
    const val GROW = "GROW"
    const val SHOP = "SHOP"
    const val LOGIN = "LOGIN"

    /** Every PetAction is also logged with its enum name as the activity type. */
    val CARE: Set<String> = setOf(
        PetAction.FEED.name, PetAction.WATER.name, PetAction.PET.name, PetAction.PLAY.name,
        PetAction.TOY.name, PetAction.CLEAN.name, PetAction.REST.name, PetAction.WALK.name,
        PetAction.CUDDLE.name, PetAction.USE_ITEM.name, PetAction.TRICK.name,
    )
}
